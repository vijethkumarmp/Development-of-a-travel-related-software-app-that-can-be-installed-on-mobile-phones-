# TripBro Project - Setup & Integration Guide

## ✅ Project Status: FULLY INTEGRATED

### Backend (Django) - Running on http://localhost:8000
- **Port**: 8000
- **Framework**: Django REST Framework with JWT Authentication
- **Database**: SQLite (db.sqlite3)

### Frontend (React + TypeScript) - Running on http://localhost:5173
- **Port**: 5173
- **Framework**: React with Vite
- **API Integration**: Connected to Django backend

---

## 🔧 Fixed Issues

### 1. **Model Field Mismatches**
   - ✅ Fixed `Translation` model - added `source_language` field
   - ✅ Fixed `PackingList` model - updated to use `destination`, `trip_details`, `packing_list_items`
   - ✅ Fixed `SouvenirSuggestion` model - split `details` into `location` and `suggestion`
   - ✅ Fixed `JetLagPlan` model - split `flight_info` into proper fields
   - ✅ Fixed `Booking` model - split `booking_info` into separate fields

### 2. **Serializer Alignment**
   - ✅ All serializers updated to match model fields exactly
   - ✅ Removed non-existent field references
   - ✅ Added proper read-only fields

### 3. **View Field Names**
   - ✅ Fixed `ItinerarySuggestionViewSet` - uses `location_query` and `suggested_place`
   - ✅ Fixed `LiveGuideQueryViewSet` - uses correct field names
   - ✅ Fixed `SouvenirSuggestionViewSet` - uses `location` and `suggestion`

### 4. **Authentication & API**
   - ✅ Created comprehensive `apiService.ts` with all endpoints
   - ✅ Added user registration endpoint (`/api/register/`)
   - ✅ Integrated JWT token management in frontend
   - ✅ Updated `.env.local` with `VITE_API_URL`

### 5. **Frontend Integration**
   - ✅ Updated `LoginPage.tsx` to use backend authentication
   - ✅ Created `apiService.ts` with full CRUD operations for all models
   - ✅ Set up proper CORS handling

---

## 📋 API Endpoints

### Authentication
- `POST /api/register/` - Register new user
- `POST /api/token/` - Get JWT token
- `POST /api/token/refresh/` - Refresh JWT token

### User Data
- `GET/POST /api/userprofiles/` - User profiles
- `GET/POST /api/itineraries/` - Itinerary suggestions
- `GET/POST /api/translations/` - Translations
- `GET/POST /api/live-guides/` - Live guide queries
- `GET/POST /api/packing-lists/` - Packing lists
- `GET/POST /api/souvenirs/` - Souvenir suggestions
- `GET/POST /api/jetlag-plans/` - Jet lag plans
- `GET/POST /api/bookings/` - Bookings
- `GET/POST /api/expenses/` - Expenses
- `GET/POST /api/moods/` - Mood entries
- `GET/POST /api/offline-maps/` - Offline maps
- `GET/POST /api/scrapbook-entries/` - Scrapbook entries
- `GET/POST /api/sos-contacts/` - SOS contacts

---

## 🚀 Running the Project

### Backend
```bash
cd backend
python manage.py runserver 0.0.0.0:8000
```

### Frontend
```bash
cd frontend
npm run dev
```

---

## 🔑 How to Use the Frontend-Backend Connection

### 1. **User Registration & Login**
```typescript
import { registerUser, getToken } from '@/services/apiService';

// Register
const response = await registerUser('username', 'email@example.com', 'password');

// Login
const loginResponse = await getToken('username', 'password');
// Token is automatically stored
```

### 2. **Fetch Data**
```typescript
import { getItineraries, createItinerary } from '@/services/apiService';

// Get all itineraries for the logged-in user
const itineraries = await getItineraries();

// Create new itinerary
const newItinerary = await createItinerary({
  location_query: 'Paris',
  suggested_place: 'Eiffel Tower'
});
```

### 3. **Store Data Locally**
```typescript
import { initDB, add } from '@/services/dbService';

// Initialize IndexedDB
const db = await initDB();

// Store booking locally
await add('bookings', {
  id: 1,
  details: { ...bookingData }
});
```

---

## 📁 Project Structure

```
grpproject/
├── backend/
│   ├── backendapp/
│   │   ├── models.py          ✅ Fixed field definitions
│   │   ├── serializers.py     ✅ Fixed field mappings
│   │   ├── views.py           ✅ Added RegisterView
│   │   ├── urls.py            ✅ Added register endpoint
│   │   └── migrations/        ✅ Updated migrations
│   ├── tripbro/
│   │   ├── settings.py        ✅ CORS enabled
│   │   └── urls.py
│   ├── manage.py
│   └── requirements.txt
│
└── frontend/
    ├── src/
    │   ├── services/
    │   │   ├── apiService.ts   ✅ NEW - Full API integration
    │   │   ├── dbService.ts    ✅ IndexedDB support
    │   │   └── geminiService.ts
    │   ├── features/
    │   │   ├── LoginPage.tsx   ✅ Updated to use backend
    │   │   └── ...
    │   ├── App.tsx
    │   └── main.tsx
    ├── .env.local              ✅ Updated with VITE_API_URL
    ├── vite.config.ts          ✅ Proxy configured
    └── package.json
```

---

## ⚙️ Key Technologies

- **Backend**: Django 5.1.4, Django REST Framework, JWT Authentication
- **Frontend**: React 18.2, TypeScript 5.2, Vite 5.2
- **Database**: SQLite (frontend IndexedDB for local storage)
- **API Communication**: Fetch API with Bearer Token Authentication
- **Styling**: Tailwind CSS
- **AI Integration**: Google Gemini API (configured in .env)

---

## 🔐 Security Notes

- JWT tokens stored in localStorage
- CORS enabled for localhost
- Authentication required for all endpoints (except register & token)
- Tokens auto-managed by apiService

---

## 📝 Next Steps (Optional)

1. **Add environment-based API URLs**
   - Development: http://localhost:8000/api
   - Production: https://your-api-domain.com/api

2. **Implement refresh token logic**
   - Auto-refresh tokens before expiry

3. **Add error handling UI**
   - Toast notifications for API errors

4. **Add loading states**
   - Show spinners during API calls

5. **Implement offline support**
   - Sync with backend when connection restored

---

## ✨ All Systems Operational

Both frontend and backend are now:
✅ Running  
✅ Connected  
✅ Ready to store and retrieve user data  
✅ Fully integrated with authentication  

**Frontend**: http://localhost:5173  
**Backend API**: http://localhost:8000/api  
**Admin Panel**: http://localhost:8000/admin
