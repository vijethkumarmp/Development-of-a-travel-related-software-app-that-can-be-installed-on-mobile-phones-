import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Booking, Expense, TripMember } from '../types';
import { MOCK_BOOKINGS_DATA } from '../data/mockData'; 

interface TripContextType {
  bookings: Booking[];
  expenses: Expense[];
  members: TripMember[];
  addBooking: (booking: Booking) => void;
  updateBooking: (booking: Booking) => void;
  deleteBooking: (bookingId: number) => void;
  addExpense: (expense: Omit<Expense, 'id'>) => void;
  addMember: (name: string) => void;
}

const TripContext = createContext<TripContextType | undefined>(undefined);

export const TripProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [bookings, setBookings] = useState<Booking[]>(MOCK_BOOKINGS_DATA);
  const [members, setMembers] = useState<TripMember[]>([
    { id: 1, name: 'Alex' },
    { id: 2, name: 'Ben' },
    { id: 3, name: 'Chloe' },
  ]);
  const [expenses, setExpenses] = useState<Expense[]>([
    { id: 1, description: 'Dinner at Shibuya Crossing', amount: 12000, currency: 'JPY', paidBy: 1, splitBetween: [1, 2, 3], category: 'Food' },
    { id: 2, description: 'Ghibli Museum Tickets', amount: 40, currency: 'EUR', paidBy: 2, splitBetween: [1, 2, 3], category: 'Activities' },
    { id: 3, description: 'Train from Narita', amount: 60, currency: 'USD', paidBy: 1, splitBetween: [1, 2], category: 'Transport' },
    { id: 4, description: 'Hotel Stay', amount: 420, currency: 'GBP', paidBy: 3, splitBetween: [1, 2, 3], category: 'Accommodation' },
  ]);

  const addBooking = (booking: Booking) => {
    setBookings(prev => [booking, ...prev]);
  };

  const updateBooking = (updatedBooking: Booking) => {
    setBookings(prev => prev.map(b => b.id === updatedBooking.id ? updatedBooking : b));
  };

  const deleteBooking = (bookingId: number) => {
    setBookings(prev => prev.filter(b => b.id !== bookingId));
  };

  const addExpense = (expense: Omit<Expense, 'id'>) => {
    const newId = expenses.length > 0 ? Math.max(...expenses.map(e => e.id)) + 1 : 1;
    setExpenses(prev => [{ ...expense, id: newId }, ...prev]);
  };

  const addMember = (name: string) => {
    if (name.trim() && !members.find(m => m.name === name.trim())) {
      setMembers(prev => [...prev, { id: Date.now(), name: name.trim() }]);
    }
  };

  return (
    <TripContext.Provider value={{ bookings, expenses, members, addBooking, updateBooking, deleteBooking, addExpense, addMember }}>
      {children}
    </TripContext.Provider>
  );
};

export const useTrip = (): TripContextType => {
  const context = useContext(TripContext);
  if (!context) {
    throw new Error('useTrip must be used within a TripProvider');
  }
  return context;
};
