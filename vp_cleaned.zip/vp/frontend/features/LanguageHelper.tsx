import React, { useState, FC, useMemo, useRef, useCallback, useEffect } from 'react';
import { LanguageIcon } from '../components/icons/LanguageIcon';
import { SparklesIcon } from '../components/icons/SparklesIcon';
import { BookOpenIcon } from '../components/icons/BookOpenIcon';
import { translateText, generatePhrasebook, analyzeMenuImage } from '../services/geminiService';
import { Phrase, TranslationResponse, PhrasebookResponse, MenuAnalysisResponse } from '../types';
import { FoodIcon } from '../components/icons/FoodIcon';
import { TravelIcon } from '../components/icons/TravelIcon';
import { ShoppingIcon } from '../components/icons/ShoppingIcon';
import { ShieldIcon } from '../components/icons/ShieldIcon';
import { UserIcon } from '../components/icons/UserIcon';
import { VolumeUpIcon } from '../components/icons/VolumeUpIcon';
import { ScanIcon } from '../components/icons/ScanIcon';
import { CameraIcon } from '../components/icons/CameraIcon';
import { FireIcon } from '../components/icons/FireIcon';
import { LockClosedIcon } from '../components/icons/LockClosedIcon';

type View = 'translator' | 'phrasebook' | 'menu-scan';
type PhraseCategory = 'Greetings' | 'Dining' | 'Directions' | 'Shopping' | 'Emergency';

const PHRASEBOOK_CATEGORIES: { name: PhraseCategory, Icon: FC<any> }[] = [
    { name: 'Greetings', Icon: UserIcon },
    { name: 'Dining', Icon: FoodIcon },
    { name: 'Directions', Icon: TravelIcon },
    { name: 'Shopping', Icon: ShoppingIcon },
    { name: 'Emergency', Icon: ShieldIcon },
];

const LanguageHelper: FC = () => {
    const [activeView, setActiveView] = useState<View>('translator');
    const [targetLang, setTargetLang] = useState('Japanese');
    
    // Translator State
    const [inputText, setInputText] = useState('Where is the nearest train station?');
    const [translationResult, setTranslationResult] = useState<TranslationResponse | null>(null);
    const [isTranslating, setIsTranslating] = useState(false);

    // Phrasebook State
    const [selectedCategory, setSelectedCategory] = useState<PhraseCategory | null>(null);
    const [phrasebookData, setPhrasebookData] = useState<Phrase[]>([]);
    const [isFetchingPhrases, setIsFetchingPhrases] = useState(false);
    const [activePhraseIndex, setActivePhraseIndex] = useState<number | null>(null);
    const phraseCache = useMemo(() => new Map<string, Phrase[]>(), []);

    // AR Menu Scan State
    const [isLoadingScan, setIsLoadingScan] = useState(false);
    const [scanError, setScanError] = useState<string | null>(null);
    const [analysisResult, setAnalysisResult] = useState<MenuAnalysisResponse | null>(null);
    const [capturedImage, setCapturedImage] = useState<string | null>(null);
    const [isCameraOn, setIsCameraOn] = useState(false);
    const [permissionDenied, setPermissionDenied] = useState(false);
    
    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const streamRef = useRef<MediaStream | null>(null);

    const stopCamera = useCallback(() => {
        if (streamRef.current) {
            streamRef.current.getTracks().forEach(track => track.stop());
            streamRef.current = null;
        }
        setIsCameraOn(false);
    }, []);
    
    const startCamera = useCallback(async () => {
        setScanError(null);
        setPermissionDenied(false);
        setAnalysisResult(null);
        setCapturedImage(null);
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
                if (videoRef.current) {
                    videoRef.current.srcObject = stream;
                    streamRef.current = stream;
                    setIsCameraOn(true);
                }
            } catch (err: any) {
                console.error("Camera error:", err);
                if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
                    setScanError("Camera access was denied. Please enable it in your browser settings to use this feature.");
                    setPermissionDenied(true);
                } else {
                    setScanError("Could not access camera. Please check other browser permissions.");
                }
                setIsCameraOn(false);
            }
        } else {
            setScanError("Camera not supported on this device.");
        }
    }, []);

    const handleCaptureAndScan = async () => {
        if (videoRef.current && canvasRef.current) {
            const video = videoRef.current;
            const canvas = canvasRef.current;
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            const context = canvas.getContext('2d');
            if (context) {
                context.drawImage(video, 0, 0, canvas.width, canvas.height);
                const imageDataUrl = canvas.toDataURL('image/jpeg', 0.9);
                const base64Image = imageDataUrl.split(',')[1];
                
                setCapturedImage(imageDataUrl);
                stopCamera();
                setIsLoadingScan(true);
                setScanError(null);

                const result = await analyzeMenuImage(base64Image);
                if (result) {
                    setAnalysisResult(result);
                    if (result.menu_items.length === 0) {
                        setScanError("Could not detect any menu items. Please try again with a clearer picture.");
                    }
                } else {
                    setScanError("Failed to analyze the menu. The AI may be busy. Please try again.");
                }
                setIsLoadingScan(false);
            }
        }
    };

    const resetScanner = () => {
        stopCamera();
        setScanError(null);
        setAnalysisResult(null);
        setCapturedImage(null);
        setIsLoadingScan(false);
        setPermissionDenied(false);
        if (activeView === 'menu-scan') {
          startCamera();
        }
    };
    
    useEffect(() => {
        // When switching to menu-scan view, reset state but dont start camera automatically
        if (activeView !== 'menu-scan') {
             stopCamera();
        }
    }, [activeView, stopCamera]);


    const handleTranslate = async () => {
        if (!inputText.trim() || !targetLang.trim()) return;
        setIsTranslating(true);
        setTranslationResult(null);
        const result = await translateText(inputText, targetLang);
        setTranslationResult(result);
        setIsTranslating(false);
    };
    
    const handleSelectCategory = async (category: PhraseCategory) => {
        setSelectedCategory(category);
        setActivePhraseIndex(null);

        const cacheKey = `${targetLang}-${category}`;
        if (phraseCache.has(cacheKey)) {
            setPhrasebookData(phraseCache.get(cacheKey)!);
            return;
        }

        setIsFetchingPhrases(true);
        setPhrasebookData([]);
        const result = await generatePhrasebook(category, targetLang);
        if (result && result.phrases) {
            setPhrasebookData(result.phrases);
            phraseCache.set(cacheKey, result.phrases);
        }
        setIsFetchingPhrases(false);
    };

    return (
        <div className="max-w-4xl mx-auto animate-fadeIn">
            <div className="text-center mb-8">
                <LanguageIcon className="h-12 w-12 mx-auto text-[#ff8c00] mb-2"/>
                <h1 className="text-4xl font-bold text-[#f5f5f5]">Language Helper</h1>
                <p className="mt-2 text-lg text-[#a3a3a3]/70">Communicate like a local. Instant translations and a handy phrasebook.</p>
            </div>

            <div className="flex items-center gap-2 p-1 bg-[#1a1818]/50 rounded-lg mb-6 max-w-md mx-auto">
                <button onClick={() => setActiveView('translator')} className={`flex-1 text-center px-3 py-1.5 text-sm rounded-md transition-colors flex items-center justify-center gap-2 ${activeView === 'translator' ? 'bg-[#ff8c00] text-white' : 'text-[#f5f5f5] hover:bg-[#333]/70'}`}>
                    <SparklesIcon className="h-4 w-4" /> Translator
                </button>
                <button onClick={() => setActiveView('phrasebook')} className={`flex-1 text-center px-3 py-1.5 text-sm rounded-md transition-colors flex items-center justify-center gap-2 ${activeView === 'phrasebook' ? 'bg-[#ff8c00] text-white' : 'text-[#f5f5f5] hover:bg-[#333]/70'}`}>
                    <BookOpenIcon className="h-4 w-4" /> Phrasebook
                </button>
                 <button onClick={() => setActiveView('menu-scan')} className={`flex-1 text-center px-3 py-1.5 text-sm rounded-md transition-colors flex items-center justify-center gap-2 ${activeView === 'menu-scan' ? 'bg-[#ff8c00] text-white' : 'text-[#f5f5f5] hover:bg-[#333]/70'}`}>
                    <ScanIcon className="h-4 w-4" /> Menu Scan
                </button>
            </div>
            
            <div className="solaris-panel p-6">
                 <div className="flex items-center gap-4 mb-6">
                    <label htmlFor="target-lang" className="text-[#a3a3a3] font-medium">Translate to:</label>
                    <input
                        id="target-lang"
                        type="text"
                        value={targetLang}
                        onChange={(e) => setTargetLang(e.target.value)}
                        placeholder="e.g., Japanese"
                        className="bg-[#333]/50 border border-[#444] rounded-md py-1.5 px-3 text-[#f5f5f5] focus:outline-none focus:ring-1 focus:ring-[#ff8c00]"
                    />
                </div>
            
                {activeView === 'translator' && (
                    <div className="animate-fadeIn">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-[#a3a3a3]">Your Text (English)</label>
                                <textarea
                                    value={inputText}
                                    onChange={(e) => setInputText(e.target.value)}
                                    rows={5}
                                    className="mt-1 block w-full bg-[#333]/50 border border-[#444] rounded-md py-2 px-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00]"
                                />
                            </div>
                            <div className="relative">
                                <label className="block text-sm font-medium text-[#a3a3a3]">Translation</label>
                                <div className="mt-1 block w-full h-[126px] bg-[#1a1818]/50 border border-[#444] rounded-md py-2 px-3 text-[#f5f5f5] overflow-y-auto">
                                    {isTranslating ? <div className="text-[#a3a3a3]/70">Translating...</div> : null}
                                    {translationResult && (
                                        <div>
                                            <p className="text-[#ff8c00] text-lg">{translationResult.translation}</p>
                                            <p className="text-[#a3a3a3]/70 text-sm mt-2 italic">{translationResult.pronunciation_guide}</p>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                        <button
                            onClick={handleTranslate}
                            disabled={isTranslating}
                            className="mt-4 w-full flex justify-center py-2.5 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-[#ff8c00] hover:bg-[#e67e00] disabled:bg-[#ff8c00]/50"
                        >
                            {isTranslating ? 'Translating...' : 'Translate'}
                        </button>
                    </div>
                )}
                {activeView === 'phrasebook' && (
                    <div className="animate-fadeIn">
                        <h3 className="text-lg font-semibold text-[#f5f5f5] mb-4">Phrasebook Categories</h3>
                        <div className="grid grid-cols-3 md:grid-cols-5 gap-3 mb-6">
                            {PHRASEBOOK_CATEGORIES.map(({ name, Icon }) => (
                                <button
                                    key={name}
                                    onClick={() => handleSelectCategory(name)}
                                    className={`flex flex-col items-center justify-center gap-2 p-4 rounded-lg transition-colors border-2 ${selectedCategory === name ? 'bg-[#ff8c00]/20 border-[#ff8c00]' : 'bg-[#333]/50 border-transparent hover:bg-[#444]/50'}`}
                                >
                                    <Icon className="h-6 w-6 text-[#ff8c00]" />
                                    <span className="text-xs font-medium text-[#f5f5f5] text-center">{name}</span>
                                </button>
                            ))}
                        </div>

                        {isFetchingPhrases && <div className="text-center text-[#a3a3a3]/70">Generating phrasebook...</div>}

                        {phrasebookData.length > 0 && (
                            <div className="space-y-2">
                                {phrasebookData.map((phrase, index) => (
                                    <div key={index} className="border border-[#444] rounded-lg overflow-hidden">
                                        <button onClick={() => setActivePhraseIndex(activePhraseIndex === index ? null : index)} className="w-full p-3 text-left bg-[#333]/40 hover:bg-[#444]/50 focus:outline-none flex justify-between items-center">
                                            <span className="text-[#f5f5f5]">{phrase.source_phrase}</span>
                                            <span className={`transform transition-transform duration-200 ${activePhraseIndex === index ? 'rotate-180' : ''}`}>▼</span>
                                        </button>
                                        {activePhraseIndex === index && (
                                            <div className="p-4 bg-[#1a1818]/50 border-t border-[#444]">
                                                <p className="text-[#ff8c00] text-lg font-semibold">{phrase.translated_phrase}</p>
                                                <p className="text-[#a3a3a3]/70 text-sm italic mt-1">{phrase.pronunciation_guide}</p>
                                                <button className="text-[#a3a3a3]/70 mt-2 hover:text-white">
                                                    <VolumeUpIcon className="h-5 w-5" />
                                                </button>
                                            </div>
                                        )}
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                )}
                {activeView === 'menu-scan' && (
                  <div className="animate-fadeIn">
                    {!capturedImage && !isCameraOn && (
                        <div className="text-center py-8">
                            {permissionDenied ? (
                                <>
                                    <LockClosedIcon className="h-12 w-12 mx-auto text-red-400 mb-4" />
                                    <h2 className="text-xl font-semibold text-[#f5f5f5]">Camera Access Denied</h2>
                                    {scanError && <p className="text-red-400 text-sm mt-2 mb-4 max-w-sm mx-auto">{scanError}</p>}
                                    <button onClick={startCamera} className="px-5 py-2.5 bg-[#ff8c00] text-white rounded-lg font-semibold hover:bg-[#e67e00] transition-colors">
                                        Retry Permission
                                    </button>
                                </>
                            ) : (
                                <>
                                    <CameraIcon className="h-12 w-12 mx-auto text-[#a3a3a3]/70 mb-4" />
                                    <h2 className="text-xl font-semibold text-[#f5f5f5]">Ready to Scan a Menu?</h2>
                                    <button onClick={startCamera} className="mt-4 px-5 py-2.5 bg-[#ff8c00] text-white rounded-lg font-semibold hover:bg-[#e67e00] transition-colors">
                                        Start Camera
                                    </button>
                                    {scanError && <p className="text-red-400 text-sm mt-4">{scanError}</p>}
                                </>
                            )}
                        </div>
                    )}

                    {isCameraOn && (
                        <div className="relative">
                            <video ref={videoRef} className="w-full h-auto rounded-lg" autoPlay playsInline />
                            <canvas ref={canvasRef} className="hidden" />
                            <div className="absolute inset-0 flex items-end justify-center p-6 bg-gradient-to-t from-black/50 to-transparent">
                                <button onClick={handleCaptureAndScan} className="h-16 w-16 rounded-full bg-white/20 backdrop-blur-md border-2 border-white/50 flex items-center justify-center text-white transition-all duration-300 hover:bg-white/30 hover:scale-105 active:scale-95" aria-label="Scan Menu">
                                    <ScanIcon className="h-8 w-8" />
                                </button>
                            </div>
                        </div>
                    )}
                    
                    {capturedImage && (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="relative">
                              <img src={capturedImage} alt="Captured Menu" className="rounded-lg w-full" />
                              {isLoadingScan && (
                                <div className="absolute inset-0 bg-[#1a1818]/70 backdrop-blur-sm rounded-lg flex flex-col items-center justify-center text-center p-4">
                                    <SparklesIcon className="h-10 w-10 text-[#ff8c00] animate-pulse mb-4" />
                                    <p className="font-semibold text-lg text-[#f5f5f5]">Analyzing Menu...</p>
                                </div>
                              )}
                            </div>

                            <div className="flex flex-col">
                                <div className="flex justify-between items-center mb-4">
                                  <h2 className="text-2xl font-bold text-[#f5f5f5]">Analysis</h2>
                                  <button onClick={resetScanner} className="px-4 py-2 text-sm bg-[#333]/60 text-white rounded-md font-semibold hover:bg-[#444]/60">
                                    Scan Again
                                  </button>
                                </div>
                              
                                {analysisResult && analysisResult.menu_items.length > 0 ? (
                                    <div className="space-y-3 overflow-y-auto max-h-[400px] pr-2">
                                        {analysisResult.menu_items.map((item, index) => (
                                            <div key={index} className="bg-[#1a1818]/50 p-4 rounded-lg animate-fadeIn" style={{ animationDelay: `${index * 100}ms`}}>
                                                <p className="text-xs text-[#a3a3a3]/60 uppercase">{item.item_name}</p>
                                                <h3 className="text-lg font-bold text-[#ff8c00] mt-1">{item.translation}</h3>
                                                <p className="text-sm text-[#f5f5f5]/90 mt-2">{item.description}</p>
                                                <div className="flex items-center gap-2 mt-3 text-xs text-yellow-400 border-t border-[#444] pt-2">
                                                    <FireIcon className="h-4 w-4" />
                                                    <span>~{item.calorie_estimate} kcal</span>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                ) : (
                                    !isLoadingScan && (
                                        <div className="flex-1 flex items-center justify-center text-center bg-[#1a1818]/50 rounded-lg p-4">
                                            <p className="text-[#a3a3a3]/70">{scanError || "No results to show."}</p>
                                        </div>
                                    )
                                )}
                            </div>
                        </div>
                    )}
                  </div>
                )}
            </div>
        </div>
    );
};

export default LanguageHelper;