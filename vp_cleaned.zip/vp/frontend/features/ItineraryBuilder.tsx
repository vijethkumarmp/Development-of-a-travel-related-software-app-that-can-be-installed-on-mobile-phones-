
import React, { useState } from 'react';
import { Itinerary, ActivityType } from '../types';
import { generateItinerary } from '../services/geminiService';
import { useTrip } from '../context/TripContext';
import { CompassIcon } from '../components/icons/CompassIcon';
import { FoodIcon } from '../components/icons/FoodIcon';
import { CameraIcon } from '../components/icons/CameraIcon';
import { TravelIcon } from '../components/icons/TravelIcon';
import { AccommodationIcon } from '../components/icons/AccommodationIcon';
import { ShoppingIcon } from '../components/icons/ShoppingIcon';
import { EntertainmentIcon } from '../components/icons/EntertainmentIcon';
import { DefaultActivityIcon } from '../components/icons/DefaultActivityIcon';
import { LocationPinIcon } from '../components/icons/LocationPinIcon';
import { ShareIcon } from '../components/icons/ShareIcon';


const ItineraryBuilder: React.FC = () => {
  const { members } = useTrip();
  const [destination, setDestination] = useState('');
  const [duration, setDuration] = useState('');
  const [interests, setInterests] = useState('');
  const [preferences, setPreferences] = useState('');
  const [itinerary, setItinerary] = useState<Itinerary | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeDay, setActiveDay] = useState<number | null>(null);
  
  // State for the sharing modal
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [shareEmails, setShareEmails] = useState('');
  const [selectedMemberIds, setSelectedMemberIds] = useState<number[]>([]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!destination || !duration || !interests) {
      setError('Please fill out destination, duration, and interests.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setItinerary(null);
    setActiveDay(null);

    const result = await generateItinerary(destination, duration, interests, preferences);
    setIsLoading(false);
    if (result) {
      setItinerary(result);
      setActiveDay(1);
    } else {
      setError('Failed to generate itinerary. Please try again.');
    }
  };
  
  const handleToggleMember = (memberId: number) => {
    setSelectedMemberIds(prev =>
      prev.includes(memberId)
        ? prev.filter(id => id !== memberId)
        : [...prev, memberId]
    );
  };
  
  const handleSendInvites = () => {
    // In a real app, this would trigger a backend service to send emails.
    const memberEmails = members.filter(m => selectedMemberIds.includes(m.id)).map(m => `${m.name.toLowerCase().replace(' ', '.')}@tripbro.app`);
    const additionalEmails = shareEmails.split(',').map(e => e.trim()).filter(e => e);
    const allEmails = [...new Set([...memberEmails, ...additionalEmails])]; // Use Set to avoid duplicates
    
    if (allEmails.length === 0) {
        alert("Please select members or enter email addresses to share.");
        return;
    }

    console.log("Sharing itinerary with:", allEmails);
    // Here we would format the itinerary text or generate a shareable link.
    // For this demo, we'll just show a confirmation.
    alert(`Itinerary shared with: ${allEmails.join(', ')}`);
    
    // Close modal and reset state
    setIsShareModalOpen(false);
    setShareEmails('');
    setSelectedMemberIds([]);
  };

  const getActivityIcon = (type: ActivityType | string) => {
    const iconProps = { className: "h-4 w-4 text-white" };
    switch (type) {
      case 'Food':
        return <FoodIcon {...iconProps} />;
      case 'Sightseeing':
        return <CameraIcon {...iconProps} />;
      case 'Travel':
        return <TravelIcon {...iconProps} />;
      case 'Accommodation':
        return <AccommodationIcon {...iconProps} />;
      case 'Shopping':
        return <ShoppingIcon {...iconProps} />;
      case 'Entertainment':
        return <EntertainmentIcon {...iconProps} />;
      default:
        return <DefaultActivityIcon {...iconProps} />;
    }
  };
  
  const SkeletonLoader = () => (
    <div className="mt-8 animate-pulse">
      <div className="h-8 bg-[#333]/50 rounded-md w-3/4 mb-4"></div>
      <div className="space-y-4">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="p-4 border border-[#444] rounded-lg">
            <div className="h-6 bg-[#333]/50 rounded-md w-1/2 mb-3"></div>
            <div className="h-4 bg-[#333]/50 rounded-md w-full mb-2"></div>
            <div className="h-4 bg-[#333]/50 rounded-md w-5/6"></div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <CompassIcon className="h-12 w-12 mx-auto text-[#ff8c00] mb-2"/>
        <h1 className="text-4xl font-bold text-[#f5f5f5]">Smart Itinerary Builder</h1>
        <p className="mt-2 text-lg text-[#a3a3a3]/70">Describe your dream trip, and let our AI craft the perfect plan for you.</p>
      </div>

      <form onSubmit={handleSubmit} className="solaris-panel p-6 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="destination" className="block text-sm font-medium text-[#a3a3a3]">Destination</label>
            <input
              type="text"
              id="destination"
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
              placeholder="e.g., Tokyo, Japan"
              className="mt-1 block w-full bg-[#333]/50 border border-[#444] rounded-md shadow-sm py-2 px-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00] focus:border-[#ff8c00]"
            />
          </div>
          <div>
            <label htmlFor="duration" className="block text-sm font-medium text-[#a3a3a3]">Duration (days)</label>
            <input
              type="number"
              id="duration"
              value={duration}
              onChange={(e) => setDuration(e.target.value)}
              placeholder="e.g., 7"
              className="mt-1 block w-full bg-[#333]/50 border border-[#444] rounded-md shadow-sm py-2 px-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00] focus:border-[#ff8c00]"
            />
          </div>
          <div>
            <label htmlFor="interests" className="block text-sm font-medium text-[#a3a3a3]">Interests</label>
            <input
              type="text"
              id="interests"
              value={interests}
              onChange={(e) => setInterests(e.target.value)}
              placeholder="e.g., Food, History, Anime"
              className="mt-1 block w-full bg-[#333]/50 border border-[#444] rounded-md shadow-sm py-2 px-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00] focus:border-[#ff8c00]"
            />
          </div>
           <div>
            <label htmlFor="preferences" className="block text-sm font-medium text-[#a3a3a3]">Preferences (optional)</label>
            <input
              type="text"
              id="preferences"
              value={preferences}
              onChange={(e) => setPreferences(e.target.value)}
              placeholder="e.g., Budget-friendly, Adventurous"
              className="mt-1 block w-full bg-[#333]/50 border border-[#444] rounded-md shadow-sm py-2 px-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00] focus:border-[#ff8c00]"
            />
          </div>
        </div>
        <button
          type="submit"
          disabled={isLoading}
          className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-[#ff8c00] hover:bg-[#e67e00] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#ff8c00] disabled:bg-[#ff8c00]/50 disabled:cursor-not-allowed"
        >
          {isLoading ? 'Generating...' : 'Create My Itinerary'}
        </button>
        {error && <p className="text-red-400 text-sm text-center">{error}</p>}
      </form>

      {isLoading && <SkeletonLoader />}

      {itinerary && (
        <div className="mt-8 solaris-panel p-6 animate-fadeIn">
          <div className="text-center mb-6">
            <h2 className="text-3xl font-bold mb-1">{itinerary.trip_title}</h2>
            <p className="text-[#a3a3a3]/70 mb-4">{itinerary.destination} - {itinerary.duration_days} Days</p>
            <button 
                onClick={() => setIsShareModalOpen(true)}
                className="flex items-center gap-2 mx-auto px-4 py-2 bg-[#ff8c00]/50 text-white rounded-md font-semibold hover:bg-[#ff8c00] transition-colors text-sm"
            >
                <ShareIcon className="h-4 w-4" />
                Share Itinerary
            </button>
          </div>
          
          <div className="space-y-4">
            {itinerary.itinerary_plan.map((day) => (
              <div key={day.day} className="border border-[#444] rounded-lg overflow-hidden">
                <button
                  onClick={() => setActiveDay(activeDay === day.day ? null : day.day)}
                  className="w-full p-4 text-left bg-[#333]/40 hover:bg-[#333]/70 focus:outline-none"
                >
                  <div className="flex justify-between items-center">
                    <h3 className="text-xl font-semibold">Day {day.day}: {day.theme}</h3>
                    <span className={`transform transition-transform duration-300 ${activeDay === day.day ? 'rotate-180' : 'rotate-0'}`}>▼</span>
                  </div>
                </button>
                {activeDay === day.day && (
                  <div className="p-6 bg-[#2c2a2a]/50">
                    <div className="relative border-l-2 border-[#b8860b]/50 ml-3">
                      {day.activities.map((activity, index) => (
                        <div key={index} className="mb-8 pl-10 relative last:mb-2">
                          <div className="absolute -left-[13px] top-1 h-6 w-6 rounded-full bg-[#ff8c00] flex items-center justify-center ring-8 ring-[#2c2a2a]/50">
                            {getActivityIcon(activity.activity_type)}
                          </div>
                          <div>
                            <p className="text-[#ff8c00] font-semibold">{activity.time}</p>
                            <h4 className="font-bold text-lg text-[#f5f5f5] mt-1">{activity.description}</h4>
                            <p className="text-[#a3a3a3]/70 text-sm mt-1">{activity.details}</p>
                            {activity.location && (
                              <p className="text-[#a3a3a3]/50 text-xs mt-2 flex items-center gap-1">
                                <LocationPinIcon className="h-3 w-3 flex-shrink-0" />
                                <span>{activity.location}</span>
                              </p>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {isShareModalOpen && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 animate-fadeIn" onClick={() => setIsShareModalOpen(false)}>
            <div className="bg-[#2c2a2a] border border-[#444] rounded-xl p-8 w-full max-w-md shadow-2xl m-4" onClick={e => e.stopPropagation()}>
                <h2 className="text-2xl font-bold text-[#f5f5f5] mb-6">Share Itinerary</h2>
                
                <div className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-[#a3a3a3] mb-2">Invite Trip Members</label>
                        <div className="flex flex-wrap gap-3 p-2 bg-[#333]/40 rounded-lg">
                            {members.map(member => (
                                <button
                                    key={member.id}
                                    onClick={() => handleToggleMember(member.id)}
                                    className={`flex items-center gap-2 p-2 rounded-lg transition-colors border-2 ${
                                        selectedMemberIds.includes(member.id) 
                                        ? 'bg-[#ff8c00]/20 border-[#ff8c00]' 
                                        : 'bg-[#333]/50 border-transparent hover:bg-[#444]/50'
                                    }`}
                                >
                                    <img className="h-8 w-8 rounded-full" src={`https://i.pravatar.cc/40?u=${member.id}`} alt={member.name}/>
                                    <span className="text-sm font-medium text-[#f5f5f5]">{member.name}</span>
                                </button>
                            ))}
                        </div>
                    </div>

                    <div>
                        <label htmlFor="share-emails" className="block text-sm font-medium text-[#a3a3a3]">Or add emails (comma-separated)</label>
                        <textarea
                            id="share-emails"
                            value={shareEmails}
                            onChange={(e) => setShareEmails(e.target.value)}
                            rows={3}
                            placeholder="friend@example.com, family@example.com"
                            className="mt-1 block w-full bg-[#333]/50 border-[#444] rounded-md py-2 px-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00]"
                        />
                    </div>
                </div>

                <div className="flex justify-end gap-4 pt-6 mt-4 border-t border-[#444]">
                    <button type="button" onClick={() => setIsShareModalOpen(false)} className="px-4 py-2 text-[#a3a3a3] hover:bg-[#333] rounded-md">Cancel</button>
                    <button type="button" onClick={handleSendInvites} className="px-6 py-2 bg-[#ff8c00] text-white rounded-md font-semibold hover:bg-[#e67e00]">Send Invites</button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default ItineraryBuilder;