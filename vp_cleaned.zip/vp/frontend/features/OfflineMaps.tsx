import React, { useState, useEffect } from 'react';
import { MapIcon } from '../components/icons/MapIcon';
import { DownloadIcon } from '../components/icons/DownloadIcon';
import { PlaneIcon } from '../components/icons/PlaneIcon';
import { BuildingIcon } from '../components/icons/BuildingIcon';
import { PhoneIcon } from '../components/icons/PhoneIcon';
import { InfoIcon } from '../components/icons/InfoIcon';
import { OfflineFlight, OfflineHotel, OfflineContact } from '../types';
import { DocumentTextIcon } from '../components/icons/DocumentTextIcon';

const MOCK_FLIGHT_DATA: OfflineFlight = {
  airline: 'VoyageAir',
  flightNumber: 'VA 2042',
  departure: { city: 'San Francisco', code: 'SFO', time: '10:30 AM' },
  arrival: { city: 'Tokyo', code: 'NRT', time: '2:45 PM' },
  gate: 'G9',
  seat: '24A',
};

const MOCK_HOTEL_DATA: OfflineHotel = {
  name: 'Shibuya Grand Hotel',
  address: '2 Chome-24-1 Dogenzaka, Shibuya City, Tokyo',
  checkIn: '3:00 PM',
  checkOut: '11:00 AM',
  confirmationNumber: 'VK-982374',
};

const MOCK_CONTACTS_DATA: OfflineContact[] = [
    { name: 'Local Police', number: '110', type: 'Emergency' },
    { name: 'Ambulance', number: '119', type: 'Emergency' },
    { name: 'US Embassy', number: '+81 3-3224-5000', type: 'Info' },
];

const MOCK_CULTURAL_NOTES = `
- **Bowing:** A slight bow is a common greeting and sign of respect.
- **Tipping:** Tipping is not customary in Japan and can sometimes be considered rude.
- **Shoes:** Be prepared to remove your shoes when entering homes, temples, and some restaurants.
- **Chopsticks:** Never stick chopsticks upright in a bowl of rice.
`;

const AccordionItem: React.FC<{ title: string; Icon: React.FC<any>; children: React.ReactNode }> = ({ title, Icon, children }) => {
    const [isOpen, setIsOpen] = useState(false);
    return (
        <div className="border border-[#444] rounded-lg overflow-hidden">
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="w-full p-4 text-left bg-[#333]/40 hover:bg-[#444]/50 focus:outline-none flex justify-between items-center"
            >
                <div className="flex items-center gap-3">
                    <Icon className="h-5 w-5 text-[#ff8c00]" />
                    <h3 className="text-lg font-semibold text-[#f5f5f5]">{title}</h3>
                </div>
                <span className={`transform transition-transform duration-300 text-[#f5f5f5] ${isOpen ? 'rotate-180' : 'rotate-0'}`}>▼</span>
            </button>
            {isOpen && (
                <div className="p-6 bg-[#1a1818]/50 animate-fadeIn">
                    {children}
                </div>
            )}
        </div>
    );
}

const OfflineMaps: React.FC = () => {
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [isDownloading, setIsDownloading] = useState(false);
  const [isDownloaded, setIsDownloaded] = useState(false);

  useEffect(() => {
    let interval: number;
    if (isDownloading) {
      interval = window.setInterval(() => {
        setDownloadProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            setIsDownloading(false);
            setIsDownloaded(true);
            return 100;
          }
          return prev + 1;
        });
      }, 30);
    }
    return () => clearInterval(interval);
  }, [isDownloading]);

  const handleDownload = () => {
    setIsDownloading(true);
    setDownloadProgress(0);
    setIsDownloaded(false);
  };

  return (
    <div className="max-w-4xl mx-auto animate-fadeIn">
      <div className="text-center mb-8">
        <MapIcon className="h-12 w-12 mx-auto text-[#ff8c00] mb-2"/>
        <h1 className="text-4xl font-bold text-[#f5f5f5]">Offline Everything Mode</h1>
        <p className="mt-2 text-lg text-[#a3a3a3]/70">Your digital failsafe. Download all critical trip info and never be stranded without data.</p>
      </div>
      
      <div className="solaris-panel p-6 mb-8">
        <h2 className="text-2xl font-bold text-[#f5f5f5] mb-2">Tokyo Adventure Trip Kit</h2>
        <p className="text-[#a3a3a3]/70 mb-4">Status: {isDownloaded ? 'Available Offline' : 'Online Only'}</p>
        
        {isDownloading && (
             <div className="w-full bg-[#333]/50 rounded-full h-4 mb-2">
                <div className="bg-[#ff8c00] h-4 rounded-full text-xs text-center text-white transition-all duration-100" style={{ width: `${downloadProgress}%` }}>
                   {downloadProgress > 10 && `${downloadProgress}%`}
                </div>
            </div>
        )}

        {!isDownloading && (
            <button
              onClick={handleDownload}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 border border-transparent rounded-md shadow-sm text-md font-medium text-white bg-[#ff8c00] hover:bg-[#e67e00] disabled:bg-[#ff8c00]/50 disabled:cursor-not-allowed"
            >
              <DownloadIcon className="h-5 w-5" />
              {isDownloaded ? 'Refresh Offline Data' : 'Download for Offline Access'}
            </button>
        )}
      </div>

      {isDownloaded && (
        <div className="space-y-4 animate-fadeIn">
           <AccordionItem title="Trip Summary" Icon={DocumentTextIcon}>
                {/* FLIGHTS */}
                <div className="mb-6">
                    <h4 className="text-lg font-semibold text-[#f5f5f5] mb-3 border-b border-[#444] pb-2 flex items-center gap-2">
                        <PlaneIcon className="h-5 w-5 text-[#ff8c00]" />
                        Flight Details
                    </h4>
                    <div className="bg-[#1a1818]/50 p-4 rounded-lg">
                        <p className="text-sm text-[#ff8c00]">{MOCK_FLIGHT_DATA.airline} - {MOCK_FLIGHT_DATA.flightNumber}</p>
                        <div className="flex items-center gap-4 my-2">
                            <div>
                                <p className="text-xl font-bold">{MOCK_FLIGHT_DATA.departure.code}</p>
                                <p className="text-xs text-[#a3a3a3]/70">{MOCK_FLIGHT_DATA.departure.city}</p>
                            </div>
                            <div className="text-[#a3a3a3]/50">→</div>
                            <div>
                                <p className="text-xl font-bold">{MOCK_FLIGHT_DATA.arrival.code}</p>
                                <p className="text-xs text-[#a3a3a3]/70">{MOCK_FLIGHT_DATA.arrival.city}</p>
                            </div>
                        </div>
                        <div className="flex gap-6 text-sm">
                            <p><span className="text-[#a3a3a3]/70">Gate:</span> {MOCK_FLIGHT_DATA.gate}</p>
                            <p><span className="text-[#a3a3a3]/70">Seat:</span> {MOCK_FLIGHT_DATA.seat}</p>
                        </div>
                    </div>
                </div>

                {/* ACCOMMODATION */}
                <div className="mb-6">
                    <h4 className="text-lg font-semibold text-[#f5f5f5] mb-3 border-b border-[#444] pb-2 flex items-center gap-2">
                        <BuildingIcon className="h-5 w-5 text-[#ff8c00]" />
                        Accommodation
                    </h4>
                    <div className="bg-[#1a1818]/50 p-4 rounded-lg">
                        <h5 className="text-md font-bold">{MOCK_HOTEL_DATA.name}</h5>
                        <p className="text-sm text-[#a3a3a3]/70">{MOCK_HOTEL_DATA.address}</p>
                        <div className="mt-2 pt-2 border-t border-[#444]/50">
                            <p className="text-xs text-[#a3a3a3]/60">Confirmation #</p>
                            <p className="font-mono text-sm text-[#ff8c00]">{MOCK_HOTEL_DATA.confirmationNumber}</p>
                        </div>
                    </div>
                </div>
                
                {/* CONTACTS */}
                <div className="mb-6">
                    <h4 className="text-lg font-semibold text-[#f5f5f5] mb-3 border-b border-[#444] pb-2 flex items-center gap-2">
                        <PhoneIcon className="h-5 w-5 text-[#ff8c00]" />
                        Key Contacts
                    </h4>
                    <ul className="space-y-2">
                        {MOCK_CONTACTS_DATA.map(contact => (
                            <li key={contact.name} className="flex justify-between items-center bg-[#1a1818]/50 p-2 rounded-md">
                                <div>
                                    <p className="font-semibold text-sm">{contact.name}</p>
                                    <p className={`text-xs ${contact.type === 'Emergency' ? 'text-red-400' : 'text-[#a3a3a3]/70'}`}>{contact.type}</p>
                                </div>
                                <p className="font-mono text-sm text-[#ff8c00]">{contact.number}</p>
                            </li>
                        ))}
                    </ul>
                </div>

                {/* CULTURAL NOTES */}
                <div>
                    <h4 className="text-lg font-semibold text-[#f5f5f5] mb-3 border-b border-[#444] pb-2 flex items-center gap-2">
                        <InfoIcon className="h-5 w-5 text-[#ff8c00]" />
                        Cultural Notes
                    </h4>
                    <div className="prose prose-invert prose-sm text-[#f5f5f5]/90 whitespace-pre-wrap p-2">
                        {MOCK_CULTURAL_NOTES}
                    </div>
                </div>
           </AccordionItem>
           <AccordionItem title="Flight Tickets" Icon={PlaneIcon}>
              <div className="bg-[#1a1818]/50 p-6 rounded-lg flex items-center gap-6">
                <div className="flex-shrink-0 bg-white p-2 rounded-md">
                    <img src="https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=FlightVA2042-Doe" alt="QR Code" />
                </div>
                <div>
                    <p className="text-sm text-[#ff8c00]">{MOCK_FLIGHT_DATA.airline} - {MOCK_FLIGHT_DATA.flightNumber}</p>
                    <div className="flex items-center gap-4 my-2">
                        <div>
                            <p className="text-2xl font-bold">{MOCK_FLIGHT_DATA.departure.code}</p>
                            <p className="text-sm text-[#a3a3a3]/70">{MOCK_FLIGHT_DATA.departure.city}</p>
                        </div>
                         <div className="text-[#a3a3a3]/50">→</div>
                        <div>
                            <p className="text-2xl font-bold">{MOCK_FLIGHT_DATA.arrival.code}</p>
                            <p className="text-sm text-[#a3a3a3]/70">{MOCK_FLIGHT_DATA.arrival.city}</p>
                        </div>
                    </div>
                     <div className="flex gap-6 text-sm">
                        <p><span className="text-[#a3a3a3]/70">Gate:</span> {MOCK_FLIGHT_DATA.gate}</p>
                        <p><span className="text-[#a3a3a3]/70">Seat:</span> {MOCK_FLIGHT_DATA.seat}</p>
                     </div>
                </div>
              </div>
           </AccordionItem>
           
           <AccordionItem title="Hotel Confirmation" Icon={BuildingIcon}>
                <h3 className="text-xl font-bold">{MOCK_HOTEL_DATA.name}</h3>
                <p className="text-[#a3a3a3]/70">{MOCK_HOTEL_DATA.address}</p>
                <div className="grid grid-cols-2 gap-4 mt-4 text-sm">
                    <div><p className="text-[#a3a3a3]/60">Check-in</p><p>{MOCK_HOTEL_DATA.checkIn}</p></div>
                    <div><p className="text-[#a3a3a3]/60">Check-out</p><p>{MOCK_HOTEL_DATA.checkOut}</p></div>
                </div>
                <div className="mt-4 pt-4 border-t border-[#444]">
                    <p className="text-[#a3a3a3]/60 text-sm">Confirmation #</p>
                    <p className="font-mono text-[#ff8c00]">{MOCK_HOTEL_DATA.confirmationNumber}</p>
                </div>
           </AccordionItem>

           <AccordionItem title="Key Contacts" Icon={PhoneIcon}>
              <ul className="space-y-3">
                {MOCK_CONTACTS_DATA.map(contact => (
                    <li key={contact.name} className="flex justify-between items-center bg-[#1a1818]/50 p-3 rounded-md">
                        <div>
                            <p className="font-semibold">{contact.name}</p>
                            <p className={`text-xs ${contact.type === 'Emergency' ? 'text-red-400' : 'text-[#a3a3a3]/70'}`}>{contact.type}</p>
                        </div>
                        <p className="font-mono text-[#ff8c00]">{contact.number}</p>
                    </li>
                ))}
              </ul>
           </AccordionItem>

           <AccordionItem title="Cultural Notes" Icon={InfoIcon}>
                <div className="prose prose-invert prose-sm text-[#f5f5f5]/90 whitespace-pre-wrap">
                    {MOCK_CULTURAL_NOTES}
                </div>
           </AccordionItem>
        </div>
      )}

    </div>
  );
};

export default OfflineMaps;