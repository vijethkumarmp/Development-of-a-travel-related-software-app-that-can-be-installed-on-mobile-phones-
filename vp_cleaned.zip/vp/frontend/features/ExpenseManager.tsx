import React, { useState, useMemo, FC, useEffect, useRef } from 'react';
import { SimplifiedDebt, ExpenseCategory } from '../types';
import { categorizeExpense } from '../services/geminiService';
import { useTrip } from '../context/TripContext';
import { CreditCardIcon } from '../components/icons/CreditCardIcon';
import { UserIcon } from '../components/icons/UserIcon';
import { FoodIcon } from '../components/icons/FoodIcon';
import { TravelIcon } from '../components/icons/TravelIcon';
import { AccommodationIcon } from '../components/icons/AccommodationIcon';
import { EntertainmentIcon } from '../components/icons/EntertainmentIcon';
import { ShoppingIcon } from '../components/icons/ShoppingIcon';
import { DefaultActivityIcon } from '../components/icons/DefaultActivityIcon';
import { LockClosedIcon } from '../components/icons/LockClosedIcon';
import { CheckCircleIcon } from '../components/icons/CheckCircleIcon';
import { ExclamationCircleIcon } from '../components/icons/ExclamationCircleIcon';
import { VisaIcon } from '../components/icons/VisaIcon';
import { MastercardIcon } from '../components/icons/MastercardIcon';
import { AmexIcon } from '../components/icons/AmexIcon';
import { ChipIcon } from '../components/icons/ChipIcon';
import { WifiIcon } from '../components/icons/WifiIcon';
import { QrCodeIcon } from '../components/icons/QrCodeIcon';
import { ArrowRightIcon } from '../components/icons/ArrowRightIcon';


const EXPENSE_CATEGORIES: ExpenseCategory[] = ['Food', 'Transport', 'Accommodation', 'Activities', 'Shopping', 'Other'];
const SUPPORTED_CURRENCIES = ['USD', 'EUR', 'JPY', 'GBP', 'CAD', 'AUD'];

const CATEGORY_COLORS: { [key in ExpenseCategory]: string } = {
    Food: '#ff8c00', // amber-500
    Transport: '#818cf8', // indigo-400
    Accommodation: '#a78bfa', // violet-400
    Activities: '#f472b6', // pink-400
    Shopping: '#4ade80', // green-400
    Other: '#94a3b8', // slate-400
};

const getCategoryIcon = (category: ExpenseCategory) => {
  const props = { className: "h-5 w-5 text-[#ff8c00]" };
  switch(category) {
    case 'Food': return <FoodIcon {...props} />;
    case 'Transport': return <TravelIcon {...props} />;
    case 'Accommodation': return <AccommodationIcon {...props} />;
    case 'Activities': return <EntertainmentIcon {...props} />;
    case 'Shopping': return <ShoppingIcon {...props} />;
    default: return <DefaultActivityIcon {...props} />;
  }
};

const ExpenseManager: FC = () => {
  const { members, expenses, addMember, addExpense: contextAddExpense } = useTrip();
  const [newMemberName, setNewMemberName] = useState('');
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newExpense, setNewExpense] = useState({
    description: '',
    amount: '',
    currency: 'USD',
    paidBy: members[0]?.id || 1,
    splitBetween: members.map(m => m.id),
    category: 'Other' as ExpenseCategory,
  });
  const [isBalanceUpdating, setIsBalanceUpdating] = useState(false);
  const [isCategorizing, setIsCategorizing] = useState(false);
  const [baseCurrency, setBaseCurrency] = useState('USD');
  const [rates, setRates] = useState<{[key: string]: number} | null>(null);
  const [ratesStatus, setRatesStatus] = useState<string>("Loading live exchange rates...");

  const [paymentModalState, setPaymentModalState] = useState<{ isOpen: boolean; debt: SimplifiedDebt | null }>({ isOpen: false, debt: null });
  const [paymentStatus, setPaymentStatus] = useState<'idle' | 'processing' | 'success' | 'error'>('idle');

  const debounceTimeoutRef = useRef<number | null>(null);
  
  useEffect(() => {
    const fetchRates = async () => {
      const MOCK_RATES_FALLBACK = { USD: 1, EUR: 0.92, JPY: 157.23, GBP: 0.79, CAD: 1.37, AUD: 1.50 };
      try {
        const response = await fetch(`https://api.frankfurter.app/latest?from=USD&to=${SUPPORTED_CURRENCIES.join(',')}`);
        if (!response.ok) throw new Error('Network response was not ok');
        const data = await response.json();
        setRates({ ...data.rates, USD: 1 });
        setRatesStatus(`Live rates from ${data.date}`);
      } catch (error) {
        console.error("Failed to fetch exchange rates:", error);
        setRatesStatus("Using fallback rates. Live data unavailable.");
        setRates(MOCK_RATES_FALLBACK);
      }
    };
    fetchRates();
  }, []);

  useEffect(() => {
    if (debounceTimeoutRef.current) {
      clearTimeout(debounceTimeoutRef.current);
    }
    if (newExpense.description.length > 3) {
      setIsCategorizing(true);
      debounceTimeoutRef.current = window.setTimeout(async () => {
        const category = await categorizeExpense(newExpense.description, expenses);
        if (category) {
          setNewExpense(prev => ({ ...prev, category }));
        }
        setIsCategorizing(false);
      }, 800);
    } else {
      setIsCategorizing(false);
    }
  }, [newExpense.description, expenses]);

  const handleAddMember = (e: React.FormEvent) => {
    e.preventDefault();
    addMember(newMemberName);
    setNewMemberName('');
  };

  const openModal = () => {
    setNewExpense({
      description: '',
      amount: '',
      currency: baseCurrency,
      paidBy: members[0]?.id || 1,
      splitBetween: members.map(m => m.id),
      category: 'Other' as ExpenseCategory,
    });
    setIsModalOpen(true);
  };

  const handleSplitChange = (memberId: number) => {
    const currentSplit = newExpense.splitBetween;
    if (currentSplit.includes(memberId)) {
      if (currentSplit.length > 1) { 
        setNewExpense({ ...newExpense, splitBetween: currentSplit.filter(id => id !== memberId) });
      }
    } else {
      setNewExpense({ ...newExpense, splitBetween: [...currentSplit, memberId] });
    }
  };
  
  const handleAddExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newExpense.description || !newExpense.amount || !newExpense.paidBy || newExpense.splitBetween.length === 0) return;

    contextAddExpense({
      description: newExpense.description,
      amount: parseFloat(newExpense.amount),
      currency: newExpense.currency,
      paidBy: newExpense.paidBy,
      splitBetween: newExpense.splitBetween,
      category: newExpense.category,
    });

    setIsBalanceUpdating(true);
    setTimeout(() => setIsBalanceUpdating(false), 800);

    setIsModalOpen(false);
  };
  
  const handleSettleDebt = (debt: SimplifiedDebt) => {
    setPaymentModalState({ isOpen: true, debt });
    setPaymentStatus('idle');
  };
  
  const getMemberName = (id: number) => members.find(m => m.id === id)?.name || 'Unknown';
  
  const handlePayment = async () => {
    setPaymentStatus('processing');
    await new Promise(resolve => setTimeout(resolve, 2000));
    const isSuccess = Math.random() > 0.1; // 90% success rate

    if (isSuccess && paymentModalState.debt) {
        contextAddExpense({
            description: `Settlement: ${getMemberName(paymentModalState.debt.from)} to ${getMemberName(paymentModalState.debt.to)}`,
            amount: paymentModalState.debt.amount,
            currency: baseCurrency,
            paidBy: paymentModalState.debt.from,
            splitBetween: [paymentModalState.debt.to],
            category: 'Other',
        });
        setPaymentStatus('success');
        setTimeout(() => {
            setPaymentModalState({ isOpen: false, debt: null });
        }, 1500);
    } else {
        setPaymentStatus('error');
    }
  };

  const convertCurrency = (amount: number, from: string, to: string, currentRates: {[key: string]: number}) => {
    if (!currentRates) return amount;
    const amountInUSD = amount / currentRates[from];
    return amountInUSD * currentRates[to];
  };

  const { memberBalances, simplifiedDebts, categorySpending, memberSpending } = useMemo(() => {
    if (!rates) return { memberBalances: [], simplifiedDebts: [], categorySpending: {}, memberSpending: [] };

    const memberDetails: { [key: number]: { name: string; paid: number; share: number; balance: number } } = {};
    members.forEach(member => {
        memberDetails[member.id] = { name: member.name, paid: 0, share: 0, balance: 0 };
    });

    const categoryTotals: { [key in ExpenseCategory]?: number } = {};
    
    expenses.forEach(expense => {
        const convertedAmount = convertCurrency(expense.amount, expense.currency, baseCurrency, rates);

        if (memberDetails[expense.paidBy]) {
            memberDetails[expense.paidBy].paid += convertedAmount;
        }

        categoryTotals[expense.category] = (categoryTotals[expense.category] || 0) + convertedAmount;

        const sharePerPerson = convertedAmount / expense.splitBetween.length;
        expense.splitBetween.forEach(memberId => {
            if (memberDetails[memberId]) {
                memberDetails[memberId].share += sharePerPerson;
            }
        });
    });

    const balances: { [key: number]: number } = {};
    members.forEach(member => {
        if (memberDetails[member.id]) {
            const balance = memberDetails[member.id].paid - memberDetails[member.id].share;
            memberDetails[member.id].balance = balance;
            balances[member.id] = balance;
        }
    });

    const debtors: { id: number; amount: number }[] = [];
    const creditors: { id: number; amount: number }[] = [];

    Object.entries(balances).forEach(([id, amount]) => {
        if (amount > 0.01) creditors.push({ id: Number(id), amount });
        if (amount < -0.01) debtors.push({ id: Number(id), amount: -amount });
    });

    creditors.sort((a, b) => b.amount - a.amount);
    debtors.sort((a, b) => b.amount - a.amount);

    const debts: SimplifiedDebt[] = [];
    let i = 0, j = 0;
    while (i < creditors.length && j < debtors.length) {
        const credit = creditors[i];
        const debt = debtors[j];
        const amount = Math.min(credit.amount, debt.amount);
        
        if (amount > 0.01) {
            debts.push({ from: debt.id, to: credit.id, amount });
        }

        credit.amount -= amount;
        debt.amount -= amount;

        if (credit.amount < 0.01) i++;
        if (debt.amount < 0.01) j++;
    }

    const memberSpendingData = members.map(m => ({ name: m.name, paid: memberDetails[m.id].paid }));

    return { memberBalances: Object.values(memberDetails), simplifiedDebts: debts, categorySpending: categoryTotals, memberSpending: memberSpendingData };
  }, [expenses, members, baseCurrency, rates]);

  const formatCurrency = (amount: number, currency: string) => {
    return new Intl.NumberFormat(undefined, { style: 'currency', currency }).format(amount);
  };

  const DonutChart = ({ data }: { data: { [key: string]: number }}) => {
    const total = Object.values(data).reduce((sum, val) => sum + val, 0);
    if (total === 0) return <div className="flex items-center justify-center h-48 text-[#a3a3a3]/70">No spending data yet.</div>;
    
    let cumulative = 0;
    const segments = Object.entries(data).map(([key, value]) => {
      const percent = value / total;
      const startAngle = cumulative * 360;
      cumulative += percent;
      const endAngle = cumulative * 360;
      return { key, value, percent, startAngle, endAngle, color: CATEGORY_COLORS[key as ExpenseCategory] };
    });

    return (
      <div className="flex items-center gap-6">
        <svg viewBox="0 0 100 100" className="w-48 h-48 -rotate-90">
          {segments.map(s => (
            <circle
              key={s.key}
              cx="50" cy="50" r="40"
              fill="transparent"
              stroke={s.color}
              strokeWidth="20"
              strokeDasharray={`${s.percent * 2 * Math.PI * 40} ${2 * Math.PI * 40}`}
              transform={`rotate(${s.startAngle} 50 50)`}
            />
          ))}
        </svg>
        <div className="space-y-2">
          {segments.map(s => (
            <div key={s.key} className="flex items-center gap-2 text-sm">
              <div className="h-3 w-3 rounded-sm" style={{ backgroundColor: s.color }}></div>
              <span className="text-[#a3a3a3] font-medium">{s.key}</span>
              <span className="text-[#a3a3a3]/70 ml-auto">{(s.percent * 100).toFixed(0)}%</span>
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="max-w-7xl mx-auto animate-fadeIn">
      <div className="text-center mb-8">
        <CreditCardIcon className="h-12 w-12 mx-auto text-[#ff8c00] mb-2"/>
        <h1 className="text-4xl font-bold text-[#f5f5f5]">Advanced Expense Manager</h1>
        <div className="mt-4 flex justify-center items-center gap-2">
            <label htmlFor="base-currency" className="text-[#a3a3a3]/70">Trip Base Currency:</label>
            <select
                id="base-currency"
                value={baseCurrency}
                onChange={e => setBaseCurrency(e.target.value)}
                className="bg-[#333]/50 border border-[#444] rounded-md py-1 px-2 text-[#f5f5f5] font-semibold"
            >
                {SUPPORTED_CURRENCIES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
        </div>
        <p className="text-center text-xs text-[#a3a3a3]/60 mt-2">{ratesStatus}</p>
      </div>
      
       <div className="mb-8 p-6 solaris-panel">
          <h2 className="text-2xl font-semibold text-[#f5f5f5] mb-4">Spending Overview</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div>
                  <h3 className="text-lg font-semibold text-[#f5f5f5] mb-2">Spending by Category</h3>
                  <DonutChart data={categorySpending as {[key: string]: number}} />
              </div>
              <div>
                  <h3 className="text-lg font-semibold text-[#f5f5f5] mb-4">Spending by Member</h3>
                  <div className="space-y-3">
                      {memberSpending.map(m => {
                          const maxPaid = Math.max(...memberSpending.map(ms => ms.paid), 1);
                          const widthPercent = (m.paid / maxPaid) * 100;
                          return (
                              <div key={m.name} className="flex items-center gap-3">
                                  <span className="w-16 text-sm text-[#a3a3a3] truncate">{m.name}</span>
                                  <div className="flex-1 bg-[#333]/50 rounded-full h-6">
                                      <div className="bg-[#ff8c00] h-6 rounded-full text-xs text-white flex items-center px-2 transition-all duration-500" style={{ width: `${widthPercent}%` }}>
                                         {formatCurrency(m.paid, baseCurrency)}
                                      </div>
                                  </div>
                              </div>
                          )
                      })}
                  </div>
              </div>
          </div>
      </div>


      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 space-y-6">
          <div className="solaris-panel p-6">
             <h3 className="text-xl font-semibold text-[#f5f5f5] mb-4">Trip Group</h3>
              <ul className="space-y-3 mb-4">
                {members.map(member => (
                  <li key={member.id} className="flex items-center bg-[#333]/40 p-2 rounded-md">
                    <UserIcon className="h-5 w-5 mr-3 text-[#a3a3a3]/70" />
                    <span className="text-[#f5f5f5]">{member.name}</span>
                  </li>
                ))}
              </ul>
              <form onSubmit={handleAddMember} className="flex gap-2">
                <input
                  type="text"
                  value={newMemberName}
                  onChange={(e) => setNewMemberName(e.target.value)}
                  placeholder="New member name..."
                  className="flex-grow bg-[#333]/50 border border-[#444] rounded-md py-1.5 px-3 text-[#f5f5f5] focus:outline-none focus:ring-1 focus:ring-[#ff8c00]"
                />
                <button type="submit" className="px-3 py-1.5 bg-[#ff8c00] text-white rounded-md font-semibold hover:bg-[#e67e00]">+</button>
              </form>
          </div>
          
          <div className={`solaris-panel p-6 transition-all duration-700 ease-in-out ${isBalanceUpdating ? 'scale-[1.01] ring-2 ring-[#ff8c00]/50' : 'scale-100 ring-0 ring-transparent'}`}>
            <h3 className="text-xl font-semibold text-[#f5f5f5] mb-4">Who Owes Whom</h3>
            {simplifiedDebts.length > 0 ? (
              <ul className="space-y-3">
                {simplifiedDebts.map((debt, i) => (
                  <li key={`${debt.from}-${debt.to}`} className="bg-[#333]/40 p-3 rounded-md animate-fadeIn flex items-center justify-between" style={{ animationDelay: `${i*100}ms`}}>
                    <div className="flex items-center gap-2 text-base">
                      <span className="font-bold text-red-400">{getMemberName(debt.from)}</span>
                      <span className="text-[#a3a3a3]/50 font-sans">→</span>
                      <span className="font-bold text-green-400">{getMemberName(debt.to)}</span>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="text-base font-mono font-semibold text-[#f5f5f5]">{formatCurrency(debt.amount, baseCurrency)}</span>
                      <button onClick={() => handleSettleDebt(debt)} className="px-3 py-1 bg-green-600 text-white text-xs font-semibold rounded-md hover:bg-green-700 transition-colors">Settle Up</button>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-[#a3a3a3]/70">All settled up!</p>
            )}
          </div>

        </div>

        <div className="lg:col-span-2">
          <div className="solaris-panel p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-semibold text-[#f5f5f5]">Transaction History</h3>
              <button onClick={openModal} className="px-4 py-2 bg-[#ff8c00] text-white rounded-md font-semibold hover:bg-[#e67e00] transition-colors">
                Add Expense
              </button>
            </div>
            <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
              {expenses.map((expense, i) => (
                <div key={expense.id} className="flex items-center gap-4 p-4 bg-[#333]/40 rounded-lg animate-fadeIn" style={{ animationDelay: `${i*50}ms`}}>
                  <div className="h-10 w-10 flex-shrink-0 bg-[#ff8c00]/10 rounded-full flex items-center justify-center">
                    {getCategoryIcon(expense.category)}
                  </div>
                  <div className="flex-grow min-w-0">
                    <p className="font-bold text-lg text-[#f5f5f5] truncate">{expense.description}</p>
                    <p className="text-xs text-[#a3a3a3]/60">Paid by <span className="font-medium text-[#a3a3a3]">{getMemberName(expense.paidBy)}</span></p>
                  </div>
                  <div className="text-right flex-shrink-0">
                     <p className="text-lg font-mono font-bold text-[#ff8c00]">{formatCurrency(expense.amount, expense.currency)}</p>
                     {expense.currency !== baseCurrency && rates && (
                        <p className="text-xs text-[#a3a3a3]/70">
                            ({formatCurrency(convertCurrency(expense.amount, expense.currency, baseCurrency, rates), baseCurrency)})
                        </p>
                     )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 animate-fadeIn">
          <div className="bg-[#2c2a2a] border border-[#444] rounded-xl p-8 w-full max-w-md shadow-2xl m-4">
            <h2 className="text-2xl font-bold text-[#f5f5f5] mb-6">Log a New Expense</h2>
            <form onSubmit={handleAddExpense} className="space-y-4">
              <div>
                <label htmlFor="description" className="block text-sm font-medium text-[#a3a3a3]">Description</label>
                <input type="text" id="description" value={newExpense.description} onChange={e => setNewExpense({...newExpense, description: e.target.value})} required className="mt-1 block w-full bg-[#333]/50 border-[#444] rounded-md py-2 px-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00]"/>
              </div>
              <div className="flex gap-4">
                 <div className="flex-grow">
                   <label htmlFor="category" className="block text-sm font-medium text-[#a3a3a3]">Category</label>
                   <div className="relative">
                    <select id="category" value={newExpense.category} onChange={e => setNewExpense({...newExpense, category: e.target.value as ExpenseCategory})} className="mt-1 block w-full bg-[#333]/50 border-[#444] rounded-md py-2 px-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00] appearance-none">
                        {EXPENSE_CATEGORIES.map(cat => (<option key={cat} value={cat}>{cat}</option>))}
                    </select>
                    {isCategorizing && <div className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 border-2 border-t-transparent border-[#ff8c00] rounded-full animate-spin"></div>}
                   </div>
                 </div>
                <div className="w-2/5">
                  <label htmlFor="amount" className="block text-sm font-medium text-[#a3a3a3]">Amount</label>
                  <input type="number" step="0.01" id="amount" value={newExpense.amount} onChange={e => setNewExpense({...newExpense, amount: e.target.value})} required className="mt-1 block w-full bg-[#333]/50 border-[#444] rounded-md py-2 px-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00]"/>
                </div>
                <div className="w-1/4">
                    <label htmlFor="currency" className="block text-sm font-medium text-[#a3a3a3]">Currency</label>
                    <select id="currency" value={newExpense.currency} onChange={e => setNewExpense({...newExpense, currency: e.target.value})} className="mt-1 block w-full bg-[#333]/50 border-[#444] rounded-md py-2 px-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00]">
                        {SUPPORTED_CURRENCIES.map(c => (<option key={c} value={c}>{c}</option>))}
                    </select>
                </div>
              </div>
              <div>
                 <label htmlFor="paidBy" className="block text-sm font-medium text-[#a3a3a3]">Paid By</label>
                 <select id="paidBy" value={newExpense.paidBy} onChange={e => setNewExpense({...newExpense, paidBy: Number(e.target.value)})} className="mt-1 block w-full bg-[#333]/50 border-[#444] rounded-md py-2 px-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00]">
                    {members.map(member => ( <option key={member.id} value={member.id}>{member.name}</option>))}
                 </select>
              </div>
               <div>
                <label className="block text-sm font-medium text-[#a3a3a3] mb-2">Split Between</label>
                <div className="grid grid-cols-2 gap-2 bg-[#1a1818]/50 p-2 rounded-md">
                  {members.map(member => (
                    <label key={member.id} className="flex items-center bg-[#333]/50 p-2 rounded-md cursor-pointer hover:bg-[#444]/50">
                      <input
                        type="checkbox"
                        checked={newExpense.splitBetween.includes(member.id)}
                        onChange={() => handleSplitChange(member.id)}
                        className="h-4 w-4 bg-[#333]/50 border-[#444] rounded text-[#ff8c00] focus:ring-[#ff8c00] cursor-pointer"
                      />
                      <span className="ml-3 text-[#f5f5f5] text-sm">{member.name}</span>
                    </label>
                  ))}
                </div>
              </div>
              <div className="flex justify-end gap-4 pt-4">
                <button type="button" onClick={() => setIsModalOpen(false)} className="px-4 py-2 text-[#a3a3a3] hover:bg-[#333] rounded-md">Cancel</button>
                <button type="submit" className="px-6 py-2 bg-[#ff8c00] text-white rounded-md font-semibold hover:bg-[#e67e00]">Add</button>
              </div>
            </form>
          </div>
        </div>
      )}
      <PaymentGatewayModal
        isOpen={paymentModalState.isOpen}
        onClose={() => setPaymentModalState({isOpen: false, debt: null})}
        debt={paymentModalState.debt}
        baseCurrency={baseCurrency}
        onPayment={handlePayment}
        status={paymentStatus}
        setPaymentStatus={setPaymentStatus}
        getMemberName={getMemberName}
      />
    </div>
  );
};

const getCardType = (cardNumber: string): 'visa' | 'mastercard' | 'amex' | null => {
    const cleaned = cardNumber.replace(/\s+/g, '');
    if (/^4/.test(cleaned)) return 'visa';
    if (/^5[1-5]/.test(cleaned)) return 'mastercard';
    if (/^3[47]/.test(cleaned)) return 'amex';
    return null;
};

const CardPreview: React.FC<{
    cardDetails: { number: string; expiry: string; cvc: string; name: string; };
    cardType: 'visa' | 'mastercard' | 'amex' | null;
    isFlipped: boolean;
}> = ({ cardDetails, cardType, isFlipped }) => {
    const cardBgClasses = {
        visa: 'bg-gradient-to-br from-blue-500 to-blue-800',
        mastercard: 'bg-gradient-to-br from-gray-700 to-black',
        amex: 'bg-gradient-to-br from-teal-500 to-green-800',
        default: 'bg-gradient-to-br from-gray-600 to-gray-800'
    };
    const bgClass = cardType ? cardBgClasses[cardType] : cardBgClasses.default;

    return (
        <div className="w-full max-w-sm mx-auto h-48 [perspective:1000px] mb-6">
            <div className={`relative w-full h-full [transform-style:preserve-3d] transition-transform duration-700 ${isFlipped ? '[transform:rotateY(180deg)]' : ''}`}>
                {/* Front */}
                <div className={`absolute w-full h-full [backface-visibility:hidden] rounded-xl p-6 text-white flex flex-col justify-between shadow-lg ${bgClass}`}>
                    <div className="flex justify-between items-start">
                        <ChipIcon className="w-10 h-8" />
                        <WifiIcon className="w-6 h-6 rotate-90" />
                    </div>
                    <div className="font-mono text-xl tracking-widest">
                        {cardDetails.number || '#### #### #### ####'}
                    </div>
                    <div className="flex justify-between items-end text-sm">
                        <div>
                            <p className="text-xs opacity-70">Card Holder</p>
                            <p className="font-medium uppercase">{cardDetails.name || 'FULL NAME'}</p>
                        </div>
                        <div>
                            <p className="text-xs opacity-70">Expires</p>
                            <p className="font-medium">{cardDetails.expiry || 'MM/YY'}</p>
                        </div>
                        <div className="h-8">
                            {cardType === 'visa' && <VisaIcon />}
                            {cardType === 'mastercard' && <MastercardIcon />}
                            {cardType === 'amex' && <AmexIcon />}
                        </div>
                    </div>
                </div>
                {/* Back */}
                <div className={`absolute w-full h-full [backface-visibility:hidden] [transform:rotateY(180deg)] rounded-xl p-2 text-black flex flex-col shadow-lg ${bgClass}`}>
                    <div className="w-full h-10 bg-black mt-4"></div>
                    <div className="bg-gray-200 p-2 mt-4 text-right flex items-center">
                        <p className="flex-grow text-sm italic text-gray-600">Authorized Signature</p>
                        <div className="w-20 h-6 bg-white ml-2 text-black font-mono flex items-center justify-end pr-2">{cardDetails.cvc}</div>
                    </div>
                </div>
            </div>
        </div>
    );
};


const QRScannerView: FC<{ onScanSuccess: () => void; onCancel: () => void; }> = ({ onScanSuccess, onCancel }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [error, setError] = useState<string | null>(null);
  const [statusText, setStatusText] = useState('Point your camera at a QR code...');
  const scanTimeoutRef = useRef<number | null>(null);

  useEffect(() => {
    const startCamera = async () => {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setError("Camera access is not supported by your browser.");
        return;
      }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
        // Simulate scanning process
        scanTimeoutRef.current = window.setTimeout(() => {
          setStatusText('QR Code detected! Processing...');
          scanTimeoutRef.current = window.setTimeout(() => {
            onScanSuccess();
          }, 1500);
        }, 3000);
      } catch (err: any) {
        console.error("Error accessing camera:", err);
        if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
          setError("Camera permission denied. Please enable camera access in your browser settings to scan QR codes.");
        } else {
          setError("Could not access camera. Please check permissions.");
        }
      }
    };
    startCamera();

    return () => {
      if (scanTimeoutRef.current) {
        clearTimeout(scanTimeoutRef.current);
      }
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [onScanSuccess]);

  return (
    <div className="flex flex-col items-center justify-center animate-fadeIn">
      <div className="relative w-full max-w-sm h-64 bg-[#1a1818] rounded-lg overflow-hidden mb-4">
        {error ? (
          <div className="flex items-center justify-center h-full text-red-400 text-center p-4">{error}</div>
        ) : (
          <video ref={videoRef} className="w-full h-full object-cover" autoPlay playsInline />
        )}
        <div className="absolute inset-0 flex items-center justify-center p-4">
            <div className="w-full h-full border-4 border-dashed border-white/50 rounded-lg relative overflow-hidden">
                <div className="absolute top-0 left-1/2 w-full h-1 -translate-x-1/2 bg-red-500/70 shadow-[0_0_10px_2px_#ef4444] animate-scanLine" />
            </div>
        </div>
      </div>
      <p className="text-[#a3a3a3] text-sm mb-6 h-5">{statusText}</p>
      <button onClick={onCancel} className="px-6 py-2 bg-[#333]/80 text-white rounded-md font-semibold hover:bg-[#444]/80">
        Cancel
      </button>
    </div>
  );
};


const PaymentGatewayModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  debt: SimplifiedDebt | null;
  baseCurrency: string;
  onPayment: () => Promise<void>;
  status: 'idle' | 'processing' | 'success' | 'error';
  setPaymentStatus: React.Dispatch<React.SetStateAction<'idle' | 'processing' | 'success' | 'error'>>;
  getMemberName: (id: number) => string;
}> = ({ isOpen, onClose, debt, baseCurrency, onPayment, status, setPaymentStatus, getMemberName }) => {
    
    const [view, setView] = useState<'summary' | 'methodSelection' | 'form' | 'qrScanner'>('summary');
    const [cardDetails, setCardDetails] = useState({ number: '', expiry: '', cvc: '', name: '' });
    const [isCvcFocused, setIsCvcFocused] = useState(false);
    const cardType = getCardType(cardDetails.number);

    useEffect(() => {
        if (isOpen) {
            setCardDetails({ number: '', expiry: '', cvc: '', name: '' });
            setView('summary');
        }
    }, [isOpen]);

    if (!isOpen || !debt) return null;

    const formatCardNumber = (value: string) => {
        const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
        const matches = v.match(/\d{1,16}/g);
        const match = (matches && matches[0]) || '';
        const parts = [];
        for (let i = 0, len = match.length; i < len; i += 4) {
            parts.push(match.substring(i, i + 4));
        }
        return parts.length > 0 ? parts.join(' ') : value;
    };
    
    const formatExpiry = (value: string) => {
        return value.replace(/[^0-9]/g, '').replace(/^([2-9])$/, '0$1').replace(/^(1[3-9])$/, '01/$1').replace(/^0{2,}/, '0').replace(/^([0-1])([0-9])/, '$1$2/').replace(/^([0-1][0-9])([0-9]{2}).*/, '$1/$2');
    }

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        let { name, value } = e.target;
        if (name === 'number') value = formatCardNumber(value);
        if (name === 'expiry') value = formatExpiry(value);
        if (name === 'cvc' && value.length > 4) value = value.slice(0, 4);
        setCardDetails(prev => ({ ...prev, [name]: value }));
    };

    const renderContent = () => {
        switch (status) {
            case 'processing':
                return (
                    <div className="flex flex-col items-center justify-center h-full min-h-[350px]">
                        <div className="h-12 w-12 border-4 border-t-transparent border-[#ff8c00] rounded-full animate-spin"></div>
                        <p className="mt-4 text-[#a3a3a3]">Processing payment...</p>
                    </div>
                );
            case 'success':
                return (
                     <div className="flex flex-col items-center justify-center h-full min-h-[350px] text-center">
                        <CheckCircleIcon className="h-16 w-16 text-green-400 mb-4" />
                        <h3 className="text-xl font-bold text-[#f5f5f5]">Payment Successful!</h3>
                        <p className="text-[#a3a3a3]">The balances have been updated.</p>
                    </div>
                );
            case 'error':
                 return (
                     <div className="flex flex-col items-center justify-center h-full min-h-[350px] text-center">
                        <ExclamationCircleIcon className="h-16 w-16 text-red-400 mb-4" />
                        <h3 className="text-xl font-bold text-[#f5f5f5]">Payment Failed</h3>
                        <p className="text-[#a3a3a3] mb-4">Please check your details and try again.</p>
                        <button onClick={() => { setPaymentStatus('idle'); setView('methodSelection'); }} className="px-4 py-2 bg-[#ff8c00] text-white rounded-md font-semibold hover:bg-[#e67e00]">Try Again</button>
                    </div>
                );
            case 'idle':
                 if (view === 'summary') {
                    return (
                        <div className="text-center animate-fadeIn flex flex-col items-center justify-center h-full min-h-[350px]">
                            <p className="text-lg text-[#a3a3a3] mb-6">Confirm Transaction</p>
                            <div className="flex items-center justify-between w-full px-4 mb-2">
                                <div className="flex flex-col items-center w-24">
                                    <div className="h-16 w-16 bg-[#333]/50 rounded-full flex items-center justify-center mb-2">
                                        <UserIcon className="h-8 w-8 text-red-400" />
                                    </div>
                                    <p className="text-sm font-semibold text-[#f5f5f5] truncate">{getMemberName(debt.from)}</p>
                                    <p className="text-xs text-[#a3a3a3]/70">Payer</p>
                                </div>
                                <div className="flex-1 flex flex-col items-center text-[#a3a3a3]/50">
                                    <ArrowRightIcon className="h-8 w-8" />
                                </div>
                                <div className="flex flex-col items-center w-24">
                                    <div className="h-16 w-16 bg-[#333]/50 rounded-full flex items-center justify-center mb-2">
                                        <UserIcon className="h-8 w-8 text-green-400" />
                                    </div>
                                    <p className="text-sm font-semibold text-[#f5f5f5] truncate">{getMemberName(debt.to)}</p>
                                    <p className="text-xs text-[#a3a3a3]/70">Payee</p>
                                </div>
                            </div>
                            <p className="text-5xl font-bold text-[#f5f5f5] my-4">{new Intl.NumberFormat(undefined, { style: 'currency', currency: baseCurrency }).format(debt.amount)}</p>
                            <div className="mt-8 w-full">
                                <button onClick={() => setView('methodSelection')} className="w-full py-3 bg-[#ff8c00] text-white rounded-md font-semibold hover:bg-[#e67e00]">
                                    Proceed to Payment
                                </button>
                            </div>
                        </div>
                    );
                } else if (view === 'methodSelection') {
                    return (
                        <div className="text-center animate-fadeIn flex flex-col items-center justify-center h-full min-h-[350px]">
                            <h3 className="text-xl font-semibold text-[#f5f5f5] mb-6">Choose Payment Method</h3>
                            <p className="text-lg text-[#a3a3a3]/70 mb-8">
                                Paying <span className="font-bold text-[#f5f5f5]">{new Intl.NumberFormat(undefined, { style: 'currency', currency: baseCurrency }).format(debt.amount)}</span> to <span className="font-bold text-green-400">{getMemberName(debt.to)}</span>
                            </p>
                            <div className="w-full flex flex-col gap-3">
                                <button onClick={() => setView('form')} className="w-full py-3 bg-[#ff8c00] text-white rounded-md font-semibold hover:bg-[#e67e00] flex items-center justify-center gap-2">
                                    <CreditCardIcon className="h-5 w-5" />
                                    Pay with Card
                                </button>
                                <button onClick={() => setView('qrScanner')} className="w-full py-3 bg-[#333]/60 text-white rounded-md font-semibold hover:bg-[#444]/60 flex items-center justify-center gap-2">
                                    <QrCodeIcon className="h-5 w-5" />
                                    Scan QR Code
                                </button>
                            </div>
                            <button onClick={() => setView('summary')} className="mt-6 px-4 py-2 text-sm text-[#a3a3a3]/70 hover:text-white">
                                Back
                            </button>
                        </div>
                    );
                } else if (view === 'qrScanner') {
                    return <QRScannerView onScanSuccess={onPayment} onCancel={() => setView('methodSelection')} />;
                } else { // form view
                    return (
                        <div className="animate-fadeIn">
                            <div className="flex justify-center items-center gap-3 mb-4 h-10">
                                {[
                                    {type: 'visa', Icon: VisaIcon},
                                    {type: 'mastercard', Icon: MastercardIcon},
                                    {type: 'amex', Icon: AmexIcon},
                                ].map(({type, Icon}) => (
                                    <div key={type} className={`p-1 border-2 rounded-lg transition-all duration-300 ${cardType === type ? 'border-[#ff8c00] scale-110 opacity-100' : 'border-transparent opacity-40'}`}>
                                        <Icon />
                                    </div>
                                ))}
                            </div>
                            <CardPreview cardDetails={cardDetails} cardType={cardType} isFlipped={isCvcFocused} />
                            <form id="payment-form" onSubmit={(e) => { e.preventDefault(); onPayment(); }} className="space-y-3">
                                <div>
                                    <label className="block text-xs font-medium text-[#a3a3a3]/70">Card Number</label>
                                    <input type="text" name="number" value={cardDetails.number} onChange={handleInputChange} placeholder="0000 0000 0000 0000" maxLength={19} required className="mt-1 block w-full bg-[#333]/50 border border-[#444] rounded-md py-2 px-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00]" />
                                </div>
                                <div>
                                <label className="block text-xs font-medium text-[#a3a3a3]/70">Cardholder Name</label>
                                <input type="text" name="name" value={cardDetails.name} onChange={handleInputChange} placeholder="John Doe" required className="mt-1 block w-full bg-[#333]/50 border border-[#444] rounded-md py-2 px-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00]" />
                                </div>
                                <div className="grid grid-cols-2 gap-3">
                                    <div>
                                        <label className="block text-xs font-medium text-[#a3a3a3]/70">Expiry Date</label>
                                        <input type="text" name="expiry" value={cardDetails.expiry} onChange={handleInputChange} placeholder="MM/YY" maxLength={5} required className="mt-1 block w-full bg-[#333]/50 border border-[#444] rounded-md py-2 px-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00]" />
                                    </div>
                                    <div>
                                        <label className="block text-xs font-medium text-[#a3a3a3]/70">CVC</label>
                                        <input type="text" name="cvc" value={cardDetails.cvc} onChange={handleInputChange} placeholder="123" maxLength={4} required className="mt-1 block w-full bg-[#333]/50 border border-[#444] rounded-md py-2 px-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00]" onFocus={() => setIsCvcFocused(true)} onBlur={() => setIsCvcFocused(false)} />
                                    </div>
                                </div>
                            </form>
                            <div className="flex justify-between items-center mt-6">
                                <button onClick={() => setView('methodSelection')} className="px-4 py-2 text-[#a3a3a3] hover:bg-[#333] rounded-md">Back</button>
                                <button type="submit" form="payment-form" className="flex justify-center items-center gap-2 py-3 px-6 bg-green-600 text-white rounded-md font-semibold hover:bg-green-700">
                                <LockClosedIcon className="h-5 w-5" />
                                Pay Now
                                </button>
                            </div>
                        </div>
                    );
                }
        }
    }

    return (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 animate-fadeIn" onClick={onClose}>
            <div className="bg-[#2c2a2a] border border-[#444] rounded-xl p-8 w-full max-w-md shadow-2xl m-4" onClick={e => e.stopPropagation()}>
                <div className="text-center mb-4">
                    <h2 className="text-2xl font-bold text-[#f5f5f5]">Settle Debt</h2>
                    <p className="text-[#a3a3a3]/70 text-sm">
                        from <span className="font-semibold text-red-400">{getMemberName(debt.from)}</span>
                    </p>
                </div>
                {renderContent()}
            </div>
        </div>
    );
};


export default ExpenseManager;