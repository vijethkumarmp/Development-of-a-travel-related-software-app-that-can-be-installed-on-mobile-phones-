
import React from 'react';
import { FEATURES } from '../constants';
import { Feature } from '../types';
import { EtiquetteIcon } from '../components/icons/EtiquetteIcon';

interface DashboardProps {
  setActiveFeature: (feature: Feature) => void;
}

const suggestedFeatures = [
  {
    name: 'Local Etiquette Guide',
    Icon: EtiquetteIcon,
    description: 'Get proactive, location-aware advice on local customs. Know the right way to tip, greet, and show respect wherever you are.'
  },
];


const Dashboard: React.FC<DashboardProps> = ({ setActiveFeature }) => {
  const quickAccessFeatures = FEATURES.filter(f => ['itinerary', 'language', 'souvenir', 'jetlag'].includes(f.id));

  return (
    <div className="animate-fadeIn">
      <div 
        className="bg-cover bg-center h-64 rounded-xl p-8 flex flex-col justify-end text-white" 
        style={{backgroundImage: `linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url(https://picsum.photos/1200/400?random=2)`}}
      >
        <h1 className="text-4xl font-bold">Welcome back, Vijeth!</h1>
        <p className="mt-2 text-lg text-[#f5f5f5]/80">Where will your next adventure take you?</p>
      </div>

      <div className="mt-8">
        <h2 className="text-2xl font-semibold text-[#f5f5f5] mb-4">Quick Tools</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {quickAccessFeatures.map((feature) => (
            <div
              key={feature.id}
              onClick={() => setActiveFeature(feature)}
              className="solaris-panel p-6 cursor-pointer transition-all duration-300 ease-in-out transform hover:-translate-y-1"
            >
              <div className="flex items-center justify-center h-12 w-12 rounded-full bg-[#ff8c00]/10 mb-4">
                <feature.Icon className="h-6 w-6 text-[#ff8c00]" />
              </div>
              <h3 className="text-lg font-semibold text-[#f5f5f5]">{feature.name}</h3>
              <p className="mt-1 text-sm text-[#a3a3a3]/70">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-8">
        <h2 className="text-2xl font-semibold text-[#f5f5f5] mb-4">Recent Trips</h2>
        <div className="solaris-panel p-6">
          <p className="text-[#a3a3a3]/70">You have no recent trips planned. Let's create one!</p>
           <button 
             onClick={() => setActiveFeature(FEATURES.find(f => f.id === 'itinerary')!)}
             className="mt-4 px-4 py-2 bg-[#ff8c00] text-white rounded-md font-semibold hover:bg-[#e67e00] transition-colors"
           >
             Plan a New Trip
           </button>
        </div>
      </div>

      <div className="mt-8">
        <h2 className="text-2xl font-semibold text-[#f5f5f5] mb-4">Feature Spotlight</h2>
        <p className="text-[#a3a3a3]/70 mb-6 max-w-3xl">Explore ideas for the next generation of travel tools. These are concepts for new features we're thinking about building!</p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {suggestedFeatures.map((feature) => (
            <div
              key={feature.name}
              className="solaris-panel p-6 transition-all duration-300 ease-in-out relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 px-2 py-1 bg-[#ff8c00]/20 text-[#ff8c00] text-xs font-bold rounded-bl-lg">
                CONCEPT
              </div>
              <div className="flex items-center justify-center h-12 w-12 rounded-full bg-[#ff8c00]/10 mb-4">
                <feature.Icon className="h-6 w-6 text-[#ff8c00]" />
              </div>
              <h3 className="text-lg font-semibold text-[#f5f5f5]">{feature.name}</h3>
              <p className="mt-1 text-sm text-[#a3a3a3]/70">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};

export default Dashboard;