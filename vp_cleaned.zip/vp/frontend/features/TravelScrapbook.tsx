import React, { useMemo, useState } from 'react';
import { VisitedPlace, Booking, JournalEntry, Attachment, FlightBooking, HotelBooking } from '../types';
import { CameraIcon } from '../components/icons/CameraIcon';
import WorldMap from '../components/maps/WorldMap';
import { useTrip } from '../context/TripContext';
import { SparklesIcon } from '../components/icons/SparklesIcon';
import { generateCaptionForImage } from '../services/geminiService';

// --- Geo Calculation Helpers ---
const deg2rad = (deg: number) => {
  return deg * (Math.PI / 180);
};

const getDistanceFromLatLonInKm = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
  const R = 6371; // Radius of the earth in km
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const d = R * c; // Distance in km
  return d;
};

// --- Data Parsing Helpers ---
const getFlightCoords = (flight: FlightBooking): { start: { lat: number, lon: number }, end: { lat: number, lon: number } } | null => {
    // Mock geocoding for flight routes based on IATA codes
    const locations: { [key: string]: { lat: number, lon: number } } = {
        'sfo': { lat: 37.6213, lon: -122.3790 },
        'nrt': { lat: 35.7647, lon: 140.3864 },
    };
    const start = locations[flight.departure.code.toLowerCase()];
    const end = locations[flight.arrival.code.toLowerCase()];
    if (start && end) {
        return { start, end };
    }
    return null;
}

const getBookingPrimaryCity = (booking: Booking): string => {
    // Mock city extraction logic
    try {
        if (booking.type === 'Hotel') return booking.hotelName.split(',').pop()?.trim() || 'Unknown';
        if (booking.type === 'Flight') return booking.arrival.airport.replace(/ Intl$/, '').replace(/ Airport$/, '').trim();
        if (booking.type === 'Activity') return booking.location.split(',').pop()?.trim() || 'Unknown';
        if (booking.type === 'Car Rental') return booking.pickupLocation.split(',')[0].trim();
        if (booking.type === 'Cab') return booking.pickupLocation.split(',')[0].trim();
    } catch (e) {
        return 'Unknown';
    }
    return 'Unknown';
};

const getBookingEndDate = (booking: Booking): Date => {
    switch (booking.type) {
        case 'Flight': return new Date(booking.arrival.dateTime);
        case 'Hotel': return new Date(booking.checkOutDate);
        case 'Car Rental': return new Date(booking.dropoffDateTime);
        case 'Activity': return new Date(booking.date);
        case 'Cab': return new Date(booking.pickupDateTime);
    }
}

const getBookingLocation = (booking: Booking): { name: string, country: string, lat: number, lon: number } => {
    // In a real app, you would geocode the location string. Here we use mock coordinates.
    const locations: { [key: string]: { lat: number, lon: number, country: string } } = {
        'tokyo': { lat: 35.6895, lon: 139.6917, country: 'Japan' },
        'san francisco': { lat: 37.7749, lon: -122.4194, country: 'USA' },
    };
    const locationName = booking.type === 'Hotel' ? booking.hotelName.split(',')[0] : 
                         booking.type === 'Flight' ? booking.arrival.airport :
                         booking.type === 'Activity' ? booking.location : 
                         booking.type === 'Car Rental' ? booking.pickupLocation :
                         booking.type === 'Cab' ? booking.pickupLocation : 'Unknown';
    
    const key = Object.keys(locations).find(k => locationName.toLowerCase().includes(k));
    const geo = key ? locations[key] : { lat: 0, lon: 0, country: 'Unknown' };

    return { name: locationName, country: geo.country, lat: geo.lat, lon: geo.lon };
};

const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
  });
};


const TravelScrapbook: React.FC = () => {
    const { bookings } = useTrip();
    const [selectedTrip, setSelectedTrip] = useState<Booking | null>(null);
    const [journalEntries, setJournalEntries] = useState<Record<number, JournalEntry>>({
        2: { // Pre-populate one entry for demo
            notes: "The view from the hotel was absolutely breathtaking, especially at night. The Shibuya Scramble is a sight to behold!",
            photos: []
        }
    });
    const [isCaptionLoading, setIsCaptionLoading] = useState<string | null>(null);

    const { pastBookings, upcomingBookings, visitedPlaces, stats } = useMemo(() => {
        const now = new Date();
        const past: Booking[] = [];
        const upcoming: Booking[] = [];

        bookings.forEach(b => {
            if (getBookingEndDate(b) < now) {
                past.push(b);
            } else {
                upcoming.push(b);
            }
        });

        const places: VisitedPlace[] = bookings.map(booking => {
            const location = getBookingLocation(booking);
            return {
                name: location.name,
                country: location.country,
                latitude: location.lat,
                longitude: location.lon,
                bookingId: booking.id,
                status: past.some(b => b.id === booking.id) ? 'past' : 'upcoming',
            };
        });
        
        // --- Detailed Stat Calculations ---

        // Total Distance from past flights
        const pastFlights = past.filter(b => b.type === 'Flight') as FlightBooking[];
        const totalDistance = pastFlights.reduce((acc, flight) => {
            const coords = getFlightCoords(flight);
            if (coords) {
                return acc + getDistanceFromLatLonInKm(coords.start.lat, coords.start.lon, coords.end.lat, coords.end.lon);
            }
            return acc;
        }, 0);

        // Unique Cities Visited
        const uniqueCities = new Set(past.map(b => getBookingPrimaryCity(b)).filter(c => c && c !== 'Unknown'));

        // Average Trip Duration from Hotel stays
        const pastHotelBookings = past.filter(b => b.type === 'Hotel') as HotelBooking[];
        const totalTripDays = pastHotelBookings.reduce((acc, hotel) => {
            const checkIn = new Date(hotel.checkInDate);
            const checkOut = new Date(hotel.checkOutDate);
            const duration = (checkOut.getTime() - checkIn.getTime()) / (1000 * 3600 * 24);
            return acc + (duration > 0 ? duration : 0);
        }, 0);
        const avgTripDuration = pastHotelBookings.length > 0 ? totalTripDays / pastHotelBookings.length : 0;
        
        const countriesVisited = new Set(past.map(b => getBookingLocation(b).country).filter(c => c !== 'Unknown'));

        return {
            pastBookings: past,
            upcomingBookings: upcoming,
            visitedPlaces: places,
            stats: {
                trips: pastHotelBookings.length, // A better proxy for trips than all bookings
                countries: countriesVisited.size,
                totalDistance: Math.round(totalDistance),
                cities: uniqueCities.size,
                avgDuration: Math.round(avgTripDuration)
            }
        };
    }, [bookings]);

    const handleSelectTrip = (bookingId: number) => {
        const trip = bookings.find(b => b.id === bookingId);
        if (trip && visitedPlaces.find(p => p.bookingId === bookingId)?.status === 'past') {
            setSelectedTrip(trip);
        } else {
            setSelectedTrip(null);
        }
    };

    const handleJournalChange = (bookingId: number, notes: string) => {
        setJournalEntries(prev => ({
            ...prev,
            [bookingId]: { ...(prev[bookingId] || { notes: '', photos: [] }), notes }
        }));
    };

    const handleAddPhoto = async (bookingId: number, e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files) {
            const file = e.target.files[0];
            const base64 = await fileToBase64(file);
            const newPhoto: Attachment = { name: file.name, type: file.type, data: base64 };
            
            setJournalEntries(prev => {
                const currentEntry = prev[bookingId] || { notes: '', photos: [] };
                return {
                    ...prev,
                    [bookingId]: {
                        ...currentEntry,
                        photos: [...currentEntry.photos, newPhoto]
                    }
                };
            });
        }
    };
    
    const handleGenerateCaption = async (bookingId: number, photo: Attachment) => {
        const photoData = photo.data;
        const mimeType = photo.type;
        const base64Only = photoData.split(',')[1];
        
        if (!base64Only) return;

        setIsCaptionLoading(photoData);

        const caption = await generateCaptionForImage(base64Only, mimeType);

        if (caption) {
          setJournalEntries(prev => {
            const currentEntry = prev[bookingId] || { notes: '', photos: [] };
            const newNotes = currentEntry.notes 
              ? `${currentEntry.notes}\n\n${caption}` 
              : caption;
            return {
              ...prev,
              [bookingId]: { ...currentEntry, notes: newNotes.trim() }
            };
          });
        } else {
          alert("Sorry, I couldn't come up with a caption for this image. Please try again.");
        }

        setIsCaptionLoading(null);
    };

    const StatCard: React.FC<{ value: string | number; label: string }> = ({ value, label }) => (
        <div className="solaris-panel p-6 text-center">
            <p className="text-3xl font-bold text-[#ff8c00]">{value}</p>
            <p className="text-sm text-[#a3a3a3]/70 mt-1">{label}</p>
        </div>
    );
    
    return (
        <div className="max-w-7xl mx-auto animate-fadeIn">
            <div className="text-center mb-8">
                <CameraIcon className="h-12 w-12 mx-auto text-[#ff8c00] mb-2"/>
                <h1 className="text-4xl font-bold text-[#f5f5f5]">Travel Scrapbook</h1>
                <p className="mt-2 text-lg text-[#a3a3a3]/70">Your personalized map of adventures and travel stats.</p>
            </div>

            <div className="grid grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                <StatCard value={stats.trips} label="Trips Taken" />
                <StatCard value={stats.countries} label="Countries Visited" />
                <StatCard value={stats.cities} label="Cities Visited" />
                <StatCard value={`${stats.totalDistance.toLocaleString()} km`} label="Distance Traveled" />
                <StatCard value={stats.avgDuration > 0 ? `${stats.avgDuration} days` : 'N/A'} label="Avg. Trip Duration" />
                <StatCard value={upcomingBookings.length} label="Upcoming Trips" />
            </div>

            <div className="flex flex-col lg:flex-row gap-8">
                 <div className="flex-1 solaris-panel p-4">
                    <WorldMap visitedPlaces={visitedPlaces} onMarkerClick={handleSelectTrip} />
                </div>
                <div className="w-full lg:w-96 flex-shrink-0">
                   <div className="solaris-panel p-6 h-full">
                       <h2 className="text-xl font-bold text-[#f5f5f5] mb-4">Trip Journal</h2>
                       {selectedTrip ? (
                           <div className="animate-fadeIn">
                               <h3 className="text-lg font-semibold text-[#ff8c00]">{getBookingLocation(selectedTrip).name}</h3>
                               <p className="text-sm text-[#a3a3a3]/70 mb-4">{new Date(getBookingEndDate(selectedTrip)).toLocaleDateString()}</p>
                               
                               <label className="text-sm font-medium text-[#a3a3a3]">My Notes</label>
                               <textarea
                                 value={journalEntries[selectedTrip.id]?.notes || ''}
                                 onChange={e => handleJournalChange(selectedTrip.id, e.target.value)}
                                 rows={5}
                                 placeholder="What did you love about this place?"
                                 className="w-full mt-1 bg-[#333]/50 border border-[#444] rounded-md py-2 px-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00]"
                               />

                               <div className="mt-4">
                                   <label className="text-sm font-medium text-[#a3a3a3]">Photos</label>
                                   <div className="grid grid-cols-3 gap-2 mt-2">
                                        {(journalEntries[selectedTrip.id]?.photos || []).map((photo, i) => (
                                            <div key={i} className="relative group">
                                                <img src={photo.data} alt={photo.name} className="w-full h-24 object-cover rounded-md" />
                                                <button 
                                                    onClick={() => handleGenerateCaption(selectedTrip.id, photo)}
                                                    disabled={isCaptionLoading === photo.data}
                                                    className="absolute top-1 right-1 bg-black/50 p-1.5 rounded-full text-[#ff8c00] opacity-0 group-hover:opacity-100 transition-all duration-200 hover:scale-110 disabled:opacity-100 disabled:cursor-not-allowed"
                                                    title="Generate AI Caption"
                                                >
                                                    {isCaptionLoading === photo.data ? (
                                                        <div className="h-4 w-4 border-2 border-t-transparent border-white rounded-full animate-spin" />
                                                    ) : (
                                                        <SparklesIcon className="h-4 w-4" />
                                                    )}
                                                </button>
                                            </div>
                                        ))}
                                       <label className="w-full h-24 bg-[#333]/50 rounded-md flex items-center justify-center cursor-pointer hover:bg-[#444]/50">
                                            <input type="file" accept="image/*" className="hidden" onChange={(e) => handleAddPhoto(selectedTrip.id, e)} />
                                            <span className="text-[#a3a3a3]/70 text-2xl">+</span>
                                       </label>
                                   </div>
                               </div>
                           </div>
                       ) : (
                           <div className="text-center text-[#a3a3a3]/60 pt-10">
                               <SparklesIcon className="h-10 w-10 mx-auto mb-2" />
                               <p>Select a completed trip on the map to view or add to its journal.</p>
                           </div>
                       )}
                   </div>
                </div>
            </div>

        </div>
    );
};

export default TravelScrapbook;