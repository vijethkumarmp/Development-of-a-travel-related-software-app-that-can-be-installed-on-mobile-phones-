
import React, { useState } from 'react';

interface LoginPageProps {
  onLogin: () => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, you'd perform authentication here.
    // For this demo, any login attempt is successful.
    onLogin();
  };

  return (
    <div className="flex items-center justify-center h-screen">
      <div className="w-full max-w-md">
        <form onSubmit={handleSubmit} className="solaris-panel p-8 space-y-6">
          <div className="text-center mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto text-[#ff8c00]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M21.5 12c0-5.25-4.25-9.5-9.5-9.5S2.5 6.75 2.5 12s4.25 9.5 9.5 9.5"/>
              <path d="M12 2.5v19"/>
              <path d="M2.5 12h19"/>
              <path d="M4.1 19.9a9.5 9.5 0 0 0 15.8 0"/>
              <path d="M4.1 4.1a9.5 9.5 0 0 1 15.8 0"/>
            </svg>
            <h1 className="text-3xl font-bold text-[#f5f5f5] mt-2">TripBro</h1>
            <p className="text-[#a3a3a3]/70 mt-1">Sign in to your travel hub</p>
          </div>
          
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-[#a3a3a3]">Email Address</label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="mt-1 block w-full bg-[#333]/50 border border-[#444] rounded-md shadow-sm py-2 px-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00] focus:border-[#ff8c00]"
              required
            />
          </div>

          <div>
            <label htmlFor="password" className="block text-sm font-medium text-[#a3a3a3]">Password</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="mt-1 block w-full bg-[#333]/50 border border-[#444] rounded-md shadow-sm py-2 px-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00] focus:border-[#ff8c00]"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full flex justify-center py-2.5 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-[#ff8c00] hover:bg-[#e67e00] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#ff8c00] transition-colors"
          >
            Login
          </button>

          <div className="flex items-center justify-center">
            <span className="text-[#a3a3a3]/80 text-sm">or</span>
          </div>

          <button
            type="button"
            onClick={onLogin} // Guest login also triggers onLogin
            className="w-full flex justify-center py-2.5 px-4 border border-[#444] rounded-md shadow-sm text-sm font-medium text-[#a3a3a3] bg-[#333]/40 hover:bg-[#444]/50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#b8860b] transition-colors"
          >
            Continue as Guest
          </button>
        </form>
      </div>
    </div>
  );
};

export default LoginPage;