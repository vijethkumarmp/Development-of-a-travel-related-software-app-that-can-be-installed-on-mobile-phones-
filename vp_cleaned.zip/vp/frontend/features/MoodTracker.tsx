import React, { useState } from 'react';
import { Mood, MoodEntry, MoodInsight } from '../types';
import { generateMoodInsights } from '../services/geminiService';
import { MoodIcon } from '../components/icons/MoodIcon';
import { EcstaticIcon } from '../components/icons/EcstaticIcon';
import { HappyIcon } from '../components/icons/HappyIcon';
import { NeutralIcon } from '../components/icons/NeutralIcon';
import { SadIcon } from '../components/icons/SadIcon';
import { StressedIcon } from '../components/icons/StressedIcon';
import { SparklesIcon } from '../components/icons/SparklesIcon';
import { LocationPinIcon } from '../components/icons/LocationPinIcon';
import { ClockIcon } from '../components/icons/ClockIcon';
import { UserGroupIcon } from '../components/icons/UserGroupIcon';
import { InfoIcon } from '../components/icons/InfoIcon';
import { CrosshairIcon } from '../components/icons/CrosshairIcon';
import { TagIcon } from '../components/icons/TagIcon';


const MOOD_OPTIONS: { mood: Mood; Icon: React.FC<any>; color: string }[] = [
  { mood: 'Ecstatic', Icon: EcstaticIcon, color: 'text-yellow-400' },
  { mood: 'Happy', Icon: HappyIcon, color: 'text-green-400' },
  { mood: 'Neutral', Icon: NeutralIcon, color: 'text-slate-400' },
  { mood: 'Sad', Icon: SadIcon, color: 'text-blue-400' },
  { mood: 'Stressed', Icon: StressedIcon, color: 'text-red-400' },
];

const SUGGESTED_ACTIVITIES = ['Sightseeing', 'Dining', 'Relaxing', 'Shopping', 'Exploring', 'Museum', 'Beach', 'Hiking'];

const getInsightIcon = (category: MoodInsight['category']) => {
  const props = { className: "h-6 w-6 text-[#ff8c00] flex-shrink-0" };
  switch(category) {
    case 'Activity': return <SparklesIcon {...props} />;
    case 'Location': return <LocationPinIcon {...props} />;
    case 'Pacing': return <ClockIcon {...props} />;
    case 'Social': return <UserGroupIcon {...props} />;
    default: return <InfoIcon {...props} />;
  }
};

const MoodTracker: React.FC = () => {
  const [moodEntries, setMoodEntries] = useState<MoodEntry[]>([]);
  const [selectedMood, setSelectedMood] = useState<Mood | null>(null);
  const [activities, setActivities] = useState<string[]>([]);
  const [currentActivity, setCurrentActivity] = useState('');
  const [location, setLocation] = useState('');
  const [notes, setNotes] = useState('');
  const [insights, setInsights] = useState<MoodInsight[] | null>(null);
  const [isLoadingInsights, setIsLoadingInsights] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [insightsError, setInsightsError] = useState<string | null>(null);

  const getMoodOption = (mood: Mood) => MOOD_OPTIONS.find(m => m.mood === mood);
  
  const handleActivityKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if ((e.key === 'Enter' || e.key === ',') && currentActivity.trim()) {
      e.preventDefault();
      addActivityTag(currentActivity.trim());
      setCurrentActivity('');
    }
  };

  const addActivityTag = (tag: string) => {
    if (activities.length < 5 && !activities.map(a => a.toLowerCase()).includes(tag.toLowerCase())) {
        setActivities([...activities, tag]);
    }
  };

  const removeActivityTag = (tagToRemove: string) => {
    setActivities(activities.filter(tag => tag !== tagToRemove));
  };
  
  const handleUseCurrentLocation = () => {
    // In a real app, this would use navigator.geolocation to get coordinates
    // and a reverse geocoding service. For this demo, we'll mock it.
    setLocation('Shibuya, Japan');
  };

  const handleLogMood = () => {
    if (!selectedMood) {
      setFormError('Please select a mood.');
      return;
    }
    setFormError(null);

    const newEntry: MoodEntry = {
      id: Date.now(),
      mood: selectedMood,
      activities: activities,
      location,
      notes,
      timestamp: new Date().toISOString(),
    };

    setMoodEntries([newEntry, ...moodEntries]);

    // Reset form
    setSelectedMood(null);
    setActivities([]);
    setCurrentActivity('');
    setLocation('');
    setNotes('');
  };

  const handleAnalyzeMoods = async () => {
    setIsLoadingInsights(true);
    setInsights(null);
    setInsightsError(null);

    const result = await generateMoodInsights(moodEntries);

    if (result && result.insights) {
      if (result.insights.length > 0) {
        setInsights(result.insights);
      } else {
        setInsightsError("Not enough data for a meaningful insight yet. Keep logging your moods!");
      }
    } else {
      setInsightsError("I'm sorry, I couldn't analyze the mood data right now. Please try again later.");
    }
    setIsLoadingInsights(false);
  };

  return (
    <div className="max-w-4xl mx-auto animate-fadeIn">
      <div className="text-center mb-8">
        <MoodIcon className="h-12 w-12 mx-auto text-[#ff8c00] mb-2"/>
        <h1 className="text-4xl font-bold text-[#f5f5f5]">Advanced Mood Tracker</h1>
        <p className="mt-2 text-lg text-[#a3a3a3]/70">Log your feelings to discover what makes your trips unforgettable.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Left Column: Logging & Insights */}
        <div className="space-y-8">
           {/* Mood Logging Form */}
          <div className="solaris-panel p-6">
            <h2 className="text-xl font-semibold text-[#f5f5f5] mb-4">How are you feeling right now?</h2>
            
            <div className="mb-4">
                <label className="block text-sm font-medium text-[#a3a3a3] mb-2">Select Mood</label>
                <div className="flex justify-around bg-[#1a1818]/50 p-2 rounded-lg">
                    {MOOD_OPTIONS.map(({ mood, Icon, color }) => (
                        <button key={mood} onClick={() => setSelectedMood(mood)} className={`p-2 rounded-full transition-all duration-200 ${selectedMood === mood ? 'bg-[#ff8c00] scale-110' : 'hover:bg-[#333]'}`}>
                            <Icon className={`h-8 w-8 ${color}`} />
                        </button>
                    ))}
                </div>
            </div>

            <div className="space-y-4">
               <div>
                    <label className="block text-sm font-medium text-[#a3a3a3] mb-2">What are you doing? (tag activities)</label>
                    <div className="relative flex items-center bg-[#333]/50 border border-[#444] rounded-md py-2 px-3 text-[#f5f5f5] focus-within:ring-2 focus-within:ring-[#ff8c00]">
                      <TagIcon className="h-5 w-5 text-[#a3a3a3]/70 mr-2 flex-shrink-0" />
                      <div className="flex flex-wrap gap-1.5 items-center flex-grow">
                          {activities.map(tag => (
                            <span key={tag} className="flex items-center gap-1.5 bg-[#ff8c00]/20 text-[#ff8c00] text-sm font-medium px-2 py-0.5 rounded">
                                {tag}
                                <button onClick={() => removeActivityTag(tag)} className="text-[#ff8c00]/70 hover:text-white">&times;</button>
                            </span>
                          ))}
                         <input
                            type="text"
                            value={currentActivity}
                            onChange={(e) => setCurrentActivity(e.target.value)}
                            onKeyDown={handleActivityKeyDown}
                            placeholder={activities.length >= 5 ? 'Max 5 tags reached' : activities.length > 0 ? '' : 'e.g., Sightseeing...'}
                            className="bg-transparent focus:outline-none min-w-[100px] flex-grow"
                            disabled={activities.length >= 5}
                          />
                      </div>
                    </div>
                     <div className="flex flex-wrap gap-2 mt-2">
                        {SUGGESTED_ACTIVITIES.map(tag => (
                            <button key={tag} onClick={() => addActivityTag(tag)} className={`px-2 py-1 bg-[#333]/60 text-[#a3a3a3] text-xs rounded hover:bg-[#444]/60 transition-colors disabled:opacity-50`} disabled={activities.includes(tag) || activities.length >= 5}>
                                {tag}
                            </button>
                        ))}
                    </div>
               </div>
               <div>
                   <label className="block text-sm font-medium text-[#a3a3a3] mb-2">Where are you?</label>
                   <div className="relative">
                      <input type="text" value={location} onChange={e => setLocation(e.target.value)} placeholder="e.g., Rome, Italy" className="w-full bg-[#333]/50 border border-[#444] rounded-md py-2 pl-3 pr-10 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00]" />
                      <button onClick={handleUseCurrentLocation} className="absolute right-2 top-1/2 -translate-y-1/2 text-[#a3a3a3]/70 hover:text-[#ff8c00]" title="Use Current Location">
                        <CrosshairIcon className="h-5 w-5" />
                      </button>
                   </div>
               </div>

               <textarea value={notes} onChange={e => setNotes(e.target.value)} placeholder="What made this moment special? Any thoughts or details..." rows={5} className="w-full bg-[#333]/50 border border-[#444] rounded-md py-2 px-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00]" />
            </div>

            <button onClick={handleLogMood} disabled={!selectedMood} className="w-full mt-4 py-2 px-4 bg-[#ff8c00] text-white rounded-lg font-semibold hover:bg-[#e67e00] disabled:bg-[#ff8c00]/50 disabled:cursor-not-allowed">
                Log Mood
            </button>
            {formError && <p className="text-red-400 text-sm text-center mt-2">{formError}</p>}
          </div>

          {/* AI Insights */}
          <div className="solaris-panel p-6">
             <div className="flex items-center gap-3 mb-4">
                <SparklesIcon className="h-6 w-6 text-[#ff8c00]"/>
                <h2 className="text-xl font-semibold text-[#f5f5f5]">Your Travel Insights</h2>
             </div>
             
             {isLoadingInsights && <p className="text-[#a3a3a3]/70 text-sm animate-pulse">Analyzing your moods...</p>}
             
             {insightsError && !isLoadingInsights && (
               <p className="text-yellow-400 text-sm">{insightsError}</p>
             )}

             {insights && !isLoadingInsights && (
                <div className="space-y-4">
                  {insights.map((insight, index) => (
                    <div key={index} className="bg-[#1a1818]/50 p-4 rounded-lg animate-fadeIn" style={{ animationDelay: `${index * 100}ms` }}>
                        <div className="flex items-start gap-4 mb-3">
                            {getInsightIcon(insight.category)}
                            <div>
                                <h3 className="text-lg font-bold text-[#f5f5f5]">{insight.insight_title}</h3>
                                <p className="text-sm text-[#a3a3a3]/70 mt-1">{insight.pattern_description}</p>
                            </div>
                        </div>
                        <div className="mt-3 pt-3 border-t border-[#444]">
                            <div className="flex items-start gap-3 p-3 bg-[#ff8c00]/10 rounded-md">
                                <SparklesIcon className="h-5 w-5 text-[#ff8c00] flex-shrink-0 mt-0.5" />
                                <div>
                                    <p className="text-sm font-semibold text-[#ff8c00]">Travel Suggestion</p>
                                    <p className="text-sm text-[#ff8c00]/90 mt-1">{insight.travel_suggestion}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                  ))}
                </div>
             )}

             {!insights && !isLoadingInsights && !insightsError && (
                <p className="text-[#a3a3a3]/70 text-sm">Log at least 3 moods to reveal personalized travel tips!</p>
             )}
             
             <button onClick={handleAnalyzeMoods} disabled={moodEntries.length < 3 || isLoadingInsights} className={`w-full mt-4 py-2 px-4 bg-[#ff8c00]/80 text-white rounded-lg font-semibold hover:bg-[#ff8c00] disabled:bg-[#ff8c00]/50 disabled:cursor-not-allowed disabled:animate-none transition-all duration-300 ${moodEntries.length >= 3 && !isLoadingInsights ? 'animate-pulse' : ''}`}>
                {isLoadingInsights ? 'Thinking...' : 'Analyze My Moods'}
             </button>
          </div>
        </div>

        {/* Right Column: Mood History */}
        <div className="solaris-panel p-6">
          <h2 className="text-xl font-semibold text-[#f5f5f5] mb-4">Mood History</h2>
          {moodEntries.length > 0 ? (
            <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2">
              {moodEntries.map(entry => {
                const moodOption = getMoodOption(entry.mood);
                return (
                  <div key={entry.id} className="bg-[#333]/40 p-4 rounded-lg flex gap-4 animate-fadeIn">
                    <div className="flex-shrink-0">
                      {moodOption && <moodOption.Icon className={`h-10 w-10 ${moodOption.color}`} />}
                    </div>
                    <div className="flex-grow">
                      <p className="font-bold text-[#f5f5f5]">{entry.mood}</p>
                      
                      <div className="mt-2 space-y-2 text-sm">
                        {entry.activities.length > 0 && (
                            <div className="flex items-start gap-2">
                                <TagIcon className="h-4 w-4 text-[#a3a3a3]/70 mt-0.5 flex-shrink-0" />
                                <div className="flex flex-wrap gap-1.5">
                                    {entry.activities.map(act => (
                                        <span key={act} className="bg-[#ff8c00]/20 text-[#ff8c00] text-xs font-medium px-2 py-1 rounded-md">{act}</span>
                                    ))}
                                </div>
                            </div>
                        )}
                        {entry.location && (
                            <div className="flex items-center gap-2">
                                <LocationPinIcon className="h-4 w-4 text-[#a3a3a3]/70 flex-shrink-0" />
                                <span className="text-[#a3a3a3]/80">{entry.location}</span>
                            </div>
                        )}
                      </div>

                      {entry.notes && <p className="text-sm text-[#f5f5f5]/90 italic mt-3 pt-3 border-t border-[#444]/50">"{entry.notes}"</p>}
                      <p className="text-xs text-[#a3a3a3]/50 mt-3">{new Date(entry.timestamp).toLocaleString()}</p>
                    </div>
                  </div>
                )
              })}
            </div>
          ) : (
            <div className="text-center py-10">
              <p className="text-[#a3a3a3]/70">Your logged moods will appear here.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MoodTracker;