import React from 'react';
import { Feature } from '../types';

interface PlaceholderProps {
  feature: Feature;
}

const Placeholder: React.FC<PlaceholderProps> = ({ feature }) => {
  return (
    <div className="flex flex-col items-center justify-center h-full text-center">
      <div className="p-6 solaris-panel rounded-full mb-6 bg-[#ff8c00]/10">
        <feature.Icon className="h-16 w-16 text-[#ff8c00]" />
      </div>
      <h1 className="text-4xl font-bold text-[#f5f5f5]">{feature.name}</h1>
      <p className="mt-2 text-lg text-[#a3a3a3]/70 max-w-md">{feature.description}</p>
      <div className="mt-8 bg-[#ff8c00]/10 text-[#ff8c00] px-6 py-3 rounded-lg">
        <p className="font-semibold">This feature is coming soon!</p>
      </div>
    </div>
  );
};

export default Placeholder;