
import React, { useState, useEffect, useRef } from 'react';
import { ShieldIcon } from '../components/icons/ShieldIcon';
import { EmergencyContact } from '../types';
import { getEmergencyInfo } from '../services/geminiService';
import { LocationSharingIcon } from '../components/icons/LocationSharingIcon';
import { TimerIcon } from '../components/icons/TimerIcon';
import { SparklesIcon } from '../components/icons/SparklesIcon';

const SOS: React.FC = () => {
  const [isCheckInActive, setIsCheckInActive] = useState(false);
  const [checkInTime, setCheckInTime] = useState(30);
  const [checkInCountdown, setCheckInCountdown] = useState(0);
  const checkInIntervalRef = useRef<number | null>(null);

  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [statusType, setStatusType] = useState<'success' | 'error' | 'info'>('info');
  
  const [location, setLocation] = useState<{ latitude: number, longitude: number } | null>(null);
  const [locationError, setLocationError] = useState<string | null>(null);

  const [country, setCountry] = useState('Japan');
  const [emergencyNumbers, setEmergencyNumbers] = useState<EmergencyContact[]>([]);
  const [isLoadingNumbers, setIsLoadingNumbers] = useState(false);
  
  // --- Mock Data ---
  const accommodation = {
    name: 'Shibuya Grand Hotel',
    address: '2 Chome-24-1 Dogenzaka, Shibuya City, Tokyo 150-0043, Japan',
    addressLocal: '〒150-0043 東京都渋谷区道玄坂２丁目２４−1',
  };
  // --- End Mock Data ---
  
  // Fetch user location
  useEffect(() => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          });
          setLocationError(null);
        },
        (error) => {
          let errorMessage = "An unknown error occurred.";
          switch (error.code) {
            case error.PERMISSION_DENIED:
              errorMessage = "Permission to access location was denied.";
              break;
            case error.POSITION_UNAVAILABLE:
              errorMessage = "Location information is unavailable.";
              break;
            case error.TIMEOUT:
              errorMessage = "The request to get user location timed out.";
              break;
          }
          console.error("Geolocation error:", error);
          setLocationError(`Error getting location: ${errorMessage}`);
        }
      );
    } else {
      setLocationError("Geolocation is not supported by your browser.");
    }
  }, []);

  // Fetch emergency numbers when country changes
  useEffect(() => {
    const fetchNumbers = async () => {
      if (!country) return;
      setIsLoadingNumbers(true);
      const numbers = await getEmergencyInfo(country);
      if (numbers) {
        setEmergencyNumbers(numbers);
      } else {
        setEmergencyNumbers([]);
        showStatusMessage(`Could not fetch numbers for ${country}`, 'error');
      }
      setIsLoadingNumbers(false);
    };
    fetchNumbers();
  }, [country]);


  const showStatusMessage = (message: string, type: 'success' | 'error' | 'info', duration: number = 5000) => {
    setStatusMessage(message);
    setStatusType(type);
    setTimeout(() => setStatusMessage(null), duration);
  };

  useEffect(() => {
    if (isCheckInActive) {
      checkInIntervalRef.current = window.setInterval(() => {
        setCheckInCountdown(prev => (prev > 0 ? prev - 1 : 0));
      }, 1000);
    } else if (checkInIntervalRef.current) {
      clearInterval(checkInIntervalRef.current);
      checkInIntervalRef.current = null;
    }
    return () => {
      if (checkInIntervalRef.current) clearInterval(checkInIntervalRef.current);
    };
  }, [isCheckInActive]);

  useEffect(() => {
    if (checkInCountdown === 0 && isCheckInActive) {
      setIsCheckInActive(false);
      const locationString = location
          ? `Lat: ${location.latitude}, Lon: ${location.longitude}`
          : "Location not available";
      showStatusMessage('CHECK-IN FAILED! Alert sent to trusted contacts.', 'error');
      // Simulate sending alert with location
      console.log(`ALERT: User did not check in! Sending location to trusted contacts. ${locationString}`);
    }
  }, [checkInCountdown, isCheckInActive, location]);

  const handleShareLocation = async () => {
    if (location) {
      const mapLink = `https://www.google.com/maps?q=${location.latitude},${location.longitude}`;
      const shareData = {
        title: 'My Live Location',
        text: `I'm sharing my live location with you: ${mapLink}`,
        url: mapLink,
      };

      if (navigator.share) {
        try {
          await navigator.share(shareData);
          showStatusMessage('Location shared successfully!', 'success');
        } catch (err) {
          console.error('Error sharing location:', err);
          showStatusMessage('Could not share location.', 'error');
        }
      } else {
        // Fallback for browsers that don't support Web Share API
        navigator.clipboard.writeText(shareData.text);
        showStatusMessage('Location link copied to clipboard!', 'success');
      }
    } else {
      showStatusMessage(locationError || 'Location not available.', 'error');
    }
  };


  const handleStartCheckIn = () => {
    if (checkInTime < 1) {
        showStatusMessage('Timer must be at least 1 minute.', 'error');
        return;
    }
    setCheckInCountdown(checkInTime * 60);
    setIsCheckInActive(true);
    showStatusMessage(`Safety check-in timer started for ${checkInTime} minutes.`, 'success');
  };

  const handleImSafe = () => {
    setIsCheckInActive(false);
    setCheckInCountdown(0);
    showStatusMessage('You have checked in safely.', 'success');
  };

  const handleEmergencyCall = (service: string, number: string) => {
    showStatusMessage(`Dialing ${service}: ${number}`, 'info', 2000);
    window.location.href = `tel:${number}`;
  };

  const handleCopyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
        showStatusMessage('Address copied to clipboard!', 'success');
    }).catch(() => {
        showStatusMessage('Failed to copy address.', 'error');
    });
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="max-w-4xl mx-auto animate-fadeIn pb-16">
      <div className="text-center mb-8">
        <ShieldIcon className="h-12 w-12 mx-auto text-red-400 mb-2"/>
        <h1 className="text-4xl font-bold text-[#f5f5f5]">SOS & Safety Hub</h1>
        <p className="mt-2 text-lg text-[#a3a3a3]/70">Your one-tap safety net for peace of mind.</p>
      </div>

      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-semibold text-[#f5f5f5]">Emergency Hub</h2>
           <div className="flex items-center gap-2">
                <label htmlFor="country-input" className="text-sm text-[#a3a3a3]/70">Country:</label>
                <input
                    id="country-input"
                    type="text"
                    value={country}
                    onChange={(e) => setCountry(e.target.value)}
                    placeholder="e.g., Japan"
                    className="bg-[#333]/50 border border-[#444] rounded-md py-1 px-2 text-[#f5f5f5] w-32"
                />
            </div>
        </div>
        {isLoadingNumbers ? (
             <div className="text-center text-[#a3a3a3]/70">Fetching numbers...</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {emergencyNumbers.map(({ service, number }) => (
                 <button key={service} onClick={() => handleEmergencyCall(service, number)} className="p-6 bg-red-600/80 hover:bg-red-700 rounded-lg text-white font-bold text-xl text-center transition-transform transform hover:scale-105">
                     {service} ({number})
                 </button>
             ))}
             {emergencyNumbers.length === 0 && <p className="text-[#a3a3a3]/60 md:col-span-3 text-center">No emergency numbers found for the selected country.</p>}
          </div>
        )}
      </div>
      
      <div className="mb-8">
         <h2 className="text-2xl font-semibold text-[#f5f5f5] mb-4">My Accommodation</h2>
         <div className="solaris-panel p-6">
            <h3 className="text-xl font-bold text-[#f5f5f5]">{accommodation.name}</h3>
            <div className="group relative">
                <p className="text-[#a3a3a3]/90 mt-2">{accommodation.address}</p>
                <button onClick={() => handleCopyToClipboard(accommodation.address)} className="absolute top-0 right-0 opacity-0 group-hover:opacity-100 transition-opacity bg-[#ff8c00] text-white text-xs px-2 py-1 rounded-md">Copy</button>
            </div>
            <div className="mt-4 pt-4 border-t border-[#444] group relative">
                <p className="text-sm text-[#a3a3a3]/70 mb-1">Address in Local Language (for taxi/help):</p>
                <p className="text-lg font-mono text-[#ff8c00] bg-[#1a1818]/70 p-3 rounded-md">{accommodation.addressLocal}</p>
                <button onClick={() => handleCopyToClipboard(accommodation.addressLocal)} className="absolute top-9 right-1 opacity-0 group-hover:opacity-100 transition-opacity bg-[#ff8c00] text-white text-xs px-2 py-1 rounded-md">Copy</button>
            </div>
         </div>
      </div>

      <div>
        <h2 className="text-2xl font-semibold text-[#f5f5f5] mb-4">Advanced Safety Tools</h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

          {/* Safety Beacon Card */}
          <div className="solaris-panel p-6 flex flex-col">
            <div className="flex items-center gap-4 mb-4">
              <LocationSharingIcon className="h-8 w-8 text-[#ff8c00] flex-shrink-0" />
              <div>
                <h3 className="text-xl font-bold text-[#f5f5f5]">Safety Beacon</h3>
                <p className="text-sm text-[#a3a3a3]/70">Share your location with trusted contacts.</p>
              </div>
            </div>
            <div className="text-center my-4 flex-grow">
                <p className="text-[#a3a3a3]/70">
                    {location ? 'Your current location is ready to share.' : locationError || 'Getting your location...'}
                </p>
            </div>
            <button onClick={handleShareLocation} disabled={!location} className="w-full py-3 px-4 rounded-md font-semibold transition-colors bg-[#ff8c00] hover:bg-[#e67e00] text-white disabled:bg-[#ff8c00]/50 disabled:cursor-not-allowed">
              Share My Location
            </button>
          </div>

          {/* Safety Check-in Card */}
          <div className="solaris-panel p-6 flex flex-col">
            <div className="flex items-center gap-4 mb-4">
              <TimerIcon className="h-8 w-8 text-yellow-300 flex-shrink-0" />
              <div>
                <h3 className="text-xl font-bold text-[#f5f5f5]">Safety Check-In</h3>
                <p className="text-sm text-[#a3a3a3]/70">Sends an alert if you don't check in on time.</p>
              </div>
            </div>
            {isCheckInActive ? (
              <div className="text-center my-4 flex-grow flex flex-col items-center justify-center">
                  <div className="relative w-48 h-48">
                      <svg className="w-full h-full" viewBox="0 0 140 140" style={{ transform: 'rotate(-90deg)', transformOrigin: 'center' }}>
                          <circle
                              className="text-[#333]/50"
                              strokeWidth="10"
                              stroke="currentColor"
                              fill="transparent"
                              r="60"
                              cx="70"
                              cy="70"
                          />
                          <circle
                              className="text-yellow-400"
                              style={{ transition: 'stroke-dashoffset 1s linear' }}
                              strokeWidth="10"
                              strokeDasharray={377}
                              strokeDashoffset={377 - (checkInCountdown / (checkInTime * 60 || 1)) * 377}
                              strokeLinecap="round"
                              stroke="currentColor"
                              fill="transparent"
                              r="60"
                              cx="70"
                              cy="70"
                          />
                      </svg>
                      <div className="absolute inset-0 flex flex-col items-center justify-center">
                          <p className="text-4xl font-mono text-[#f5f5f5]">{formatTime(checkInCountdown)}</p>
                          <p className="text-sm text-[#a3a3a3]/70">until alert</p>
                      </div>
                  </div>
              </div>
            ) : (
              <div className="my-4 flex-grow flex flex-col items-center justify-center gap-3">
                <label className="text-[#a3a3a3] text-sm">Set Check-in Timer (minutes)</label>
                <div className="flex items-center gap-2">
                    <input
                        type="number"
                        value={checkInTime}
                        onChange={e => setCheckInTime(Number(e.target.value))}
                        className="w-24 bg-[#333]/50 border border-[#444] rounded-md py-2 px-3 text-[#f5f5f5] text-center font-semibold text-lg"
                        min="1"
                    />
                    <span className="text-[#a3a3a3]/70">min</span>
                </div>
                <div className="flex gap-2 mt-2">
                    {[15, 30, 60, 120].map(time => (
                        <button
                            key={time}
                            onClick={() => setCheckInTime(time)}
                            className={`px-3 py-1 text-xs font-medium rounded-full transition-colors ${
                                checkInTime === time
                                    ? 'bg-[#ff8c00] text-white'
                                    : 'bg-[#333]/50 text-[#a3a3a3] hover:bg-[#444]/50'
                            }`}
                        >
                            {time < 60 ? `${time}m` : `${time/60}h`}
                        </button>
                    ))}
                </div>
              </div>
            )}
            {isCheckInActive ? (
              <button onClick={handleImSafe} className="w-full py-3 px-4 rounded-md font-semibold transition-colors bg-green-600 hover:bg-green-700 text-white">
                I'm Safe
              </button>
            ) : (
              <button onClick={handleStartCheckIn} className="w-full py-3 px-4 rounded-md font-semibold transition-colors bg-yellow-600 hover:bg-yellow-700 text-black">
                Start Timer
              </button>
            )}
          </div>
        </div>
      </div>
      
      {/* Status Message */}
      {statusMessage && (
        <div className={`fixed bottom-8 left-1/2 -translate-x-1/2 px-6 py-3 rounded-lg text-white shadow-lg text-sm font-semibold
          ${statusType === 'success' && 'bg-green-600'}
          ${statusType === 'error' && 'bg-red-600'}
          ${statusType === 'info' && 'bg-[#ff8c00]'}
          animate-fadeIn`}>
          {statusMessage}
        </div>
      )}
    </div>
  );
};

export default SOS;