
import { GoogleGenAI, Type, Chat } from "@google/genai";
import { Itinerary, LandmarkInfo, PackingListResponse, Expense, ExpenseCategory, MoodEntry, Booking, EmergencyContact, DetailedLandmarkInfo, Attachment, TranslationResponse, PhrasebookResponse, MoodInsightResponse, MenuAnalysisResponse, SouvenirResponse, JetLagPlanResponse } from '../types';

// if (!process.env.API_KEY) {
//     throw new Error("API_KEY environment variable is not set.");
// }

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || 'dummy' });

const itinerarySchema = {
  type: Type.OBJECT,
  properties: {
    trip_title: { type: Type.STRING, description: "A creative and catchy title for the trip." },
    destination: { type: Type.STRING },
    duration_days: { type: Type.INTEGER },
    itinerary_plan: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          day: { type: Type.INTEGER },
          date_suggestion: { type: Type.STRING, description: "A suggested date, like 'Day 1' or a specific calendar date if possible." },
          theme: { type: Type.STRING, description: "A theme for the day, e.g., 'Cultural Immersion' or 'Relaxation'." },
          activities: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                time: { type: Type.STRING, description: "e.g., '9:00 AM' or 'Afternoon'" },
                description: { type: Type.STRING, description: "A short description of the activity." },
                details: { type: Type.STRING, description: "More detailed information about the activity." },
                location: { type: Type.STRING, description: "Name of the place or address." },
                activity_type: {
                  type: Type.STRING,
                  description: "Categorize the activity. Possible values: 'Food', 'Sightseeing', 'Travel', 'Accommodation', 'Shopping', 'Entertainment', 'Other'."
                }
              },
               required: ["time", "description", "details", "activity_type"],
            },
          },
        },
        required: ["day", "date_suggestion", "theme", "activities"],
      },
    },
  },
  required: ["trip_title", "destination", "duration_days", "itinerary_plan"],
};

export const generateItinerary = async (destination: string, duration: string, interests: string, preferences: string): Promise<Itinerary | null> => {
  const preferencesPrompt = preferences
    ? `The traveler's preferences are: ${preferences}. This should strongly influence the style of the trip (e.g., 'budget-friendly' should prioritize free activities and public transport, 'adventurous' should include hiking or unique experiences, 'family-friendly' should include activities suitable for children).`
    : '';

  const prompt = `
    Create a detailed travel itinerary for a trip to ${destination} for ${duration} days. 
    The traveler's interests are: ${interests}.
    ${preferencesPrompt}
    The itinerary should be well-structured, logical, and inspiring. 
    Provide a variety of activities, including popular attractions and hidden gems.
    For each day, suggest a theme and a list of activities with suggested times and details.
    Crucially, for each activity, you MUST categorize it into one of the following types: 'Food', 'Sightseeing', 'Travel', 'Accommodation', 'Shopping', 'Entertainment', or 'Other'.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: itinerarySchema,
      },
    });

    const jsonText = response.text.trim();
    return JSON.parse(jsonText) as Itinerary;
  } catch (error) {
    console.error("Error generating itinerary:", error);
    return null;
  }
};

export const getProactiveSuggestion = async (
    context: { location: string; time: string; itineraryItem?: string; previousMessages: { sender: 'user' | 'bot', text: string }[] }
): Promise<string> => {
    let chat: Chat;

    const systemInstruction = `You are TripBro, a helpful and knowledgeable travel assistant specializing in cultural etiquette, local customs, and language. 
    You also act as a proactive guide. When given context about a user's location or itinerary, you provide timely, interesting, and helpful suggestions.
    Always format your responses for readability with markdown (e.g., lists, bold text). Keep responses concise.`;

    // Recreate a chat history for context
    const history = context.previousMessages.map(msg => ({
        role: msg.sender === 'user' ? 'user' : 'model',
        parts: [{ text: msg.text }]
    }));

    chat = ai.chats.create({
        model: 'gemini-2.5-flash',
        config: { systemInstruction },
        history,
    });
    
    // This is the prompt for the AI's turn
    const proactivePrompt = `Based on the current situation, provide a helpful message.
    - Current Location: ${context.location}
    - Current Time: ${context.time}
    - Relevant Itinerary Item: ${context.itineraryItem || 'None specified, user is exploring.'}
    Your response should be a single, proactive suggestion, cultural tip, or interesting fact. Be conversational and friendly.`;

    try {
        const response = await chat.sendMessage({ message: proactivePrompt });
        return response.text;
    } catch (error) {
        console.error("Error in proactive suggestion:", error);
        return "I'm sorry, I'm having trouble connecting right now. Please try again later.";
    }
};

const landmarkSchema = {
  type: Type.OBJECT,
  properties: {
    name: { type: Type.STRING, description: "The name of the landmark. If no landmark is detected, this should be 'Unknown'." },
    location: { type: Type.STRING, description: "The city and country of the landmark." },
    description: { type: Type.STRING, description: "A concise, interesting, one-paragraph description of the landmark's history and significance." },
    opening_hours: { type: Type.STRING, description: "The typical opening and closing hours for the landmark (e.g., '9:00 AM - 6:00 PM'). Only include if readily available public information." },
    wait_time: { type: Type.STRING, description: "An estimated current wait time if it's a popular tourist attraction (e.g., '~15 minutes', 'Short wait'). Only include if this is a known, common metric for the location." }
  },
  required: ["name", "location", "description"],
};

export const getLandmarkInfoFromImage = async (base64Image: string): Promise<LandmarkInfo | null> => {
  const imagePart = {
    inlineData: {
      mimeType: 'image/jpeg',
      data: base64Image,
    },
  };
  const textPart = {
    text: "Identify the landmark in this image. Provide its name, location, and a brief, engaging description of its history and significance. If it's a popular tourist attraction, also include its typical opening hours and an estimated current wait time if this is commonly known information. If you cannot identify a specific landmark, please indicate that."
  };

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: { parts: [imagePart, textPart] },
      config: {
        responseMimeType: 'application/json',
        responseSchema: landmarkSchema,
      }
    });
    
    const jsonText = response.text.trim();
    const data = JSON.parse(jsonText) as LandmarkInfo;

    if (data.name.toLowerCase() === 'unknown') {
      return null;
    }
    
    return data;

  } catch (error) {
    console.error("Error getting landmark info:", error);
    return null;
  }
};

const detailedLandmarkSchema = {
  type: Type.OBJECT,
  properties: {
    historical_context: { type: Type.STRING, description: "A detailed, multi-paragraph historical context of the landmark." },
    visitor_reviews_summary: { type: Type.STRING, description: "A summary of common themes from visitor reviews, such as best times to visit, what to look out for, and general sentiment." }
  },
  required: ["historical_context", "visitor_reviews_summary"],
};

export const getDetailedLandmarkInfo = async (landmarkName: string, location: string): Promise<DetailedLandmarkInfo | null> => {
  const prompt = `Provide a more detailed look at the landmark: "${landmarkName}" located in ${location}.
  Specifically, I need:
  1. A detailed historical context, going deeper than a brief summary.
  2. A summary of common themes from visitor reviews. What do people love? What are common tips or complaints?
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: detailedLandmarkSchema,
      }
    });
    
    const jsonText = response.text.trim();
    return JSON.parse(jsonText) as DetailedLandmarkInfo;
  } catch (error) {
    console.error("Error getting detailed landmark info:", error);
    return null;
  }
};


const packingListSchema = {
  type: Type.OBJECT,
  properties: {
    trip_title: { type: Type.STRING, description: "A title for the trip this packing list is for, e.g., 'Tokyo Adventure Packing List'." },
    packing_list: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          category_name: { type: Type.STRING, description: "The category of items, e.g., 'Clothing', 'Toiletries', 'Electronics', 'Documents'." },
          items: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                item_name: { type: Type.STRING, description: "The name of the item to pack." },
                quantity: { type: Type.STRING, description: "The suggested quantity, e.g., '1', '2 pairs', 'As needed'." }
              },
              required: ["item_name", "quantity"],
            }
          }
        },
        required: ["category_name", "items"],
      }
    }
  },
  required: ["trip_title", "packing_list"],
};

export const generatePackingList = async (destination: string, duration: string, activities: string): Promise<PackingListResponse | null> => {
    const prompt = `
    Create a detailed, personalized packing list for a trip to ${destination} for ${duration} days.
    The traveler's planned activities are: ${activities}.
    Crucially, act as if you have access to real-time weather forecasts for the destination and generate the list accordingly, suggesting appropriate clothing.
    Also include essentials like travel documents and specific power adapters for the destination country if applicable.
    Structure the list into logical categories (e.g., Clothing, Toiletries, Electronics, Documents, Miscellaneous).
    Provide a suggested quantity for each item.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: packingListSchema,
      },
    });

    const jsonText = response.text.trim();
    return JSON.parse(jsonText) as PackingListResponse;
  } catch (error) {
    console.error("Error generating packing list:", error);
    return null;
  }
};

const expenseCategorySchema = {
  type: Type.OBJECT,
  properties: {
    category: {
      type: Type.STRING,
      description: "The most appropriate category for the expense.",
      enum: ['Food', 'Transport', 'Accommodation', 'Activities', 'Shopping', 'Other']
    },
  },
  required: ["category"],
};

export const categorizeExpense = async (description: string, pastExpenses: Expense[]): Promise<ExpenseCategory | null> => {
  if (!description || description.trim().length < 3) return null;
  
  // To keep the prompt efficient, let's use a sample of recent expenses.
  const expenseHistorySample = pastExpenses
    .slice(0, 20) // Limit to the 20 most recent expenses
    .map(({ description, category }) => ({ description, category }));

  const prompt = `
    You are an intelligent expense categorization assistant. Your task is to categorize a new expense based on its description and the user's past spending habits.
    Analyze the user's recent expense history to understand their patterns. For example, if they frequently categorize "taxi" as 'Transport', you should do the same.

    Here is a sample of the user's recent expenses:
    ${JSON.stringify(expenseHistorySample, null, 2)}

    Based on this history, categorize the following new expense.
    Choose exactly one of the following categories: 'Food', 'Transport', 'Accommodation', 'Activities', 'Shopping', 'Other'.

    New Expense Description: "${description}"
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: expenseCategorySchema,
      },
    });

    const jsonText = response.text.trim();
    const result = JSON.parse(jsonText);
    return result.category as ExpenseCategory;
  } catch (error) {
    console.error("Error categorizing expense:", error);
    return null;
  }
};

const moodInsightsSchema = {
  type: Type.OBJECT,
  properties: {
    insights: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          insight_title: { type: Type.STRING, description: "A short, catchy title for the insight." },
          pattern_description: { type: Type.STRING, description: "A friendly description of the pattern discovered in the user's mood data." },
          travel_suggestion: { type: Type.STRING, description: "A concrete, actionable travel suggestion for a future trip based on the discovered pattern." },
          category: { 
            type: Type.STRING, 
            description: "Categorize the insight. This helps the UI pick a relevant icon.",
            enum: ['Activity', 'Location', 'Pacing', 'Social', 'Other']
          },
        },
        required: ["insight_title", "pattern_description", "travel_suggestion", "category"],
      }
    }
  },
  required: ["insights"],
};

export const generateMoodInsights = async (moodEntries: MoodEntry[]): Promise<MoodInsightResponse | null> => {
  const cleanEntries = moodEntries.map(({ id, ...rest }) => rest);
  const prompt = `
    As a travel insight analyst, examine the following mood log data from a traveler. 
    The data is an array of JSON objects, where each object represents a mood entry with the mood, activities (an array of tags), location, and notes.
    Identify 1 to 3 significant patterns or correlations between their moods, activities, and locations. 
    For each pattern, provide a concise, personalized insight and a specific, actionable travel suggestion for a future trip.
    Do not just summarize the data; provide creative and helpful advice based on the patterns you see.
    Categorize each insight appropriately. For example, if the insight is about enjoying museums, the category is 'Activity'. If it's about enjoying slower days, it's 'Pacing'. If they are happiest with friends, it's 'Social'.

    Mood Data:
    ${JSON.stringify(cleanEntries, null, 2)}
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: moodInsightsSchema,
      },
    });

    const jsonText = response.text.trim();
    const parsed = JSON.parse(jsonText) as MoodInsightResponse;
    if (!parsed.insights) {
      return { insights: [] };
    }
    return parsed;

  } catch (error) {
    console.error("Error generating mood insights:", error);
    return null;
  }
};

export const generateCaptionForImage = async (base64Image: string, mimeType: string): Promise<string | null> => {
  const imagePart = {
    inlineData: {
      mimeType,
      data: base64Image,
    },
  };
  const textPart = {
    text: "Analyze this image from a travel scrapbook. Generate a single, creative, one-sentence caption for it. The tone should be evocative and personal, like a journal entry. For example, 'Chasing the last golden rays over the Aegean.' or 'Lost in the vibrant chaos of the Shibuya Scramble.' Do not add any extra formatting or quotation marks.",
  };

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: { parts: [imagePart, textPart] },
    });
    
    return response.text.trim();
  } catch (error) {
    console.error("Error generating image caption:", error);
    return null;
  }
};

const bookingParserSchema = {
  type: Type.OBJECT,
  properties: {
    type: {
      type: Type.STRING,
      description: "The type of booking. Must be one of 'Flight', 'Hotel', 'Car Rental', or 'Activity'.",
      enum: ['Flight', 'Hotel', 'Car Rental', 'Activity'],
    },
    confirmationNumber: { type: Type.STRING },
    notes: { type: Type.STRING, description: "Any other relevant notes or details." },
    // Flight fields
    airline: { type: Type.STRING, description: "Airline name." },
    flightNumber: { type: Type.STRING },
    departure: {
      type: Type.OBJECT,
      properties: {
        airport: { type: Type.STRING, description: "Full departure airport name." },
        code: { type: Type.STRING, description: "3-letter IATA airport code for departure." },
        dateTime: { type: Type.STRING, description: "Departure date and time in local format for that airport, converted to YYYY-MM-DDTHH:mm." },
      },
    },
    arrival: {
      type: Type.OBJECT,
      properties: {
        airport: { type: Type.STRING, description: "Full arrival airport name." },
        code: { type: Type.STRING, description: "3-letter IATA airport code for arrival." },
        dateTime: { type: Type.STRING, description: "Arrival date and time in local format for that airport, converted to YYYY-MM-DDTHH:mm." },
      },
    },
    // Hotel fields
    hotelName: { type: Type.STRING },
    address: { type: Type.STRING },
    checkInDate: { type: Type.STRING, description: "Check-in date in YYYY-MM-DD format." },
    checkOutDate: { type: Type.STRING, description: "Check-out date in YYYY-MM-DD format." },
    // Car Rental fields
    company: { type: Type.STRING, description: "Car rental company name." },
    pickupLocation: { type: Type.STRING },
    dropoffLocation: { type: Type.STRING },
    pickupDateTime: { type: Type.STRING, description: "Pickup date and time, converted to YYYY-MM-DDTHH:mm." },
    dropoffDateTime: { type: Type.STRING, description: "Dropoff date and time, converted to YYYY-MM-DDTHH:mm." },
    // Activity fields
    name: { type: Type.STRING, description: "Name of the activity or tour." },
    location: { type: Type.STRING },
    date: { type: Type.STRING, description: "Date of the activity in YYYY-MM-DD format." },
    time: { type: Type.STRING, description: "Time of the activity in HH:mm format." },
  },
  required: ["type"],
};


export const extractTextFromImage = async (base64Image: string): Promise<string | null> => {
  const imagePart = {
    inlineData: {
      mimeType: 'image/jpeg',
      data: base64Image,
    },
  };
  const textPart = {
    text: "Perform OCR on this image. Extract all visible text and return it as a single block of raw text. Do not summarize, interpret, or format the text. Just return the text content.",
  };

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: { parts: [imagePart, textPart] },
    });
    
    return response.text;
  } catch (error) {
    console.error("Error extracting text from image:", error);
    return null;
  }
};

export const parseBookingFromText = async (text: string): Promise<Partial<Booking> | null> => {
  if (!text || text.trim().length < 10) return null;
  
  const prompt = `
    You are an intelligent travel assistant. Analyze the following text from a travel confirmation.
    Identify if it is for a 'Flight', 'Hotel', 'Car Rental', or 'Activity'.
    Extract all relevant details and format them into the provided JSON schema.
    Be precise with details like confirmation numbers, dates, times, and locations.
    For all date and time fields, convert them to the standard formats specified in the schema description (e.g., YYYY-MM-DD, YYYY-MM-DDTHH:mm, or HH:mm).
    If a piece of information is not present, omit the corresponding field from the JSON output.

    Text to analyze:
    "${text}"
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: bookingParserSchema,
      },
    });

    const jsonText = response.text.trim();
    // The model's response should match the schema, so we can cast it.
    // We handle potential missing fields gracefully in the component.
    return JSON.parse(jsonText) as Partial<Booking>; 
  } catch (error) {
    console.error("Error parsing booking text:", error);
    return null;
  }
};

const emergencyContactsSchema = {
    type: Type.ARRAY,
    items: {
        type: Type.OBJECT,
        properties: {
            service: {
                type: Type.STRING,
                description: "The emergency service, must be one of 'Police', 'Ambulance', or 'Fire'.",
                enum: ['Police', 'Ambulance', 'Fire']
            },
            number: {
                type: Type.STRING,
                description: "The primary phone number for the service."
            }
        },
        required: ["service", "number"]
    }
};


export const getEmergencyInfo = async (country: string): Promise<EmergencyContact[] | null> => {
    if (!country || country.trim().length < 3) return null;
    const prompt = `
    Provide the primary national emergency contact numbers for ${country}.
    I need the numbers for 'Police', 'Ambulance', and 'Fire' services.
    If a single number (like 112 or 911) is used for all services, provide that number for each category.
    Format the response according to the provided JSON schema.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: emergencyContactsSchema,
      },
    });

    const jsonText = response.text.trim();
    return JSON.parse(jsonText) as EmergencyContact[];
  } catch (error) {
    console.error("Error fetching emergency info:", error);
    return null;
  }
};

const translationSchema = {
  type: Type.OBJECT,
  properties: {
    translation: { type: Type.STRING, description: "The translated text." },
    pronunciation_guide: { type: Type.STRING, description: "A simple, easy-to-read phonetic pronunciation guide for the translated text." }
  },
  required: ["translation", "pronunciation_guide"],
};

export const translateText = async (text: string, targetLang: string, sourceLang: string = 'English'): Promise<TranslationResponse | null> => {
  if (!text.trim() || !targetLang.trim()) return null;

  const prompt = `
    Translate the following text from ${sourceLang} to ${targetLang}. 
    Also provide a simple, easy-to-read phonetic pronunciation guide for the ${targetLang} translation.
    Text to translate: "${text}"
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: translationSchema,
      },
    });

    const jsonText = response.text.trim();
    return JSON.parse(jsonText) as TranslationResponse;
  } catch (error) {
    console.error("Error translating text:", error);
    return null;
  }
};

const phrasebookSchema = {
  type: Type.OBJECT,
  properties: {
    phrases: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          source_phrase: { type: Type.STRING, description: "The phrase in the source language." },
          translated_phrase: { type: Type.STRING, description: "The translated phrase in the target language." },
          pronunciation_guide: { type: Type.STRING, description: "A simple phonetic guide for the translated phrase." },
        },
        required: ["source_phrase", "translated_phrase", "pronunciation_guide"],
      }
    }
  },
  required: ["phrases"],
};

export const generatePhrasebook = async (category: string, targetLang: string, sourceLang: string = 'English'): Promise<PhrasebookResponse | null> => {
  const prompt = `
    Generate a list of 10 essential travel phrases for a tourist.
    The category is: "${category}".
    The source language is ${sourceLang}.
    The target language for translation is ${targetLang}.
    For each phrase, provide the source phrase, the translated phrase, and a simple, easy-to-read phonetic pronunciation guide for the translation.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: phrasebookSchema,
      },
    });

    const jsonText = response.text.trim();
    return JSON.parse(jsonText) as PhrasebookResponse;
  } catch (error) {
    console.error("Error generating phrasebook:", error);
    return null;
  }
};

const menuAnalysisSchema = {
  type: Type.OBJECT,
  properties: {
    menu_items: {
      type: Type.ARRAY,
      description: "A list of items found on the menu.",
      items: {
        type: Type.OBJECT,
        properties: {
          item_name: { type: Type.STRING, description: "The original name of the menu item as it appears on the menu." },
          translation: { type: Type.STRING, description: "The English translation of the menu item name." },
          description: { type: Type.STRING, description: "A brief, appealing one-sentence description of the dish." },
          calorie_estimate: { type: Type.INTEGER, description: "A rough estimate of the calorie count for the dish." },
        },
        required: ["item_name", "translation", "description", "calorie_estimate"],
      }
    }
  },
  required: ["menu_items"],
};

export const analyzeMenuImage = async (base64Image: string): Promise<MenuAnalysisResponse | null> => {
  const imagePart = {
    inlineData: {
      mimeType: 'image/jpeg',
      data: base64Image,
    },
  };
  const textPart = {
    text: `Analyze the attached menu image. Perform OCR to identify each menu item. For each distinct item, provide the following:
    1. The original item name.
    2. A translation of the item name into English.
    3. A brief, one-sentence description of what the dish is.
    4. An estimated calorie count as an integer.
    Return the result as a JSON object that strictly follows the provided schema. If the image is not a menu or is unreadable, return an empty list for "menu_items".`
  };

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: { parts: [imagePart, textPart] },
      config: {
        responseMimeType: 'application/json',
        responseSchema: menuAnalysisSchema,
      }
    });
    
    const jsonText = response.text.trim();
    return JSON.parse(jsonText) as MenuAnalysisResponse;
  } catch (error) {
    console.error("Error analyzing menu image:", error);
    return null;
  }
};

const souvenirSchema = {
  type: Type.OBJECT,
  properties: {
    suggestions: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          souvenir_name: { type: Type.STRING },
          description: { type: Type.STRING, description: "Why this is a great and authentic souvenir." },
          shop_name: { type: Type.STRING, description: "A specific, real or plausible shop, market, or district to find it." },
          shop_location: { type: Type.STRING, description: "Neighborhood or address of the shop." },
          price_range: { type: Type.STRING, description: "e.g., 'Budget-friendly', 'Mid-range', 'Premium'" },
          category: { type: Type.STRING, enum: ['Craft', 'Food', 'Fashion', 'Pop Culture', 'Unique'] }
        },
        required: ["souvenir_name", "description", "shop_name", "shop_location", "price_range", "category"],
      }
    }
  },
  required: ["suggestions"],
};

export const findSouvenirs = async (location: string, recipient: string, interests: string, budget: string): Promise<SouvenirResponse | null> => {
  const prompt = `
    Act as a local shopping expert for a tourist in ${location}.
    They are looking for a souvenir for: "${recipient}".
    The recipient's interests are: "${interests}".
    The traveler's budget is: "${budget}".

    Suggest 3-4 unique, authentic, and thoughtful souvenir ideas.
    For each suggestion, provide:
    1. The name of the souvenir.
    2. A brief description of why it's a good choice.
    3. The name of a specific, realistic shop, market, or district where it can be found.
    4. The location of that shop/market.
    5. A general price range.
    6. A relevant category for the item.

    Return the result as a JSON object that strictly follows the provided schema.
  `;
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: souvenirSchema,
      }
    });
    const jsonText = response.text.trim();
    return JSON.parse(jsonText) as SouvenirResponse;
  } catch (error) {
    console.error("Error finding souvenirs:", error);
    return null;
  }
};

const jetLagPlanSchema = {
  type: Type.OBJECT,
  properties: {
    plan_title: { type: Type.STRING, description: "A title for the plan, e.g., 'Your Personalized Plan to Conquer Jet Lag'." },
    plan_summary: { type: Type.STRING, description: "A brief, encouraging summary of the jet lag strategy." },
    plan_phases: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          phase_name: { type: Type.STRING, enum: ['Pre-Flight Adjustment', 'During The Flight', 'Post-Flight Recovery'] },
          actions: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                time_description: { type: Type.STRING, description: "When to perform the action, e.g., '3 days before departure', 'Upon boarding', '9:00 AM local time'." },
                action_title: { type: Type.STRING, description: "A short title for the action, e.g., 'Seek Morning Light'." },
                action_description: { type: Type.STRING, description: "A detailed explanation of the action and its benefits." },
                category: { type: Type.STRING, enum: ['Light', 'Sleep', 'Nutrition', 'Activity', 'Other'] }
              },
              required: ["time_description", "action_title", "action_description", "category"],
            }
          }
        },
        required: ["phase_name", "actions"],
      }
    }
  },
  required: ["plan_title", "plan_summary", "plan_phases"],
};

export const generateJetLagPlan = async (
    departureCity: string,
    arrivalCity: string,
    departureTime: string,
    arrivalTime: string,
    usualWakeTime: string,
    usualSleepTime: string
): Promise<JetLagPlanResponse | null> => {
  const prompt = `
    Act as a chronobiology and travel wellness expert. Create a personalized, science-based jet lag mitigation plan for the following trip:
    - Departure: ${departureCity} at ${departureTime}
    - Arrival: ${arrivalCity} at ${arrivalTime}
    - Traveler's normal schedule: Wakes at ${usualWakeTime}, Sleeps at ${usualSleepTime}.

    The plan should be broken down into three phases: 'Pre-Flight Adjustment', 'During The Flight', and 'Post-Flight Recovery'.
    For each phase, provide a list of specific, timed, and actionable recommendations.
    These actions should cover key areas for managing circadian rhythms: light exposure (most important), sleep schedule, nutrition (e.g., caffeine, meal timing), hydration, and physical activity.
    Make the advice clear, concise, and easy for a traveler to follow.
    Return the result as a JSON object that strictly follows the provided schema.
  `;
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: jetLagPlanSchema,
      }
    });
    const jsonText = response.text.trim();
    return JSON.parse(jsonText) as JetLagPlanResponse;
  } catch (error) {
    console.error("Error generating jet lag plan:", error);
    return null;
  }
};
