import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { Booking, Expense, TripMember, MoodEntry, JournalEntry } from '../types';
import * as apiService from '../services/apiService';
import { MOCK_BOOKINGS_DATA } from '../data/mockData';

interface TripContextType {
  isLoading: boolean;
  bookings: Booking[];
  expenses: Expense[];
  members: TripMember[];
  moodEntries: MoodEntry[];
  journalEntries: JournalEntry[];
  addBooking: (booking: Booking) => Promise<void>;
  updateBooking: (booking: Booking) => Promise<void>;
  deleteBooking: (bookingId: number) => Promise<void>;
  addExpense: (expense: Omit<Expense, 'id'>) => Promise<void>;
  addMember: (name: string) => Promise<void>;
  addMoodEntry: (entry: Omit<MoodEntry, 'id'>) => Promise<void>;
  updateJournalEntry: (entry: JournalEntry) => Promise<void>;
}

const TripContext = createContext<TripContextType | undefined>(undefined);

const initialMembers = [
  { id: 1, name: 'Alex' },
  { id: 2, name: 'Ben' },
  { id: 3, name: 'Chloe' },
];

const initialExpenses = [
  { id: 1, description: 'Dinner at Shibuya Crossing', amount: 12000, currency: 'JPY', paidBy: 1, splitBetween: [1, 2, 3], category: 'Food' as const },
  { id: 2, description: 'Ghibli Museum Tickets', amount: 40, currency: 'EUR', paidBy: 2, splitBetween: [1, 2, 3], category: 'Activities' as const },
  { id: 3, description: 'Train from Narita', amount: 60, currency: 'USD', paidBy: 1, splitBetween: [1, 2], category: 'Transport' as const },
  { id: 4, description: 'Hotel Stay', amount: 420, currency: 'GBP', paidBy: 3, splitBetween: [1, 2, 3], category: 'Accommodation' as const },
];

export const TripProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [members, setMembers] = useState<TripMember[]>(initialMembers);
  const [moodEntries, setMoodEntries] = useState<MoodEntry[]>([]);
  const [journalEntries, setJournalEntries] = useState<JournalEntry[]>([]);

  useEffect(() => {
    const loadData = async () => {
      try {
        // Check if user is authenticated
        const token = apiService.getAuthToken();
        if (!token) {
          console.log('No auth token, skipping backend data load');
          setIsLoading(false);
          return;
        }

        // Load data from backend
        const [backendBookings, backendExpenses, backendMoods] = await Promise.all([
          apiService.getBookings().catch(() => []),
          apiService.getExpenses().catch(() => []),
          apiService.getMoodEntries().catch(() => []),
        ]);

        setBookings(backendBookings);
        setExpenses(backendExpenses);
        setMoodEntries(backendMoods);

      } catch (error) {
        console.error("Failed to load data from backend", error);
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, []);

  const addBooking = async (booking: Booking) => {
    try {
      const bookingData = {
        booking_type: booking.type,
        details: booking,
        confirmation_number: booking.confirmationNumber || '',
      };
      const savedBooking = await apiService.createBooking(bookingData);
      setBookings(prev => [booking, ...prev]);
    } catch (error) {
      console.error('Failed to save booking:', error);
      // Still add to local state for better UX
      setBookings(prev => [booking, ...prev]);
    }
  };

  const updateBooking = async (updatedBooking: Booking) => {
    try {
      const bookingData = {
        booking_type: updatedBooking.type,
        details: updatedBooking,
        confirmation_number: updatedBooking.confirmationNumber || '',
      };
      await apiService.updateBooking(updatedBooking.id, bookingData);
      setBookings(prev => prev.map(b => b.id === updatedBooking.id ? updatedBooking : b));
    } catch (error) {
      console.error('Failed to update booking:', error);
      setBookings(prev => prev.map(b => b.id === updatedBooking.id ? updatedBooking : b));
    }
  };

  const deleteBooking = async (bookingId: number) => {
    try {
      await apiService.deleteBooking(bookingId);
      setBookings(prev => prev.filter(b => b.id !== bookingId));
    } catch (error) {
      console.error('Failed to delete booking:', error);
      setBookings(prev => prev.filter(b => b.id !== bookingId));
    }
  };

  const addExpense = async (expense: Omit<Expense, 'id'>) => {
    try {
      const expenseData = {
        amount: expense.amount.toString(),
        currency: expense.currency,
        category: expense.category,
        note: expense.description,
      };
      const savedExpense = await apiService.createExpense(expenseData);
      const newExpense = { ...expense, id: savedExpense.id || Date.now() };
      setExpenses(prev => [newExpense, ...prev]);
    } catch (error) {
      console.error('Failed to save expense:', error);
      const newExpense = { ...expense, id: Date.now() };
      setExpenses(prev => [newExpense, ...prev]);
    }
  };

  const addMember = async (name: string) => {
    if (name.trim() && !members.find(m => m.name === name.trim())) {
      const newMember = { id: Date.now(), name: name.trim() };
      setMembers(prev => [...prev, newMember]);
    }
  };

  const addMoodEntry = async (entry: Omit<MoodEntry, 'id'>) => {
    try {
      const moodData = {
        mood: entry.mood,
        note: `${entry.location ? `Location: ${entry.location}. ` : ''}${entry.activities.length > 0 ? `Activities: ${entry.activities.join(', ')}. ` : ''}${entry.notes || ''}`,
      };
      const savedMood = await apiService.createMoodEntry(moodData);
      const newEntry = { ...entry, id: savedMood.id || Date.now() };
      setMoodEntries(prev => [newEntry, ...prev]);
    } catch (error) {
      console.error('Failed to save mood entry:', error);
      const newEntry = { ...entry, id: Date.now() };
      setMoodEntries(prev => [newEntry, ...prev]);
    }
  };

  const updateJournalEntry = async (entry: JournalEntry) => {
    setJournalEntries(prev => {
      const existingIndex = prev.findIndex(j => j.bookingId === entry.bookingId);
      if (existingIndex > -1) {
        const newState = [...prev];
        newState[existingIndex] = entry;
        return newState;
      }
      return [...prev, entry];
    });
  };

  const value = {
    isLoading,
    bookings,
    expenses,
    members,
    moodEntries,
    journalEntries,
    addBooking,
    updateBooking,
    deleteBooking,
    addExpense,
    addMember,
    addMoodEntry,
    updateJournalEntry
  };

  return (
    <TripContext.Provider value={value}>
      {isLoading ? (
        <div className="flex items-center justify-center h-screen w-full bg-[#1a1818] text-[#a3a3a3]">
          <div className="flex items-center gap-3">
            <div className="h-6 w-6 border-2 border-t-transparent border-[#ff8c00] rounded-full animate-spin"></div>
            <span>Loading Trip Data...</span>
          </div>
        </div>
      ) : children}
    </TripContext.Provider>
  );
};

export const useTrip = (): TripContextType => {
  const context = useContext(TripContext);
  if (!context) {
    throw new Error('useTrip must be used within a TripProvider');
  }
  return context;
};