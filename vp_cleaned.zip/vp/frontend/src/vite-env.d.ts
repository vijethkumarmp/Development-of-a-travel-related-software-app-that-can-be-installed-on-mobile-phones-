// FIX: Removed reference to "vite/client" which was causing a type error and was not used.

declare global {
  interface AIStudio {
    hasSelectedApiKey: () => Promise<boolean>;
    openSelectKey: () => Promise<void>;
  }

  interface Window {
    aistudio?: AIStudio;
  }
}

// Add an empty export to ensure this file is treated as a module, which is required for global augmentation.
export {};