/**
 * API Service - Handles all communication with the Django backend
 * Backend URL: http://localhost:8000/api/
 */

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000/api';

// Store authentication token
let authToken: string | null = localStorage.getItem('authToken') || null;

export const setAuthToken = (token: string) => {
  authToken = token;
  localStorage.setItem('authToken', token);
};

export const clearAuthToken = () => {
  authToken = null;
  localStorage.removeItem('authToken');
};

export const getAuthToken = () => {
  return authToken;
};

/**
 * Generic API request function
 */
const apiCall = async (
  endpoint: string,
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH' = 'GET',
  data?: any
): Promise<any> => {
  const url = `${API_BASE_URL}${endpoint}`;
  
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  };

  if (authToken) {
    headers['Authorization'] = `Bearer ${authToken}`;
  }

  const config: RequestInit = {
    method,
    headers,
  };

  if (data && (method === 'POST' || method === 'PUT' || method === 'PATCH')) {
    config.body = JSON.stringify(data);
  }

  try {
    const response = await fetch(url, config);

    if (!response.ok) {
      if (response.status === 401) {
        // Unauthorized - clear token and redirect to login
        clearAuthToken();
        window.location.href = '/login';
      }
      const error = await response.json().catch(() => ({ detail: 'Unknown error' }));
      throw new Error(error.detail || `HTTP Error: ${response.status}`);
    }

    // Handle 204 No Content
    if (response.status === 204) {
      return null;
    }

    return await response.json();
  } catch (error) {
    console.error(`API Error [${method} ${endpoint}]:`, error);
    throw error;
  }
};

// ============================================================================
// USER PROFILE ENDPOINTS
// ============================================================================

export const getUserProfile = () => {
  return apiCall('/userprofiles/', 'GET');
};

export const updateUserProfile = (data: any) => {
  return apiCall('/userprofiles/', 'PUT', data);
};

// ============================================================================
// ITINERARY ENDPOINTS
// ============================================================================

export const getItineraries = () => {
  return apiCall('/itineraries/', 'GET');
};

export const getItinerary = (id: string | number) => {
  return apiCall(`/itineraries/${id}/`, 'GET');
};

export const createItinerary = (data: any) => {
  return apiCall('/itineraries/', 'POST', data);
};

export const updateItinerary = (id: string | number, data: any) => {
  return apiCall(`/itineraries/${id}/`, 'PUT', data);
};

export const deleteItinerary = (id: string | number) => {
  return apiCall(`/itineraries/${id}/`, 'DELETE');
};

export const generateItinerarySuggestion = (location_query: string) => {
  return apiCall('/itineraries/generate_suggestion/', 'POST', { location_query });
};

// ============================================================================
// TRANSLATION ENDPOINTS
// ============================================================================

export const getTranslations = () => {
  return apiCall('/translations/', 'GET');
};

export const translateText = (source_text: string, target_language: string) => {
  return apiCall('/translations/translate_text/', 'POST', {
    source_text,
    target_language,
  });
};

// ============================================================================
// LIVE GUIDE ENDPOINTS
// ============================================================================

export const getLiveGuideQueries = () => {
  return apiCall('/live-guides/', 'GET');
};

export const askLiveGuideQuestion = (location: string, query: string) => {
  return apiCall('/live-guides/ask_question/', 'POST', { location, query });
};

// ============================================================================
// PACKING LIST ENDPOINTS
// ============================================================================

export const getPackingLists = () => {
  return apiCall('/packing-lists/', 'GET');
};

export const createPackingList = (data: any) => {
  return apiCall('/packing-lists/', 'POST', data);
};

export const updatePackingList = (id: string | number, data: any) => {
  return apiCall(`/packing-lists/${id}/`, 'PUT', data);
};

export const deletePackingList = (id: string | number) => {
  return apiCall(`/packing-lists/${id}/`, 'DELETE');
};

// ============================================================================
// SOUVENIR ENDPOINTS
// ============================================================================

export const getSouvenirs = () => {
  return apiCall('/souvenirs/', 'GET');
};

export const generateSouvenirSuggestion = (location: string) => {
  return apiCall('/souvenirs/generate_suggestion/', 'POST', { location });
};

// ============================================================================
// JET LAG PLAN ENDPOINTS
// ============================================================================

export const getJetLagPlans = () => {
  return apiCall('/jetlag-plans/', 'GET');
};

export const generateJetLagPlan = (data: any) => {
  return apiCall('/jetlag-plans/generate_plan/', 'POST', data);
};

// ============================================================================
// BOOKING ENDPOINTS
// ============================================================================

export const getBookings = () => {
  return apiCall('/bookings/', 'GET');
};

export const createBooking = (data: any) => {
  return apiCall('/bookings/', 'POST', data);
};

export const updateBooking = (id: string | number, data: any) => {
  return apiCall(`/bookings/${id}/`, 'PUT', data);
};

export const deleteBooking = (id: string | number) => {
  return apiCall(`/bookings/${id}/`, 'DELETE');
};

// ============================================================================
// EXPENSE ENDPOINTS
// ============================================================================

export const getExpenses = () => {
  return apiCall('/expenses/', 'GET');
};

export const createExpense = (data: any) => {
  return apiCall('/expenses/', 'POST', data);
};

export const updateExpense = (id: string | number, data: any) => {
  return apiCall(`/expenses/${id}/`, 'PUT', data);
};

export const deleteExpense = (id: string | number) => {
  return apiCall(`/expenses/${id}/`, 'DELETE');
};

// ============================================================================
// MOOD ENTRY ENDPOINTS
// ============================================================================

export const getMoodEntries = () => {
  return apiCall('/moods/', 'GET');
};

export const createMoodEntry = (data: any) => {
  return apiCall('/moods/', 'POST', data);
};

export const deleteMoodEntry = (id: string | number) => {
  return apiCall(`/moods/${id}/`, 'DELETE');
};

// ============================================================================
// OFFLINE MAP ENDPOINTS
// ============================================================================

export const getOfflineMaps = () => {
  return apiCall('/offline-maps/', 'GET');
};

export const createOfflineMapDownload = (data: any) => {
  return apiCall('/offline-maps/', 'POST', data);
};

// ============================================================================
// SCRAPBOOK ENDPOINTS
// ============================================================================

export const getScrapbookEntries = () => {
  return apiCall('/scrapbook-entries/', 'GET');
};

export const createScrapbookEntry = (data: any) => {
  return apiCall('/scrapbook-entries/', 'POST', data);
};

export const updateScrapbookEntry = (id: string | number, data: any) => {
  return apiCall(`/scrapbook-entries/${id}/`, 'PUT', data);
};

export const deleteScrapbookEntry = (id: string | number) => {
  return apiCall(`/scrapbook-entries/${id}/`, 'DELETE');
};

// ============================================================================
// SOS CONTACT ENDPOINTS
// ============================================================================

export const getSOSContacts = () => {
  return apiCall('/sos-contacts/', 'GET');
};

export const createSOSContact = (data: any) => {
  return apiCall('/sos-contacts/', 'POST', data);
};

export const updateSOSContact = (id: string | number, data: any) => {
  return apiCall(`/sos-contacts/${id}/`, 'PUT', data);
};

export const deleteSOSContact = (id: string | number) => {
  return apiCall(`/sos-contacts/${id}/`, 'DELETE');
};

// ============================================================================
// AUTHENTICATION ENDPOINTS
// ============================================================================

export const getToken = (username: string, password: string) => {
  return fetch(`${API_BASE_URL}/token/`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ username, password }),
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error('Invalid credentials');
      }
      return response.json();
    })
    .then((data) => {
      if (data.access) {
        setAuthToken(data.access);
      }
      return data;
    });
};

export const registerUser = (username: string, email: string, password: string) => {
  return fetch(`${API_BASE_URL}/register/`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ username, email, password }),
  })
    .then((response) => {
      if (!response.ok) {
        return response.json().then((error) => {
          throw new Error(error.error || 'Registration failed');
        });
      }
      return response.json();
    });
};

export const refreshToken = (refresh: string) => {
  return fetch(`${API_BASE_URL}/token/refresh/`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ refresh }),
  }).then((response) => {
    if (!response.ok) {
      throw new Error('Token refresh failed');
    }
    return response.json();
  });
};
