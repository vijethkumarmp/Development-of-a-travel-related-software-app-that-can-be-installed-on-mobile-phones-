import { Booking } from '../types';

export const MOCK_BOOKINGS_DATA: Booking[] = [
  {
    id: 1, type: 'Flight', airline: 'VoyageAir', flightNumber: 'VA 2042', confirmationNumber: 'XYZ789',
    departure: { airport: 'San Francisco Intl', code: 'SFO', dateTime: '2024-08-15T10:30:00Z' },
    arrival: { airport: 'Tokyo Narita', code: 'NRT', dateTime: '2024-08-16T14:45:00Z' },
    attachments: [],
  },
  {
    id: 2, type: 'Hotel', hotelName: 'Shibuya Grand Hotel, Tokyo', address: '2 Chome-24-1 Dogenzaka, Tokyo',
    checkInDate: '2022-08-16', checkOutDate: '2022-08-22', confirmationNumber: 'VK-982374',
    attachments: [],
  },
  {
    id: 3, type: 'Car Rental', company: 'Nippon Rent-A-Car', pickupLocation: 'Narita Airport (NRT)',
    dropoffLocation: 'Shinjuku Station', pickupDateTime: '2024-08-22T10:00:00Z', dropoffDateTime: '2024-08-25T17:00:00Z',
    confirmationNumber: 'CAR-55443',
    attachments: [],
  },
  {
    id: 4, type: 'Activity', name: 'Ghibli Museum Tour', location: 'Mitaka, Tokyo', date: '2023-08-18', time: '14:00',
    confirmationNumber: 'ACT-GHIB-1029',
    attachments: [],
  },
   {
    id: 6, type: 'Cab', cabCompany: 'GoRide Cabs', pickupLocation: 'Narita Airport (NRT)',
    dropoffLocation: 'Shibuya Grand Hotel, Tokyo', pickupDateTime: '2024-08-16T15:30:00Z',
    confirmationNumber: 'CAB-99887', driverName: 'K. Tanaka', driverContact: '+81 80-1234-5678',
    bookingLink: 'https://www.uber.com/',
    attachments: [],
  },
  {
    id: 5, type: 'Flight', airline: 'VoyageAir', flightNumber: 'VA 2043', confirmationNumber: 'ABC123',
    departure: { airport: 'Tokyo Narita', code: 'NRT', dateTime: '2024-08-25T20:00:00Z' },
    arrival: { airport: 'San Francisco Intl', code: 'SFO', dateTime: '2024-08-25T13:30:00Z' },
    attachments: [],
  },
];