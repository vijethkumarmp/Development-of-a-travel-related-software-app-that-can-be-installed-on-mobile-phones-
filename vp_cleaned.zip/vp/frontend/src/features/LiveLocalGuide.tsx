
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Message } from '../types';
import { getProactiveSuggestion } from '../services/geminiService';
import { useTrip } from '../context/TripContext';
import { LiveGuideIcon } from '../components/icons/LiveGuideIcon';
import { LocationPinIcon } from '../components/icons/LocationPinIcon';
import { LockClosedIcon } from '../components/icons/LockClosedIcon';
import { SparklesIcon } from '../components/icons/SparklesIcon';

// --- Helper Functions ---
const getDistanceFromLatLonInMeters = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371e3; // metres
    const φ1 = lat1 * Math.PI/180;
    const φ2 = lat2 * Math.PI/180;
    const Δφ = (lat2-lat1) * Math.PI/180;
    const Δλ = (lon2-lon1) * Math.PI/180;
    const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ/2) * Math.sin(Δλ/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c; // in metres
};

// --- Mock Data ---
const MOCK_POIS = [
    { name: 'Ghibli Museum', lat: 35.6963, lon: 139.5704, itineraryMatch: 'Ghibli Museum Tour' },
    { name: 'Shibuya Crossing', lat: 35.6595, lon: 139.7005, itineraryMatch: 'Shibuya Crossing' },
    { name: 'Shibuya Grand Hotel', lat: 35.658, lon: 139.699, itineraryMatch: 'Shibuya Grand Hotel' },
];

const LiveLocalGuide: React.FC = () => {
    const [messages, setMessages] = useState<Message[]>([
        { sender: 'bot', text: "Hello! As you explore, I'll provide timely tips and info right here. You can also ask me anything about local culture or language." }
    ]);
    const [input, setInput] = useState('');
    const [isAISpeaking, setIsAISpeaking] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const [location, setLocation] = useState<{ lat: number, lon: number } | null>(null);
    const [locationError, setLocationError] = useState<string | null>(null);
    const [permissionDenied, setPermissionDenied] = useState(false);
    
    const { bookings } = useTrip();
    const lastSuggestionRef = useRef<string | null>(null);

    const startLocationWatcher = useCallback(() => {
        let watchId: number | null = null;
        if (navigator.geolocation && navigator.geolocation.watchPosition) {
            setPermissionDenied(false);
            watchId = navigator.geolocation.watchPosition(
                (position) => {
                    setLocation({
                        lat: position.coords.latitude,
                        lon: position.coords.longitude,
                    });
                    setLocationError(null);
                },
                (err) => {
                    console.error("Error watching location:", err);
                    let errorMessage = "An unknown error occurred while tracking location.";
                    switch (err.code) {
                        case err.PERMISSION_DENIED:
                            errorMessage = "Location permission is required for the Live Guide. Please enable it in your browser settings.";
                            setPermissionDenied(true);
                            break;
                        case err.POSITION_UNAVAILABLE:
                            errorMessage = "Location information is currently unavailable.";
                            break;
                        case err.TIMEOUT:
                            errorMessage = "The request to get user location timed out.";
                            break;
                    }
                    setLocationError(errorMessage);
                },
                { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
            );
        } else {
            setLocationError("Geolocation is not supported by your browser.");
        }
        return watchId;
    }, []);

    useEffect(() => {
        const watchId = startLocationWatcher();

        return () => {
            if (watchId !== null) {
                navigator.geolocation.clearWatch(watchId);
            }
        };
    }, [startLocationWatcher]);

    useEffect(() => {
        const interval = setInterval(async () => {
            if (!location || isAISpeaking) return;

            // Check for proximity to POIs
            for (const poi of MOCK_POIS) {
                const distance = getDistanceFromLatLonInMeters(location.lat, location.lon, poi.lat, poi.lon);
                if (distance < 200 && lastSuggestionRef.current !== poi.name) { // within 200 meters and not already suggested
                    lastSuggestionRef.current = poi.name; // Mark as suggested
                    setIsAISpeaking(true);
                    
                    const context = {
                        location: `near ${poi.name}`,
                        time: new Date().toLocaleTimeString(),
                        itineraryItem: poi.itineraryMatch,
                        previousMessages: messages,
                    };

                    const suggestion = await getProactiveSuggestion(context);
                    setMessages(prev => [...prev, { sender: 'bot', text: suggestion }]);
                    setIsAISpeaking(false);
                    return; // Only one suggestion at a time
                }
            }
        }, 10000); // Check every 10 seconds

        return () => clearInterval(interval);
    }, [location, isAISpeaking, bookings, messages]);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };
    useEffect(scrollToBottom, [messages]);
    
    const handleSendMessage = async () => {
        if (input.trim() === '' || isAISpeaking) return;
        const userMessage: Message = { sender: 'user', text: input.trim() };
        const currentMessages = [...messages, userMessage];
        setMessages(currentMessages);
        setInput('');
        setIsAISpeaking(true);

        const context = {
            location: location ? `lat: ${location.lat}, lon: ${location.lon}` : 'unknown',
            time: new Date().toLocaleTimeString(),
            itineraryItem: 'User is asking a question.',
            previousMessages: currentMessages,
        };

        const botResponseText = await getProactiveSuggestion(context);
        const botMessage: Message = { sender: 'bot', text: botResponseText };
        setMessages(prev => [...prev, botMessage]);
        setIsAISpeaking(false);
    };

    const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter') handleSendMessage();
    };

    return (
        <div className="flex flex-col h-full max-w-6xl mx-auto">
            <div className="text-center mb-6">
                <LiveGuideIcon className="h-12 w-12 mx-auto text-[#ff8c00] mb-2"/>
                <h1 className="text-4xl font-bold text-[#f5f5f5]">Live Local Guide</h1>
                <p className="mt-2 text-lg text-[#a3a3a3]/70">Your proactive AI companion for on-the-ground exploration.</p>
            </div>
            
            <div className="flex-1 solaris-panel flex overflow-hidden">
                {/* Map View */}
                <div className="w-1/3 border-r border-[#444] flex-shrink-0 relative bg-[#1a1818]/50 flex flex-col items-center justify-center p-4">
                    {location && (
                        <>
                            <div className="relative w-48 h-48 border-2 border-dashed border-[#444] rounded-full flex items-center justify-center">
                                <div className="absolute h-2 w-2 bg-[#ff8c00] rounded-full animate-ping"></div>
                                <div className="absolute h-3 w-3 bg-[#ff8c00] rounded-full border-2 border-[#1a1818]"></div>
                            </div>
                            <div className="text-center mt-4">
                                <p className="font-semibold text-[#f5f5f5]">Live Location Active</p>
                                <p className="text-xs text-[#a3a3a3]/70 font-mono">Lat: {location.lat.toFixed(4)}, Lon: {location.lon.toFixed(4)}</p>
                            </div>
                        </>
                    )}
                    {locationError && (
                        <div className="text-center text-red-400 p-4">
                            {permissionDenied ? (
                                <>
                                    <LockClosedIcon className="h-8 w-8 mx-auto mb-2"/>
                                    <p className="text-sm font-semibold mb-4">{locationError}</p>
                                    <button onClick={startLocationWatcher} className="px-4 py-2 bg-[#ff8c00] text-white rounded-md font-semibold hover:bg-[#e67e00] text-sm">Retry Permission</button>
                                </>
                            ) : (
                                <p>{locationError}</p>
                            )}
                        </div>
                    )}
                    {!location && !locationError && (
                        <div className="text-center text-[#a3a3a3]/70">
                            <LocationPinIcon className="h-8 w-8 mx-auto mb-2 animate-pulse"/>
                            <p>Acquiring your location...</p>
                        </div>
                    )}
                </div>

                {/* Chat View */}
                <div className="flex-1 flex flex-col p-4 overflow-hidden">
                    <div className="flex-1 overflow-y-auto space-y-4 pr-2">
                        {messages.map((msg, index) => (
                            <div key={index} className={`flex items-end gap-2 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                                {msg.sender === 'bot' && (
                                    <div className="h-8 w-8 rounded-full bg-[#ff8c00]/10 flex items-center justify-center text-[#ff8c00] flex-shrink-0">
                                        <SparklesIcon className="h-4 w-4" />
                                    </div>
                                )}
                                <div className={`max-w-md px-4 py-2 rounded-2xl ${msg.sender === 'user' ? 'bg-[#ff8c00] text-white rounded-br-none' : 'bg-[#333]/70 text-[#f5f5f5] rounded-bl-none'}`}>
                                    <p className="text-sm" dangerouslySetInnerHTML={{ __html: msg.text.replace(/\n/g, '<br />') }} />
                                </div>
                            </div>
                        ))}
                        {isAISpeaking && (
                            <div className="flex items-end gap-2 justify-start">
                                <div className="h-8 w-8 rounded-full bg-[#ff8c00]/10 flex items-center justify-center text-[#ff8c00] flex-shrink-0">
                                    <SparklesIcon className="h-4 w-4" />
                                </div>
                                <div className="max-w-md px-4 py-2 rounded-2xl bg-[#333]/70 text-[#f5f5f5] rounded-bl-none">
                                    <div className="flex items-center space-x-1">
                                        <div className="h-2 w-2 bg-[#a3a3a3]/70 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                                        <div className="h-2 w-2 bg-[#a3a3a3]/70 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                                        <div className="h-2 w-2 bg-[#a3a3a3]/70 rounded-full animate-bounce"></div>
                                    </div>
                                </div>
                            </div>
                        )}
                        <div ref={messagesEndRef} />
                    </div>
                    <div className="mt-4 border-t border-[#444] pt-4">
                        <div className="relative">
                            <input
                                type="text"
                                value={input}
                                onChange={(e) => setInput(e.target.value)}
                                onKeyPress={handleKeyPress}
                                placeholder="Ask for a translation or about a local custom..."
                                className="w-full bg-[#333]/50 border border-[#444] rounded-full py-2 pl-4 pr-12 text-[#f5f5f5] focus:outline-none focus:ring-2 focus:ring-[#ff8c00]"
                                disabled={isAISpeaking}
                            />
                            <button
                                onClick={handleSendMessage}
                                disabled={isAISpeaking}
                                className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 bg-[#ff8c00] text-white rounded-full flex items-center justify-center hover:bg-[#e67e00] disabled:bg-[#ff8c00]/50"
                            >
                                ↑
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default LiveLocalGuide;