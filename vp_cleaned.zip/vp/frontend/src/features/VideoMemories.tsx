import React, { useState, useEffect, useRef } from 'react';
import { VideoIcon } from '../components/icons/VideoIcon';
import { SparklesIcon } from '../components/icons/SparklesIcon';
import { generateVideoFromImage } from '../services/geminiService';
import { KeyIcon } from '../components/icons/KeyIcon';
import { CameraIcon } from '../components/icons/CameraIcon';

const loadingMessages = [
    "Warming up the digital film...",
    "Composing the perfect shot...",
    "Consulting with the director...",
    "Rendering the final cut...",
    "This can take a few minutes, good things take time!",
    "Adding a touch of cinematic magic...",
    "Almost there, preparing for the premiere..."
];

const VideoMemories: React.FC = () => {
    const [apiKeySelected, setApiKeySelected] = useState(false);
    const [isCheckingKey, setIsCheckingKey] = useState(true);

    const [imageFile, setImageFile] = useState<File | null>(null);
    const [imagePreview, setImagePreview] = useState<string | null>(null);
    const [prompt, setPrompt] = useState('A gentle breeze makes the scene come alive.');
    const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16'>('16:9');
    
    const [isLoading, setIsLoading] = useState(false);
    const [loadingMessage, setLoadingMessage] = useState(loadingMessages[0]);
    const [error, setError] = useState<string | null>(null);
    const [videoUrl, setVideoUrl] = useState<string | null>(null);

    const loadingIntervalRef = useRef<number | null>(null);
    
    // Check for API key on component mount
    useEffect(() => {
        const checkKey = async () => {
            if (window.aistudio) {
                const hasKey = await window.aistudio.hasSelectedApiKey();
                setApiKeySelected(hasKey);
            }
            setIsCheckingKey(false);
        };
        checkKey();
    }, []);
    
    // Cycle through loading messages
    useEffect(() => {
        if (isLoading) {
            loadingIntervalRef.current = window.setInterval(() => {
                setLoadingMessage(prev => {
                    const currentIndex = loadingMessages.indexOf(prev);
                    const nextIndex = (currentIndex + 1) % loadingMessages.length;
                    return loadingMessages[nextIndex];
                });
            }, 4000);
        } else if (loadingIntervalRef.current) {
            clearInterval(loadingIntervalRef.current);
            loadingIntervalRef.current = null;
        }
        return () => {
            if (loadingIntervalRef.current) clearInterval(loadingIntervalRef.current);
        }
    }, [isLoading]);

    const handleSelectKey = async () => {
        if (window.aistudio) {
            await window.aistudio.openSelectKey();
            // Assume success and update UI immediately to avoid race conditions
            setApiKeySelected(true);
        }
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setImageFile(file);
            const reader = new FileReader();
            reader.onloadend = () => {
                setImagePreview(reader.result as string);
            };
            reader.readAsDataURL(file);
        }
    };
    
    const fileToBase64 = (file: File): Promise<{base64: string, mimeType: string}> => {
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => {
            const result = reader.result as string;
            const mimeType = result.split(';')[0].split(':')[1];
            const base64 = result.split(',')[1];
            resolve({ base64, mimeType });
        };
        reader.onerror = error => reject(error);
      });
    };

    const handleSubmit = async () => {
        if (!imageFile) {
            setError('Please upload an image first.');
            return;
        }

        setIsLoading(true);
        setError(null);
        setVideoUrl(null);
        setLoadingMessage(loadingMessages[0]);

        try {
            const { base64, mimeType } = await fileToBase64(imageFile);
            const resultUrl = await generateVideoFromImage(base64, mimeType, prompt, aspectRatio);

            if (resultUrl) {
                // The URL from the service already includes the API key
                setVideoUrl(resultUrl);
            } else {
                setError('Failed to generate video. Please try again.');
            }
        } catch (e: any) {
            if (e.message === 'API_KEY_NOT_FOUND') {
                setError('Your API key seems to be invalid. Please select it again.');
                setApiKeySelected(false); // Force re-selection
            } else {
                setError('An unexpected error occurred. Please check the console for details.');
                console.error(e);
            }
        } finally {
            setIsLoading(false);
        }
    };

    const resetForm = () => {
        setImageFile(null);
        setImagePreview(null);
        setVideoUrl(null);
        setError(null);
        setIsLoading(false);
    };

    if (isCheckingKey) {
        return (
            <div className="flex items-center justify-center h-full">
                <div className="text-center text-[#a3a3a3]">
                    <div className="h-8 w-8 mx-auto border-2 border-t-transparent border-[#ff8c00] rounded-full animate-spin"></div>
                    <p className="mt-2">Checking API key status...</p>
                </div>
            </div>
        );
    }

    if (!apiKeySelected) {
        return (
            <div className="max-w-2xl mx-auto animate-fadeIn">
                 <div className="text-center mb-8">
                    <VideoIcon className="h-12 w-12 mx-auto text-[#ff8c00] mb-2"/>
                    <h1 className="text-4xl font-bold text-[#f5f5f5]">AI Video Memories</h1>
                    <p className="mt-2 text-lg text-[#a3a3a3]/70">This premium feature uses Veo for video generation.</p>
                </div>
                <div className="solaris-panel p-8 text-center">
                    <KeyIcon className="h-10 w-10 mx-auto text-[#ff8c00] mb-4"/>
                    <h2 className="text-2xl font-bold text-[#f5f5f5]">API Key Required</h2>
                    <p className="mt-2 text-[#a3a3a3]/80">
                        To generate videos, you need to select a Google AI API key.
                        Please note that charges may apply. For more information on billing, visit{' '}
                        <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noopener noreferrer" className="text-[#ff8c00] underline hover:text-[#e67e00]">
                            ai.google.dev/gemini-api/docs/billing
                        </a>.
                    </p>
                    {error && <p className="mt-4 text-red-400">{error}</p>}
                    <button onClick={handleSelectKey} className="mt-6 w-full flex justify-center py-2.5 px-4 rounded-md font-semibold text-white bg-[#ff8c00] hover:bg-[#e67e00]">
                        Select API Key to Continue
                    </button>
                </div>
            </div>
        );
    }
    
    return (
        <div className="max-w-4xl mx-auto animate-fadeIn">
            <div className="text-center mb-8">
                <VideoIcon className="h-12 w-12 mx-auto text-[#ff8c00] mb-2"/>
                <h1 className="text-4xl font-bold text-[#f5f5f5]">AI Video Memories</h1>
                <p className="mt-2 text-lg text-[#a3a3a3]/70">Bring your travel photos to life with a touch of AI magic.</p>
            </div>
            
            <div className="solaris-panel p-6">
                {isLoading ? (
                    <div className="text-center py-16">
                        <div className="h-12 w-12 mx-auto border-4 border-t-transparent border-[#ff8c00] rounded-full animate-spin"></div>
                        <p className="mt-4 text-lg font-semibold text-[#f5f5f5]">{loadingMessage}</p>
                    </div>
                ) : videoUrl ? (
                    <div className="text-center">
                        <h2 className="text-2xl font-bold text-[#f5f5f5] mb-4">Your Video is Ready!</h2>
                        <video src={videoUrl} controls autoPlay loop className="w-full rounded-lg shadow-lg" />
                        <div className="mt-6 flex justify-center gap-4">
                            <button onClick={resetForm} className="px-6 py-2 bg-[#333]/60 text-white rounded-md font-semibold hover:bg-[#444]/60">
                                Generate Another
                            </button>
                            <a href={videoUrl} download="tripbro_video.mp4" className="px-6 py-2 bg-[#ff8c00] text-white rounded-md font-semibold hover:bg-[#e67e00]">
                                Download Video
                            </a>
                        </div>
                    </div>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                        <div>
                            <label htmlFor="image-upload" className="cursor-pointer">
                                <div className="h-64 border-2 border-dashed border-[#444] rounded-lg flex flex-col items-center justify-center text-center text-[#a3a3a3]/70 hover:bg-[#333]/50 hover:border-[#ff8c00]">
                                    {imagePreview ? (
                                        <img src={imagePreview} alt="Preview" className="h-full w-full object-cover rounded-lg" />
                                    ) : (
                                        <>
                                            <CameraIcon className="h-10 w-10 mb-2" />
                                            <p className="font-semibold">Click to upload image</p>
                                            <p className="text-xs">or drag and drop</p>
                                        </>
                                    )}
                                </div>
                            </label>
                            <input id="image-upload" type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
                        </div>
                        <div className="space-y-4">
                            <div>
                                <label htmlFor="prompt" className="block text-sm font-medium text-[#a3a3a3]">Prompt</label>
                                <textarea id="prompt" value={prompt} onChange={e => setPrompt(e.target.value)} rows={3} className="mt-1 w-full bg-[#333]/50 border border-[#444] rounded-md py-2 px-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00]" />
                            </div>
                             <div>
                                <label className="block text-sm font-medium text-[#a3a3a3]">Aspect Ratio</label>
                                <div className="mt-2 grid grid-cols-2 gap-2">
                                    <button onClick={() => setAspectRatio('16:9')} className={`py-2 rounded-md text-sm font-semibold transition-colors ${aspectRatio === '16:9' ? 'bg-[#ff8c00] text-white' : 'bg-[#333]/50 text-[#a3a3a3] hover:bg-[#444]/50'}`}>Landscape (16:9)</button>
                                    <button onClick={() => setAspectRatio('9:16')} className={`py-2 rounded-md text-sm font-semibold transition-colors ${aspectRatio === '9:16' ? 'bg-[#ff8c00] text-white' : 'bg-[#333]/50 text-[#a3a3a3] hover:bg-[#444]/50'}`}>Portrait (9:16)</button>
                                </div>
                            </div>
                            <button onClick={handleSubmit} disabled={!imageFile} className="w-full flex justify-center items-center gap-2 py-2.5 bg-[#ff8c00] text-white rounded-md font-semibold hover:bg-[#e67e00] disabled:bg-[#ff8c00]/50 disabled:cursor-not-allowed">
                                <SparklesIcon className="h-5 w-5" />
                                Generate Video
                            </button>
                            {error && <p className="text-red-400 text-sm text-center">{error}</p>}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default VideoMemories;