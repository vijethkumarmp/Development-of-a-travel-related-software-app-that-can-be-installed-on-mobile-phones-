import React, { useState } from 'react';
import { JetLagPlanResponse, JetLagActionCategory } from '../types';
import { generateJetLagPlan } from '../services/geminiService';
import { JetLagIcon } from '../components/icons/JetLagIcon';
import { SunIcon } from '../components/icons/SunIcon';
import { MoonIcon } from '../components/icons/MoonIcon';
import { CoffeeIcon } from '../components/icons/CoffeeIcon';
import { DumbbellIcon } from '../components/icons/DumbbellIcon';
import { SparklesIcon } from '../components/icons/SparklesIcon';


const getActionIcon = (category: JetLagActionCategory) => {
    const props = { className: "h-5 w-5 text-white" };
    switch(category) {
        case 'Light': return <SunIcon {...props} />;
        case 'Sleep': return <MoonIcon {...props} />;
        case 'Nutrition': return <CoffeeIcon {...props} />;
        case 'Activity': return <DumbbellIcon {...props} />;
        default: return <SparklesIcon {...props} />;
    }
};

const JetLagAssistant: React.FC = () => {
    const [plan, setPlan] = useState<JetLagPlanResponse | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    
    // Form state with default values for demonstration
    const [formState, setFormState] = useState({
        departureCity: 'San Francisco (PST)',
        arrivalCity: 'Tokyo (JST)',
        departureTime: '2024-08-15T10:30',
        arrivalTime: '2024-08-16T14:45',
        usualWakeTime: '07:00',
        usualSleepTime: '23:00'
    });

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormState(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setError(null);
        setPlan(null);

        const result = await generateJetLagPlan(
            formState.departureCity,
            formState.arrivalCity,
            formState.departureTime,
            formState.arrivalTime,
            formState.usualWakeTime,
            formState.usualSleepTime
        );
        
        setIsLoading(false);
        if (result) {
            setPlan(result);
        } else {
            setError('Failed to generate a jet lag plan. The AI might be busy, please try again.');
        }
    };

    const SkeletonLoader = () => (
        <div className="mt-8 animate-pulse">
            <div className="solaris-panel p-6">
                <div className="h-8 bg-[#333]/50 rounded-md w-3/4 mb-4"></div>
                <div className="h-4 bg-[#333]/50 rounded-md w-full mb-6"></div>
                <div className="space-y-6">
                    {[...Array(2)].map((_, i) => (
                        <div key={i}>
                            <div className="h-7 bg-[#333]/50 rounded-md w-1/3 mb-4"></div>
                            <div className="space-y-4">
                                <div className="h-16 bg-[#333]/50 rounded-md"></div>
                                <div className="h-16 bg-[#333]/50 rounded-md"></div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );

    return (
        <div className="max-w-4xl mx-auto animate-fadeIn">
            <div className="text-center mb-8">
                <JetLagIcon className="h-12 w-12 mx-auto text-[#ff8c00] mb-2"/>
                <h1 className="text-4xl font-bold text-[#f5f5f5]">AI Jet Lag Assistant</h1>
                <p className="mt-2 text-lg text-[#a3a3a3]/70">Arrive refreshed and ready to explore with a personalized, science-based plan.</p>
            </div>

            <form onSubmit={handleSubmit} className="solaris-panel p-6 space-y-4 mb-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
                    <div>
                        <label className="block text-sm font-medium text-[#a3a3a3]">Departure</label>
                        <input name="departureCity" value={formState.departureCity} onChange={handleInputChange} placeholder="City (Timezone)" required className="mt-1 w-full bg-[#333]/50 border-[#444] rounded-md py-2 px-3 text-[#f5f5f5]"/>
                        <input name="departureTime" value={formState.departureTime} onChange={handleInputChange} type="datetime-local" required className="mt-1 w-full bg-[#333]/50 border-[#444] rounded-md py-2 px-3 text-[#f5f5f5]"/>
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-[#a3a3a3]">Arrival</label>
                        <input name="arrivalCity" value={formState.arrivalCity} onChange={handleInputChange} placeholder="City (Timezone)" required className="mt-1 w-full bg-[#333]/50 border-[#444] rounded-md py-2 px-3 text-[#f5f5f5]"/>
                        <input name="arrivalTime" value={formState.arrivalTime} onChange={handleInputChange} type="datetime-local" required className="mt-1 w-full bg-[#333]/50 border-[#444] rounded-md py-2 px-3 text-[#f5f5f5]"/>
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-[#a3a3a3]">Typical Wake-up Time</label>
                        <input name="usualWakeTime" value={formState.usualWakeTime} onChange={handleInputChange} type="time" required className="mt-1 w-full bg-[#333]/50 border-[#444] rounded-md py-2 px-3 text-[#f5f5f5]"/>
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-[#a3a3a3]">Typical Bedtime</label>
                        <input name="usualSleepTime" value={formState.usualSleepTime} onChange={handleInputChange} type="time" required className="mt-1 w-full bg-[#333]/50 border-[#444] rounded-md py-2 px-3 text-[#f5f5f5]"/>
                    </div>
                </div>
                <button type="submit" disabled={isLoading} className="w-full flex justify-center py-2.5 px-4 rounded-md font-semibold text-white bg-[#ff8c00] hover:bg-[#e67e00] disabled:bg-[#ff8c00]/50">
                    {isLoading ? 'Generating Plan...' : 'Generate My Jet Lag Plan'}
                </button>
            </form>

            {isLoading && <SkeletonLoader />}
            {error && <p className="text-red-400 text-sm text-center">{error}</p>}

            {plan && (
                <div className="mt-8 solaris-panel p-6 animate-fadeIn">
                    <div className="text-center mb-6">
                        <h2 className="text-3xl font-bold text-[#f5f5f5]">{plan.plan_title}</h2>
                        <p className="mt-2 text-[#a3a3a3]/70 max-w-2xl mx-auto">{plan.plan_summary}</p>
                    </div>

                    <div className="space-y-8">
                        {plan.plan_phases.map((phase) => (
                            <div key={phase.phase_name}>
                                <h3 className="text-xl font-semibold text-[#ff8c00] border-b-2 border-[#b8860b]/50 pb-2 mb-4">{phase.phase_name}</h3>
                                <div className="relative border-l-2 border-[#b8860b]/50 ml-3">
                                    {phase.actions.map((action, index) => (
                                        <div key={index} className="mb-6 pl-10 relative">
                                            <div className="absolute -left-[13px] top-1 h-6 w-6 rounded-full bg-[#ff8c00] flex items-center justify-center ring-8 ring-[#2c2a2a]">
                                                {getActionIcon(action.category)}
                                            </div>
                                            <div>
                                                <p className="text-[#ffaf66] font-semibold">{action.time_description}</p>
                                                <h4 className="font-bold text-lg text-[#f5f5f5] mt-1">{action.action_title}</h4>
                                                <p className="text-[#a3a3a3]/70 text-sm mt-1">{action.action_description}</p>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};

export default JetLagAssistant;