import React, { useState } from 'react';
import { SouvenirSuggestion } from '../types';
import { findSouvenirs } from '../services/geminiService';
import { SouvenirIcon } from '../components/icons/SouvenirIcon';
import { SparklesIcon } from '../components/icons/SparklesIcon';
import { LocationPinIcon } from '../components/icons/LocationPinIcon';
import { FoodIcon } from '../components/icons/FoodIcon';
import { ShoppingIcon } from '../components/icons/ShoppingIcon';
import { CameraIcon } from '../components/icons/CameraIcon';
import { DefaultActivityIcon } from '../components/icons/DefaultActivityIcon';


const getCategoryIcon = (category: SouvenirSuggestion['category']) => {
    const props = { className: "h-5 w-5 text-[#ff8c00]" };
    switch(category) {
        case 'Craft': return <SparklesIcon {...props} />;
        case 'Food': return <FoodIcon {...props} />;
        case 'Fashion': return <ShoppingIcon {...props} />;
        case 'Pop Culture': return <CameraIcon {...props} />;
        default: return <DefaultActivityIcon {...props} />;
    }
}

const SouvenirFinder: React.FC = () => {
    const [location, setLocation] = useState('Tokyo, Japan');
    const [recipient, setRecipient] = useState('a 10-year-old nephew');
    const [interests, setInterests] = useState('anime and video games');
    const [budget, setBudget] = useState('Budget-friendly');
    
    const [suggestions, setSuggestions] = useState<SouvenirSuggestion[] | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!location || !recipient || !interests || !budget) {
            setError('Please fill out all fields for the best suggestions.');
            return;
        }
        setIsLoading(true);
        setError(null);
        setSuggestions(null);

        const result = await findSouvenirs(location, recipient, interests, budget);
        setIsLoading(false);
        if (result) {
            setSuggestions(result.suggestions);
        } else {
            setError('Failed to find souvenirs. The AI might be busy, please try again.');
        }
    };

    const SkeletonLoader = () => (
        <div className="mt-8 animate-pulse grid grid-cols-1 md:grid-cols-2 gap-6">
            {[...Array(2)].map((_, i) => (
                <div key={i} className="solaris-panel p-6 space-y-3">
                    <div className="h-6 bg-[#333]/50 rounded-md w-3/4"></div>
                    <div className="h-4 bg-[#333]/50 rounded-md w-full"></div>
                    <div className="h-4 bg-[#333]/50 rounded-md w-5/6"></div>
                    <div className="h-8 bg-[#333]/50 rounded-md w-1/2 mt-2"></div>
                </div>
            ))}
        </div>
    );

    return (
        <div className="max-w-4xl mx-auto animate-fadeIn">
            <div className="text-center mb-8">
                <SouvenirIcon className="h-12 w-12 mx-auto text-[#ff8c00] mb-2"/>
                <h1 className="text-4xl font-bold text-[#f5f5f5]">Smart Souvenir Finder</h1>
                <p className="mt-2 text-lg text-[#a3a3a3]/70">Find the perfect, authentic gift for anyone, with AI-powered local suggestions.</p>
            </div>

            <form onSubmit={handleSubmit} className="solaris-panel p-6 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label htmlFor="location" className="block text-sm font-medium text-[#a3a3a3]">Your Location</label>
                        <input type="text" id="location" value={location} onChange={e => setLocation(e.target.value)} placeholder="e.g., Tokyo, Japan" required className="mt-1 block w-full bg-[#333]/50 border border-[#444] rounded-md py-2 px-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00]"/>
                    </div>
                     <div>
                        <label htmlFor="recipient" className="block text-sm font-medium text-[#a3a3a3]">Who is it for?</label>
                        <input type="text" id="recipient" value={recipient} onChange={e => setRecipient(e.target.value)} placeholder="e.g., my foodie friend" required className="mt-1 block w-full bg-[#333]/50 border border-[#444] rounded-md py-2 px-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00]"/>
                    </div>
                     <div>
                        <label htmlFor="interests" className="block text-sm font-medium text-[#a3a3a3]">Their Interests</label>
                        <input type="text" id="interests" value={interests} onChange={e => setInterests(e.target.value)} placeholder="e.g., traditional crafts, tea" required className="mt-1 block w-full bg-[#333]/50 border border-[#444] rounded-md py-2 px-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00]"/>
                    </div>
                     <div>
                        <label htmlFor="budget" className="block text-sm font-medium text-[#a3a3a3]">Budget</label>
                        <select id="budget" value={budget} onChange={e => setBudget(e.target.value)} className="mt-1 block w-full bg-[#333]/50 border border-[#444] rounded-md py-2 px-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00]">
                            <option>Budget-friendly</option>
                            <option>Mid-range</option>
                            <option>Premium</option>
                        </select>
                    </div>
                </div>
                <button type="submit" disabled={isLoading} className="w-full flex justify-center py-2.5 px-4 rounded-md font-semibold text-white bg-[#ff8c00] hover:bg-[#e67e00] disabled:bg-[#ff8c00]/50">
                    {isLoading ? 'Searching...' : 'Find Souvenirs'}
                </button>
                {error && <p className="text-red-400 text-sm text-center">{error}</p>}
            </form>

            {isLoading && <SkeletonLoader />}

            {suggestions && (
                <div className="mt-8">
                    <h2 className="text-2xl font-semibold text-[#f5f5f5] mb-4">Your Personalized Suggestions</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {suggestions.map((item, index) => (
                            <div key={index} className="solaris-panel p-6 flex flex-col animate-fadeIn" style={{ animationDelay: `${index * 100}ms` }}>
                                <div className="flex items-center gap-3 mb-3">
                                    <div className="flex-shrink-0 h-10 w-10 bg-[#ff8c00]/10 rounded-full flex items-center justify-center">
                                       {getCategoryIcon(item.category)}
                                    </div>
                                    <div>
                                        <h3 className="text-lg font-bold text-[#ff8c00]">{item.souvenir_name}</h3>
                                    </div>
                                </div>
                                <p className="text-sm text-[#f5f5f5]/90 flex-grow">{item.description}</p>
                                <div className="mt-4 pt-4 border-t border-[#444] space-y-3">
                                    <div>
                                        <p className="text-xs text-[#a3a3a3]/70 font-semibold">WHERE TO FIND</p>
                                        <p className="text-sm font-medium text-[#f5f5f5]">{item.shop_name}</p>
                                        <p className="text-xs text-[#a3a3a3]/70 flex items-center gap-1"><LocationPinIcon className="h-3 w-3" /> {item.shop_location}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-[#a3a3a3]/70 font-semibold">PRICE</p>
                                        <p className="text-sm font-medium text-[#f5f5f5]">{item.price_range}</p>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};

export default SouvenirFinder;