
import React, { useState, useEffect } from 'react';
import { MailIcon } from '../components/icons/MailIcon';
import { LockClosedIcon } from '../components/icons/LockClosedIcon';
import { EyeIcon } from '../components/icons/EyeIcon';
import { EyeOffIcon } from '../components/icons/EyeOffIcon';
import { KeyIcon } from '../components/icons/KeyIcon';
import { GoogleIcon } from '../components/icons/GoogleIcon';
import { ArrowLeftIcon } from '../components/icons/ArrowLeftIcon';
import { getToken, setAuthToken } from '../services/apiService';

interface LoginPageProps {
  onLogin: () => void;
}

type LoginStep = 'credentials' | '2fa' | 'forgotPassword' | 'forgotPasswordSuccess';

const calculatePasswordStrength = (password: string): number => {
    let score = 0;
    if (!password) return 0;
    if (password.length >= 8) score++;
    if (/[a-z]/.test(password) && /[A-Z]/.test(password)) score++;
    if (/\d/.test(password)) score++;
    if (/[^A-Za-z0-9]/.test(password)) score++;
    return score;
};

const PasswordStrengthMeter: React.FC<{ score: number, passwordLength: number }> = ({ score, passwordLength }) => {
    if (passwordLength === 0) return null;

    const strength = {
        0: { label: '', color: '' },
        1: { label: 'Weak', color: 'bg-red-500' },
        2: { label: 'Fair', color: 'bg-orange-500' },
        3: { label: 'Good', color: 'bg-yellow-500' },
        4: { label: 'Strong', color: 'bg-green-500' },
    }[score] || { label: '', color: '' };

    return (
        <div>
            <div className="flex gap-2 mt-2">
                {Array(4).fill(0).map((_, i) => (
                    <div key={i} className={`h-1 flex-1 rounded-full ${i < score ? strength.color : 'bg-[#1a1818]'}`}></div>
                ))}
            </div>
            <p className="text-xs mt-1 text-right" style={{ color: strength.color?.replace('bg-', '') }}>{strength.label}</p>
        </div>
    );
};

const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [step, setStep] = useState<LoginStep>('credentials');
  const [email, setEmail] = useState('vijethkumar955@gmail.com');
  const [password, setPassword] = useState('password123');
  const [showPassword, setShowPassword] = useState(false);
  const [passwordStrength, setPasswordStrength] = useState(0);
  const [code, setCode] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [forgotPasswordEmail, setForgotPasswordEmail] = useState('');


  useEffect(() => {
    setPasswordStrength(calculatePasswordStrength(password));
  }, [password]);

  const handleCredentialSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
      // Use email as username for the API
      const response = await getToken(email, password);
      if (response.access) {
        // Token automatically set by getToken function
        onLogin();
      }
    } catch (err: any) {
      setError(err.message || 'Invalid email or password.');
    } finally {
      setIsLoading(false);
    }
  };
  
  const handle2faSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    setTimeout(() => {
        if (code === '123456') {
            onLogin();
        } else {
            setError('Invalid verification code.');
        }
        setIsLoading(false);
    }, 1000);
  };
  
  const handleForgotPasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);
    setTimeout(() => {
        setIsLoading(false);
        setStep('forgotPasswordSuccess');
    }, 1000);
  };
  
  const handleCodeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/[^0-9]/g, '');
    if (value.length <= 6) {
        setCode(value);
    }
  };
  
  const backToLogin = () => {
    setStep('credentials');
    setError(null);
    setPassword('');
    setCode('');
    setForgotPasswordEmail('');
  };

  const renderContent = () => {
    switch(step) {
        case 'credentials':
            return (
                <form onSubmit={handleCredentialSubmit} className="space-y-6 animate-fadeIn">
                    <div className="text-center mb-4">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto text-[#ff8c00]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M21.5 12c0-5.25-4.25-9.5-9.5-9.5S2.5 6.75 2.5 12s4.25 9.5 9.5 9.5"/><path d="M12 2.5v19"/><path d="M2.5 12h19"/><path d="M4.1 19.9a9.5 9.5 0 0 0 15.8 0"/><path d="M4.1 4.1a9.5 9.5 0 0 1 15.8 0"/>
                        </svg>
                        <h1 className="text-3xl font-bold text-[#f5f5f5] mt-2">TripBro</h1>
                        <p className="text-[#a3a3a3]/70 mt-1">Sign in to your travel hub</p>
                    </div>
                    <div>
                        <label htmlFor="email" className="block text-sm font-medium text-[#a3a3a3]">Email Address</label>
                        <div className="mt-1 relative"><div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none"><MailIcon className="h-5 w-5 text-[#a3a3a3]/50" /></div><input type="email" id="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" className="block w-full bg-[#333]/50 border border-[#444] rounded-md shadow-sm py-2 pl-10 pr-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00] focus:border-[#ff8c00]" required/></div>
                    </div>
                    <div>
                        <div className="flex justify-between items-center"><label htmlFor="password" className="block text-sm font-medium text-[#a3a3a3]">Password</label><button type="button" onClick={() => setStep('forgotPassword')} className="text-xs text-[#a3a3a3]/70 hover:text-[#ff8c00]">Forgot password?</button></div>
                        <div className="mt-1 relative"><div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none"><LockClosedIcon className="h-5 w-5 text-[#a3a3a3]/50" /></div><input type={showPassword ? 'text' : 'password'} id="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" className="block w-full bg-[#333]/50 border border-[#444] rounded-md shadow-sm py-2 pl-10 pr-10 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00] focus:border-[#ff8c00]" required/><button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute inset-y-0 right-0 pr-3 flex items-center text-[#a3a3a3]/50 hover:text-[#f5f5f5]">{showPassword ? <EyeOffIcon className="h-5 w-5" /> : <EyeIcon className="h-5 w-5" />}</button></div>
                        <PasswordStrengthMeter score={passwordStrength} passwordLength={password.length} />
                    </div>
                    {error && <p className="text-red-400 text-sm text-center">{error}</p>}
                    <button type="submit" disabled={isLoading} className="w-full flex justify-center items-center py-2.5 px-4 rounded-md font-medium text-white bg-[#ff8c00] hover:bg-[#e67e00] disabled:bg-[#ff8c00]/50">{isLoading ? <div className="h-5 w-5 border-2 border-t-transparent border-white rounded-full animate-spin"></div> : 'Login'}</button>
                    <div className="relative flex items-center justify-center text-xs text-[#a3a3a3]/60"><span className="absolute left-0 w-full h-px bg-[#444]"></span><span className="relative bg-[#2c2a2a] px-2">or continue with</span></div>
                    <div className="grid grid-cols-2 gap-4">
                        <button type="button" onClick={onLogin} className="w-full flex justify-center items-center gap-2 py-2.5 px-4 border border-[#444] rounded-md font-medium text-[#f5f5f5] bg-[#333]/40 hover:bg-[#444]/50"><GoogleIcon className="h-5 w-5" /> Google</button>
                        <button type="button" onClick={onLogin} className="w-full flex justify-center py-2.5 px-4 border border-[#444] rounded-md font-medium text-[#a3a3a3] bg-[#333]/40 hover:bg-[#444]/50">Guest</button>
                    </div>
                </form>
            );
        case '2fa':
            return (
                <form onSubmit={handle2faSubmit} className="space-y-6 animate-fadeIn">
                    <div className="text-center mb-4"><KeyIcon className="h-12 w-12 mx-auto text-[#ff8c00]" /><h1 className="text-3xl font-bold text-[#f5f5f5] mt-2">Two-Factor Authentication</h1><p className="text-[#a3a3a3]/70 mt-1 max-w-xs mx-auto">A 6-digit code has been sent to <span className="font-semibold text-[#f5f5f5]">{email}</span>.</p></div>
                    <div><label htmlFor="code" className="block text-sm font-medium text-[#a3a3a3] text-center mb-2">Verification Code</label><input type="text" id="code" value={code} onChange={handleCodeChange} placeholder="123456" className="mt-1 block w-full bg-[#333]/50 border border-[#444] rounded-md shadow-sm py-3 px-3 text-[#f5f5f5] text-center text-2xl tracking-[0.5em] focus:outline-none focus:ring-[#ff8c00] focus:border-[#ff8c00]" required maxLength={6} autoComplete="one-time-code"/></div>
                    {error && <p className="text-red-400 text-sm text-center">{error}</p>}
                    <button type="submit" disabled={isLoading || code.length < 6} className="w-full flex justify-center items-center py-2.5 px-4 rounded-md font-medium text-white bg-[#ff8c00] hover:bg-[#e67e00] disabled:bg-[#ff8c00]/50">{isLoading ? <div className="h-5 w-5 border-2 border-t-transparent border-white rounded-full animate-spin"></div> : 'Verify'}</button>
                    <button type="button" onClick={backToLogin} className="w-full text-center text-sm text-[#a3a3a3]/70 hover:text-white flex items-center justify-center gap-2"><ArrowLeftIcon className="h-4 w-4"/> Back to login</button>
                </form>
            );
        case 'forgotPassword':
            return (
                <form onSubmit={handleForgotPasswordSubmit} className="space-y-6 animate-fadeIn">
                    <div className="text-center mb-4"><MailIcon className="h-12 w-12 mx-auto text-[#ff8c00]" /><h1 className="text-3xl font-bold text-[#f5f5f5] mt-2">Reset Password</h1><p className="text-[#a3a3a3]/70 mt-1 max-w-xs mx-auto">Enter your email and we'll send you a link to reset your password.</p></div>
                    <div><label htmlFor="forgot-email" className="block text-sm font-medium text-[#a3a3a3]">Email Address</label><div className="mt-1 relative"><div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none"><MailIcon className="h-5 w-5 text-[#a3a3a3]/50" /></div><input type="email" id="forgot-email" value={forgotPasswordEmail} onChange={(e) => setForgotPasswordEmail(e.target.value)} placeholder="you@example.com" className="block w-full bg-[#333]/50 border border-[#444] rounded-md shadow-sm py-2 pl-10 pr-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00] focus:border-[#ff8c00]" required/></div></div>
                    <button type="submit" disabled={isLoading} className="w-full flex justify-center items-center py-2.5 px-4 rounded-md font-medium text-white bg-[#ff8c00] hover:bg-[#e67e00] disabled:bg-[#ff8c00]/50">{isLoading ? <div className="h-5 w-5 border-2 border-t-transparent border-white rounded-full animate-spin"></div> : 'Send Reset Link'}</button>
                    <button type="button" onClick={backToLogin} className="w-full text-center text-sm text-[#a3a3a3]/70 hover:text-white flex items-center justify-center gap-2"><ArrowLeftIcon className="h-4 w-4"/> Back to login</button>
                </form>
            );
        case 'forgotPasswordSuccess':
            return (
                <div className="space-y-6 animate-fadeIn text-center">
                    <MailIcon className="h-12 w-12 mx-auto text-green-400" />
                    <h1 className="text-3xl font-bold text-[#f5f5f5] mt-2">Check your email</h1>
                    <p className="text-[#a3a3a3]/70 mt-1 max-w-xs mx-auto">We've sent a password reset link to <span className="font-semibold text-[#f5f5f5]">{forgotPasswordEmail}</span>.</p>
                    <button type="button" onClick={backToLogin} className="w-full text-center text-sm text-[#a3a3a3]/70 hover:text-white flex items-center justify-center gap-2 pt-4"><ArrowLeftIcon className="h-4 w-4"/> Back to login</button>
                </div>
            );
    }
  }

  return (
    <div className="flex items-center justify-center h-screen">
      <div className="w-full max-w-md">
        <div className="solaris-panel p-8">
          {renderContent()}
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
