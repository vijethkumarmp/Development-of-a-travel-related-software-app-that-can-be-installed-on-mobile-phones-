import React, { useState, useMemo, useEffect, useReducer, FC } from 'react';
import { Booking, BookingType, Attachment, ExpenseCategory, TripMember } from '../types';
import { useTrip } from '../context/TripContext';
import { parseBookingFromText, extractTextFromImage } from '../services/geminiService';
import { TicketIcon } from '../components/icons/TicketIcon';
import { PlaneIcon } from '../components/icons/PlaneIcon';
import { BuildingIcon } from '../components/icons/BuildingIcon';
import { CarIcon } from '../components/icons/CarIcon';
import { CompassIcon } from '../components/icons/CompassIcon';
import { SparklesIcon } from '../components/icons/SparklesIcon';
import { CalendarIcon } from '../components/icons/CalendarIcon';
import { MapIcon } from '../components/icons/MapIcon';
import { SearchIcon } from '../components/icons/SearchIcon';
import { CalendarPlusIcon } from '../components/icons/CalendarPlusIcon';
import { BellIcon } from '../components/icons/BellIcon';
import DocumentScanner from '../components/DocumentScanner';
import { CameraIcon } from '../components/icons/CameraIcon';
import { HashIcon } from '../components/icons/HashIcon';
import { ClockIcon } from '../components/icons/ClockIcon';
import { LocationPinIcon } from '../components/icons/LocationPinIcon';
import { TaxiIcon } from '../components/icons/TaxiIcon';
import { LinkIcon } from '../components/icons/LinkIcon';
import { UserIcon } from '../components/icons/UserIcon';
import { PhoneIcon } from '../components/icons/PhoneIcon';


const getBookingIcon = (type: BookingType, props: any = {}) => {
    const defaultProps = { className: "h-6 w-6 text-[#ff8c00]" };
    const mergedProps = {...defaultProps, ...props};
    switch(type) {
        case 'Flight': return <PlaneIcon {...mergedProps} />;
        case 'Hotel': return <BuildingIcon {...mergedProps} />;
        case 'Car Rental': return <CarIcon {...mergedProps} />;
        case 'Activity': return <CompassIcon {...mergedProps} />;
        case 'Cab': return <TaxiIcon {...mergedProps} />;
    }
};

const getBookingStartDate = (booking: Booking): Date => {
    switch (booking.type) {
        case 'Flight': return new Date(booking.departure.dateTime);
        case 'Hotel': return new Date(booking.checkInDate);
        case 'Car Rental': return new Date(booking.pickupDateTime);
        case 'Activity': return new Date(`${booking.date}T${booking.time || '00:00'}`);
        case 'Cab': return new Date(booking.pickupDateTime);
    }
}

const getBookingEndDate = (booking: Booking): Date => {
    switch (booking.type) {
        case 'Flight': return new Date(booking.arrival.dateTime);
        case 'Hotel': return new Date(booking.checkOutDate);
        case 'Car Rental': return new Date(booking.dropoffDateTime);
        case 'Activity':
            const activityDate = new Date(booking.date);
            // Treat as a full-day event for searching purposes
            activityDate.setHours(23, 59, 59, 999);
            return activityDate;
        case 'Cab':
            const pickup = new Date(booking.pickupDateTime);
            // Assume a 1-hour duration for cab rides
            return new Date(pickup.getTime() + (60 * 60 * 1000));
    }
}

const BOOKING_TYPE_KEYWORDS: { [key: string]: BookingType } = {
    flight: 'Flight',
    flights: 'Flight',
    fly: 'Flight',
    hotel: 'Hotel',
    hotels: 'Hotel',
    stay: 'Hotel',
    car: 'Car Rental',
    rental: 'Car Rental',
    activity: 'Activity',
    activities: 'Activity',
    tour: 'Activity',
    cab: 'Cab',
    taxi: 'Cab',
};


const parseSearchQuery = (query: string): { text: string; dateRange: { start: Date | null; end: Date | null }; types: BookingType[] } => {
    let text = query.toLowerCase(); // Convert to lowercase once at the beginning
    const dateRange: { start: Date | null; end: Date | null } = { start: null, end: null };
    const dateRegexSrc = `\\d{4}-\\d{2}-\\d{2}`;
    const foundTypes: BookingType[] = [];

    // 1. Extract Booking Types
    const words = text.split(/\s+/);
    const remainingWords: string[] = [];
    words.forEach(word => {
        const type = BOOKING_TYPE_KEYWORDS[word];
        if (type) {
            if (!foundTypes.includes(type)) {
                foundTypes.push(type);
            }
        } else {
            remainingWords.push(word);
        }
    });
    text = remainingWords.join(' ');

    // 2. Extract Date Ranges
    const patterns: [RegExp, (match: RegExpMatchArray, range: typeof dateRange) => void][] = [
        [
            new RegExp(`between\\s+(${dateRegexSrc})\\s+and\\s+(${dateRegexSrc})`),
            (match, range) => {
                range.start = new Date(match[1]);
                range.end = new Date(match[2]);
            }
        ],
        [
            new RegExp(`from\\s+(${dateRegexSrc})\\s+to\\s+(${dateRegexSrc})`),
            (match, range) => {
                range.start = new Date(match[1]);
                range.end = new Date(match[2]);
            }
        ],
    ];

    for (const [regex, handler] of patterns) {
        const match = text.match(regex);
        if (match) {
            handler(match, dateRange);
            text = text.replace(regex, '').trim();
            break; 
        }
    }
    
    const singleDatePatterns: [RegExp, (match: RegExpMatchArray, range: typeof dateRange) => void][] = [
        [
            new RegExp(`(?:from|after)\\s+(${dateRegexSrc})`),
            (match, range) => { range.start = new Date(match[1]); }
        ],
        [
            new RegExp(`(?:to|before)\\s+(${dateRegexSrc})`),
            (match, range) => { range.end = new Date(match[1]); }
        ],
        [
            new RegExp(`on\\s+(${dateRegexSrc})`),
            (match, range) => {
                range.start = new Date(match[1]);
                range.end = new Date(match[1]);
            }
        ]
    ];
    
    for (const [regex, handler] of singleDatePatterns) {
        const match = text.match(regex);
        if (match) {
             handler(match, dateRange);
             text = text.replace(regex, '').trim();
        }
    }

    // Normalize dates to be inclusive
    if (dateRange.start && !isNaN(dateRange.start.getTime())) {
        dateRange.start.setHours(0, 0, 0, 0);
    } else {
        dateRange.start = null;
    }
    if (dateRange.end && !isNaN(dateRange.end.getTime())) {
        dateRange.end.setHours(23, 59, 59, 999);
    } else {
        dateRange.end = null;
    }

    return { text: text.trim(), dateRange, types: foundTypes };
};

const BookingCard: React.FC<{ booking: Booking, onSelect: (booking: Booking) => void }> = ({ booking, onSelect }) => {
    const renderSummary = () => {
        switch(booking.type) {
            case 'Flight':
                return <p className="text-sm text-[#a3a3a3]/70">{booking.departure.code} → {booking.arrival.code}</p>;
            case 'Hotel':
                return <p className="text-sm text-[#a3a3a3]/70">Check-in: {new Date(booking.checkInDate).toLocaleDateString()}</p>;
            case 'Car Rental':
                return <p className="text-sm text-[#a3a3a3]/70">Pick-up: {new Date(booking.pickupDateTime).toLocaleDateString()}</p>;
            case 'Activity':
                return <p className="text-sm text-[#a3a3a3]/70">Date: {new Date(booking.date).toLocaleDateString()}</p>;
            case 'Cab':
                 return <p className="text-sm text-[#a3a3a3]/70">Pick-up: {new Date(booking.pickupDateTime).toLocaleString()}</p>;
        }
    }
    const title = booking.type === 'Hotel' ? booking.hotelName : booking.type === 'Flight' ? `${booking.airline} ${booking.flightNumber}` : booking.type === 'Car Rental' ? booking.company : booking.type === 'Cab' ? booking.cabCompany : booking.name;

    const isUpcoming = getBookingStartDate(booking) > new Date();
    const hasReminder = isUpcoming && booking.reminder && booking.reminder !== 'none';

    return (
        <div onClick={() => onSelect(booking)} className="bg-[#333]/40 p-4 rounded-lg flex items-center gap-4 cursor-pointer hover:bg-[#444]/50 transition-colors relative">
            {hasReminder && (
                <div className="absolute top-2 right-2 text-[#ff8c00]">
                    <BellIcon className="h-4 w-4" />
                </div>
            )}
            <div className="flex-shrink-0 h-10 w-10 bg-[#1a1818]/50 rounded-full flex items-center justify-center">
                {getBookingIcon(booking.type)}
            </div>
            <div className="flex-grow min-w-0">
                <p className="font-semibold text-[#f5f5f5] truncate">{title}</p>
                {renderSummary()}
            </div>
        </div>
    );
};

const TimelineView: React.FC<{ bookings: Booking[], onSelectBooking: (b: Booking) => void }> = ({ bookings, onSelectBooking }) => {
    const sortedBookings = useMemo(() => {
        return [...bookings].sort((a, b) => getBookingStartDate(a).getTime() - getBookingStartDate(b).getTime());
    }, [bookings]);

    const bookingsByDate = useMemo(() => {
        return sortedBookings.reduce((acc, booking) => {
            const dateStr = getBookingStartDate(booking).toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
            if (!acc[dateStr]) {
                acc[dateStr] = [];
            }
            acc[dateStr].push(booking);
            return acc;
        }, {} as Record<string, Booking[]>);
    }, [sortedBookings]);
    
    return (
        <div className="space-y-8">
            {Object.keys(bookingsByDate).map(date => {
                const dayBookings = bookingsByDate[date];
                return (
                <div key={date} className="relative">
                    <div className="sticky top-0 bg-[#2c2a2a]/80 backdrop-blur-sm py-2 z-10">
                        <h3 className="text-lg font-semibold text-[#ff8c00]">{date}</h3>
                    </div>
                    <div className="border-l-2 border-[#b8860b]/50 ml-3 pl-10 py-4 space-y-4">
                        {dayBookings.map(booking => {
                           const title = booking.type === 'Hotel' ? booking.hotelName : booking.type === 'Flight' ? `${booking.airline} ${booking.flightNumber}` : booking.type === 'Car Rental' ? booking.company : booking.type === 'Cab' ? booking.cabCompany : booking.name;
                           let timeString = '';
                           if(booking.type === 'Flight') timeString = new Date(booking.departure.dateTime).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
                           if(booking.type === 'Activity') timeString = booking.time;
                           if(booking.type === 'Cab') timeString = new Date(booking.pickupDateTime).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
                           
                           return (
                             <div key={booking.id} className="relative cursor-pointer" onClick={() => onSelectBooking(booking)}>
                                <div className="absolute -left-[27px] top-1 h-6 w-6 rounded-full bg-[#333]/50 flex items-center justify-center ring-8 ring-[#2c2a2a]">
                                    {getBookingIcon(booking.type, { className: 'h-4 w-4 text-[#ff8c00]' })}
                                </div>
                                <div className="bg-[#333]/40 p-4 rounded-lg hover:bg-[#444]/50 transition-colors">
                                    <p className="font-bold text-[#f5f5f5]">{title}</p>
                                    <p className="text-sm text-[#a3a3a3]/70">{booking.type} - {timeString}</p>
                                </div>
                             </div>
                           )
                        })}
                    </div>
                </div>
            )})}
        </div>
    );
};

const CategoryView: React.FC<{ bookings: Booking[], onSelectBooking: (b: Booking) => void }> = ({ bookings, onSelectBooking }) => {
    const categorizedBookings = useMemo(() => {
        if (!Array.isArray(bookings)) {
            return {} as Record<BookingType, Booking[]>;
        }
        return bookings.reduce<Record<BookingType, Booking[]>>((acc, booking) => {
            if (booking && booking.type) {
                if (!acc[booking.type]) {
                    acc[booking.type] = [];
                }
                acc[booking.type].push(booking);
            }
            return acc;
        }, {} as Record<BookingType, Booking[]>);
    }, [bookings]);

    const BOOKING_CATEGORIES: BookingType[] = ['Flight', 'Hotel', 'Car Rental', 'Cab', 'Activity'];

    return (
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-5 gap-6">
            {BOOKING_CATEGORIES.map(category => (
                <div key={category} className="solaris-panel p-6">
                    <div className="flex items-center gap-3 mb-4">
                        {getBookingIcon(category)}
                        <h2 className="text-xl font-bold text-[#f5f5f5]">{category}s</h2>
                    </div>
                    <div className="space-y-3">
                        {(categorizedBookings[category] || []).length > 0 ? (
                            (categorizedBookings[category] || []).map(booking => (
                                <BookingCard key={booking.id} booking={booking} onSelect={onSelectBooking} />
                            ))
                        ) : (
                            <div className="text-center py-8 text-[#a3a3a3]/60 text-sm">
                                <p>No {category.toLowerCase()} bookings found.</p>
                            </div>
                        )}
                    </div>
                </div>
            ))}
        </div>
    );
};


const BookingManager: React.FC = () => {
    const { bookings, deleteBooking } = useTrip();
    const [modalState, setModalState] = useState<{ isOpen: boolean; booking: Booking | null }>({ isOpen: false, booking: null });
    const [viewMode, setViewMode] = useState<'category' | 'timeline'>('category');
    const [searchQuery, setSearchQuery] = useState('');

    const filteredBookings = useMemo(() => {
        if (!searchQuery.trim()) {
            return bookings;
        }
    
        const { text, dateRange, types } = parseSearchQuery(searchQuery);
        let results = [...bookings];
    
        // 1. Filter by booking type if specified
        if (types.length > 0) {
            results = results.filter(booking => types.includes(booking.type));
        }
    
        // 2. Filter by date range if specified
        if (dateRange.start || dateRange.end) {
            results = results.filter(booking => {
                const bookingStart = getBookingStartDate(booking);
                const bookingEnd = getBookingEndDate(booking);
                
                if (isNaN(bookingStart.getTime()) || isNaN(bookingEnd.getTime())) return false;
    
                const startsAfterQueryEnd = dateRange.end && bookingStart > dateRange.end;
                const endsBeforeQueryStart = dateRange.start && bookingEnd < dateRange.start;
    
                return !(startsAfterQueryEnd || endsBeforeQueryStart);
            });
        }
        
        // 3. Filter by remaining text query
        if (text) {
            const lowercasedQuery = text.toLowerCase();
            results = results.filter(booking => {
                const checkString = (str: string | undefined | null) => str?.toLowerCase().includes(lowercasedQuery);
    
                switch (booking.type) {
                    case 'Flight':
                        return checkString(booking.airline) || checkString(booking.flightNumber) || checkString(booking.confirmationNumber) || checkString(booking.departure.airport) || checkString(booking.departure.code) || checkString(booking.arrival.airport) || checkString(booking.arrival.code);
                    case 'Hotel':
                        return checkString(booking.hotelName) || checkString(booking.address) || checkString(booking.confirmationNumber);
                    case 'Car Rental':
                        return checkString(booking.company) || checkString(booking.confirmationNumber) || checkString(booking.pickupLocation) || checkString(booking.dropoffLocation);
                    case 'Activity':
                        return checkString(booking.name) || checkString(booking.location) || checkString(booking.confirmationNumber);
                    case 'Cab':
                        return checkString(booking.cabCompany) || checkString(booking.confirmationNumber) || checkString(booking.pickupLocation) || checkString(booking.dropoffLocation) || checkString(booking.driverName);
                    default:
                        return false;
                }
            });
        }
        
        return results;
    }, [bookings, searchQuery]);


    const openAddModal = () => {
        setModalState({ isOpen: true, booking: null });
    };
    
    const openDetailsModal = (booking: Booking) => {
        setModalState({ isOpen: true, booking });
    };

    const closeModal = () => {
        setModalState({ isOpen: false, booking: null });
    }
    
    const handleDeleteBooking = (bookingId: number) => {
        deleteBooking(bookingId);
        closeModal();
    };

    const ViewToggleButton: React.FC<{isActive: boolean, onClick: () => void, Icon: React.FC<any>, label: string}> = ({isActive, onClick, Icon, label}) => (
        <button onClick={onClick} className={`flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-md transition-colors ${isActive ? 'bg-[#ff8c00] text-white' : 'bg-[#333]/50 text-[#f5f5f5] hover:bg-[#444]/50'}`}>
            <Icon className="h-5 w-5" />
            <span>{label}</span>
        </button>
    );

    return (
        <div className="max-w-7xl mx-auto animate-fadeIn">
            <div className="text-center mb-8">
                <TicketIcon className="h-12 w-12 mx-auto text-[#ff8c00] mb-2"/>
                <h1 className="text-4xl font-bold text-[#f5f5f5]">Ultimate Booking Manager</h1>
                <p className="mt-2 text-lg text-[#a3a3a3]/70">Scan documents, set reminders, and manage your trip like a pro.</p>
            </div>
            
            <div className="flex justify-between items-center mb-6 gap-4">
                <div className="flex items-center gap-2 p-1 bg-[#1a1818]/50 rounded-lg">
                    <ViewToggleButton isActive={viewMode==='category'} onClick={() => setViewMode('category')} Icon={MapIcon} label="Category View"/>
                    <ViewToggleButton isActive={viewMode==='timeline'} onClick={() => setViewMode('timeline')} Icon={CalendarIcon} label="Timeline View"/>
                </div>

                <div className="flex-grow max-w-lg relative">
                    <input
                        type="text"
                        placeholder="Search by name, type (flight, hotel), or date..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full bg-[#333]/50 border border-[#444] rounded-lg py-2.5 pl-10 pr-4 text-[#f5f5f5] focus:outline-none focus:ring-2 focus:ring-[#ff8c00]"
                    />
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <SearchIcon className="h-5 w-5 text-[#a3a3a3]/70" />
                    </div>
                </div>

                <button onClick={openAddModal} className="px-5 py-2.5 bg-[#ff8c00] text-white rounded-lg font-semibold hover:bg-[#e67e00] transition-colors shadow-lg flex items-center gap-2">
                    <SparklesIcon className="h-5 w-5" />
                    Add Booking
                </button>
            </div>
            
            {filteredBookings.length > 0 ? (
                viewMode === 'category' ? <CategoryView bookings={filteredBookings} onSelectBooking={openDetailsModal} /> : <TimelineView bookings={filteredBookings} onSelectBooking={openDetailsModal} />
            ) : (
                 <div className="text-center py-16 solaris-panel">
                    <p className="text-xl font-semibold text-[#f5f5f5]">No Bookings Found</p>
                    <p className="text-[#a3a3a3]/70 mt-2">
                        {searchQuery ? `Your search for "${searchQuery}" did not match any bookings.` : "Try adding a new booking!"}
                    </p>
                </div>
            )}

            {modalState.isOpen && <BookingFormModal booking={modalState.booking} onClose={closeModal} onDelete={handleDeleteBooking} />}
        </div>
    );
};

// --- .ICS Calendar File Generation ---
const formatDateForICS = (dateStr: string) => {
    return new Date(dateStr).toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
};

const generateICS = (booking: Booking) => {
    const uid = `${booking.id}-${booking.type.replace(/\s/g, '')}@tripbro.app`;
    const stamp = formatDateForICS(new Date().toISOString());
    let start, end, summary, description, location;

    switch (booking.type) {
        case 'Flight':
            start = formatDateForICS(booking.departure.dateTime);
            end = formatDateForICS(booking.arrival.dateTime);
            summary = `Flight: ${booking.airline} ${booking.flightNumber} (${booking.departure.code} to ${booking.arrival.code})`;
            description = `Confirmation: ${booking.confirmationNumber}. Airline: ${booking.airline}. Flight: ${booking.flightNumber}. Notes: ${booking.notes || ''}`;
            location = `Departure: ${booking.departure.airport}`;
            break;
        case 'Hotel':
            start = formatDateForICS(booking.checkInDate);
            end = formatDateForICS(booking.checkOutDate);
            summary = `Hotel Stay: ${booking.hotelName}`;
            description = `Confirmation: ${booking.confirmationNumber}. Address: ${booking.address}. Notes: ${booking.notes || ''}`;
            location = booking.address;
            break;
        case 'Car Rental':
            start = formatDateForICS(booking.pickupDateTime);
            end = formatDateForICS(booking.dropoffDateTime);
            summary = `Car Rental: ${booking.company}`;
            description = `Confirmation: ${booking.confirmationNumber}. Pick-up: ${booking.pickupLocation}. Drop-off: ${booking.dropoffLocation}. Notes: ${booking.notes || ''}`;
            location = booking.pickupLocation;
            break;
        case 'Activity':
            const activityStart = new Date(`${booking.date}T${booking.time || '00:00'}`);
            const activityEnd = new Date(activityStart.getTime() + (60 * 60 * 1000)); // Assume 1 hour duration
            start = formatDateForICS(activityStart.toISOString());
            end = formatDateForICS(activityEnd.toISOString());
            summary = `Activity: ${booking.name}`;
            description = `Confirmation: ${booking.confirmationNumber || 'N/A'}. Location: ${booking.location}. Notes: ${booking.notes || ''}`;
            location = booking.location;
            break;
        case 'Cab':
            start = formatDateForICS(booking.pickupDateTime);
            // Assume 1 hour duration for calendar event if only pickup is known
            const cabEnd = new Date(new Date(booking.pickupDateTime).getTime() + (60 * 60 * 1000));
            end = formatDateForICS(cabEnd.toISOString());
            summary = `Cab: ${booking.cabCompany} from ${booking.pickupLocation}`;
            description = `Confirmation: ${booking.confirmationNumber || 'N/A'}. Driver: ${booking.driverName || 'N/A'}. Contact: ${booking.driverContact || 'N/A'}. Drop-off: ${booking.dropoffLocation || 'N/A'}. Notes: ${booking.notes || ''}`;
            location = booking.pickupLocation;
            break;
    }

    const icsContent = `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//TripBro//EN
BEGIN:VEVENT
UID:${uid}
DTSTAMP:${stamp}
DTSTART:${start}
DTEND:${end}
SUMMARY:${summary}
DESCRIPTION:${description.replace(/\n/g, '\\n')}
LOCATION:${location}
END:VEVENT
END:VCALENDAR`;

    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `${summary.replace(/[^a-zA-Z0-9]/g, '_')}.ics`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
};


// --- Form Modal with Reducer for Performance ---

type FormState = Partial<Booking> & {
    createExpense?: boolean;
    expenseAmount?: string;
    expenseCurrency?: string;
    expensePaidBy?: number;
    expenseSplitBetween?: number[];
    expenseCategory?: ExpenseCategory;
};

type FormAction =
  | { type: 'SET_FIELD'; field: string; value: any }
  | { type: 'LOAD_DATA'; data: Partial<Booking> }
  | { type: 'RESET'; bookingType: BookingType; members: TripMember[] }
  | { type: 'UPDATE_FROM_AI'; data: Partial<Booking> };


const getInitialExpenseData = (members: TripMember[]) => ({
    createExpense: false,
    expenseAmount: '',
    expenseCurrency: 'USD',
    expensePaidBy: members[0]?.id || 1,
    expenseSplitBetween: members.map(m => m.id),
    expenseCategory: 'Other' as ExpenseCategory
});

const getInitialFormData = (type: BookingType, members: TripMember[]): FormState => {
    const common = { type, attachments: [], notes: '', reminder: 'none' };
    const expenseData = getInitialExpenseData(members);
    switch (type) {
        case 'Flight': return { ...common, airline: '', flightNumber: '', confirmationNumber: '', departure: { airport: '', code: '', dateTime: '' }, arrival: { airport: '', code: '', dateTime: '' }, ...expenseData };
        case 'Hotel': return { ...common, hotelName: '', address: '', checkInDate: '', checkOutDate: '', confirmationNumber: '', ...expenseData };
        case 'Car Rental': return { ...common, company: '', pickupLocation: '', dropoffLocation: '', pickupDateTime: '', dropoffDateTime: '', confirmationNumber: '', ...expenseData };
        case 'Activity': return { ...common, name: '', location: '', date: '', time: '', confirmationNumber: '', ...expenseData };
        case 'Cab': return { ...common, cabCompany: '', pickupLocation: '', pickupDateTime: '', ...expenseData };
        default: return { ...common, ...expenseData };
    }
};

// Correct, immutable utility to set nested properties.
const setNestedValue = (obj: any, path: string, value: any) => {
    const keys = path.split('.');
    const newObj = { ...obj };
    let currentLevel = newObj;

    for (let i = 0; i < keys.length - 1; i++) {
        const key = keys[i];
        // Create a copy of the nested object before descending
        currentLevel[key] = { ...(currentLevel[key] || {}) };
        currentLevel = currentLevel[key];
    }
    
    currentLevel[keys[keys.length - 1]] = value;
    
    return newObj;
};


const formReducer = (state: FormState, action: FormAction): FormState => {
    switch (action.type) {
        case 'SET_FIELD':
             if (action.field.includes('.')) {
                return setNestedValue(state, action.field, action.value);
            }
            return { ...state, [action.field]: action.value };
        case 'LOAD_DATA':
            return { ...state, ...action.data };
        case 'RESET':
            return getInitialFormData(action.bookingType, action.members);
        case 'UPDATE_FROM_AI':
            const newState = getInitialFormData(action.data.type || 'Flight', []); // members will be updated later
            return { ...newState, ...action.data, attachments: [] };
        default:
            return state;
    }
};


const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
  });
};

const BookingFormModal: FC<{
    booking: Booking | null;
    onClose: () => void;
    onDelete: (id: number) => void;
}> = ({ booking, onClose, onDelete }) => {
    const { members, addBooking, updateBooking, addExpense } = useTrip();
    
    const [state, dispatch] = useReducer(formReducer, getInitialFormData(booking?.type || 'Flight', members));
    const [isEditing, setIsEditing] = useState(!booking);
    const [bookingType, setBookingType] = useState<BookingType>(booking?.type || 'Flight');
    const [tab, setTab] = useState<'form' | 'import'>('form');
    const [importText, setImportText] = useState('');
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [isAttachmentScannerOpen, setIsAttachmentScannerOpen] = useState(false);
    const [isOcrScannerOpen, setIsOcrScannerOpen] = useState(false);
    
    useEffect(() => {
        if (booking) {
            dispatch({ type: 'LOAD_DATA', data: booking });
            setBookingType(booking.type);
            setIsEditing(false);
        } else {
            dispatch({ type: 'RESET', bookingType: bookingType, members });
        }
    }, [booking, bookingType, members]);

    const handleAnalyze = async () => {
        setIsAnalyzing(true);
        const result = await parseBookingFromText(importText);
        if (result && result.type) {
            setBookingType(result.type);
            dispatch({ type: 'UPDATE_FROM_AI', data: result });
            setTab('form');
        } else {
            alert('Could not parse booking details. Please try again or enter manually.');
        }
        setIsAnalyzing(false);
    };
    
    const handleOcrScan = async (base64Image: string) => {
        setIsOcrScannerOpen(false);
        setIsAnalyzing(true);
        const extractedText = await extractTextFromImage(base64Image);
        if (extractedText) {
            setImportText(extractedText); // show the user what was extracted
            const result = await parseBookingFromText(extractedText);
            if (result && result.type) {
                setBookingType(result.type);
                dispatch({ type: 'UPDATE_FROM_AI', data: result });
                setTab('form');
            } else {
                alert('Could not parse booking details from the scanned document. You can review the extracted text and try again, or enter manually.');
            }
        } else {
            alert('Could not extract any text from the document.');
        }
        setIsAnalyzing(false);
    };

    const handleFieldChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value, type } = e.target;
        const finalValue = type === 'checkbox' ? (e.target as HTMLInputElement).checked : value;
        dispatch({ type: 'SET_FIELD', field: name, value: finalValue });
    };
    
    const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files) {
            const file = e.target.files[0];
            const base64 = await fileToBase64(file);
            const newAttachment: Attachment = { name: file.name, type: file.type, data: base64 };
            const newAttachments = [...(state.attachments || []), newAttachment];
            dispatch({ type: 'SET_FIELD', field: 'attachments', value: newAttachments });
        }
    };

    const handleAttachmentScanCapture = (base64Data: string) => {
      const newAttachment: Attachment = {
        name: `Scan_${new Date().toISOString()}.jpeg`,
        type: 'image/jpeg',
        data: base64Data
      };
      const newAttachments = [...(state.attachments || []), newAttachment];
      dispatch({ type: 'SET_FIELD', field: 'attachments', value: newAttachments });
      setIsAttachmentScannerOpen(false);
    };
    
    const removeAttachment = (index: number) => {
        const newAttachments = (state.attachments || []).filter((_: any, i: number) => i !== index);
        dispatch({ type: 'SET_FIELD', field: 'attachments', value: newAttachments });
    };
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const bookingData = { ...state, id: booking?.id || Date.now(), type: bookingType };
        
        if (booking) {
            updateBooking(bookingData as Booking);
        } else {
            addBooking(bookingData as Booking);
        }
        
        if (state.createExpense && state.expenseAmount) {
            const expenseDescription = `${bookingType}: ${ (state as any).name || (state as any).hotelName || (state as any).airline || (state as any).company || 'Booking'}`;
            addExpense({
                description: expenseDescription,
                amount: parseFloat(state.expenseAmount),
                currency: state.expenseCurrency || 'USD',
                paidBy: state.expensePaidBy || members[0].id,
                splitBetween: state.expenseSplitBetween || members.map(m=>m.id),
                category: state.expenseCategory || 'Other',
            });
        }
        onClose();
    };

    const handleDelete = () => {
        if (booking && window.confirm('Are you sure you want to delete this booking?')) {
            onDelete(booking.id);
        }
    };

    const handleReminderChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        if (booking) {
            updateBooking({ ...booking, reminder: e.target.value });
        }
    };
    
    const renderDetails = () => {
        if (!booking) return null;

        const DetailItem: React.FC<{ icon: React.ReactNode, label: string, value: React.ReactNode }> = ({ icon, label, value }) => (
            <div className="flex items-start gap-3">
                <div className="flex-shrink-0 text-[#ff8c00] mt-1">{icon}</div>
                <div>
                    <p className="text-xs text-[#a3a3a3]/70 uppercase font-semibold">{label}</p>
                    <p className="text-[#f5f5f5] font-medium">{value || 'N/A'}</p>
                </div>
            </div>
        );
        
        switch (booking.type) {
            case 'Flight':
                return (
                    <div className="space-y-6">
                        <div className="flex items-center justify-between text-center">
                            <div className="w-2/5">
                                <p className="text-3xl font-bold text-[#f5f5f5]">{booking.departure.code}</p>
                                <p className="text-sm text-[#a3a3a3]/70 truncate">{booking.departure.airport}</p>
                                <p className="text-lg text-[#f5f5f5] mt-1 font-semibold">{new Date(booking.departure.dateTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                                <p className="text-xs text-[#a3a3a3]/50">{new Date(booking.departure.dateTime).toLocaleDateString()}</p>
                            </div>
                            <div className="w-1/5 flex-shrink-0 flex items-center justify-center">
                                <div className="w-full border-b-2 border-dashed border-[#444] relative">
                                    <PlaneIcon className="h-5 w-5 text-[#a3a3a3]/70 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-[#2c2a2a] px-1" />
                                </div>
                            </div>
                            <div className="w-2/5">
                                <p className="text-3xl font-bold text-[#f5f5f5]">{booking.arrival.code}</p>
                                <p className="text-sm text-[#a3a3a3]/70 truncate">{booking.arrival.airport}</p>
                                <p className="text-lg text-[#f5f5f5] mt-1 font-semibold">{new Date(booking.arrival.dateTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                                <p className="text-xs text-[#a3a3a3]/50">{new Date(booking.arrival.dateTime).toLocaleDateString()}</p>
                            </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4 pt-4 border-t border-[#444]">
                            <DetailItem icon={<TicketIcon className="h-5 w-5" />} label="Airline" value={`${booking.airline} (${booking.flightNumber})`} />
                            <DetailItem icon={<HashIcon className="h-5 w-5" />} label="Confirmation #" value={<span className="font-mono">{booking.confirmationNumber}</span>} />
                        </div>
                    </div>
                );
            case 'Hotel':
                return (
                    <div className="space-y-6">
                         <DetailItem icon={<BuildingIcon className="h-5 w-5" />} label="Hotel" value={<span className="text-lg">{booking.hotelName}</span>} />
                         <DetailItem icon={<LocationPinIcon className="h-5 w-5" />} label="Address" value={booking.address} />
                         <div className="flex items-center gap-4 p-4 bg-[#1a1818]/50 rounded-lg">
                            <div className="flex-1 text-center">
                                <p className="text-xs text-[#a3a3a3]/70 uppercase font-semibold">Check-in</p>
                                <p className="text-lg font-bold text-[#f5f5f5] mt-1">{new Date(booking.checkInDate).toLocaleDateString(undefined, { day: '2-digit', month: 'short' })}</p>
                                <p className="text-sm text-[#f5f5f5]">{new Date(booking.checkInDate).toLocaleDateString(undefined, { weekday: 'long' })}</p>
                            </div>
                            <div className="text-[#a3a3a3]/50 text-2xl">→</div>
                             <div className="flex-1 text-center">
                                <p className="text-xs text-[#a3a3a3]/70 uppercase font-semibold">Check-out</p>
                                <p className="text-lg font-bold text-[#f5f5f5] mt-1">{new Date(booking.checkOutDate).toLocaleDateString(undefined, { day: '2-digit', month: 'short' })}</p>
                                <p className="text-sm text-[#f5f5f5]">{new Date(booking.checkOutDate).toLocaleDateString(undefined, { weekday: 'long' })}</p>
                            </div>
                         </div>
                         <DetailItem icon={<HashIcon className="h-5 w-5" />} label="Confirmation #" value={<span className="font-mono">{booking.confirmationNumber}</span>} />
                    </div>
                );
            case 'Car Rental':
                 return (
                    <div className="space-y-6">
                        <DetailItem icon={<CarIcon className="h-5 w-5" />} label="Company" value={<span className="text-lg">{booking.company}</span>} />
                        <div className="space-y-4 pt-4 border-t border-[#444]">
                           <DetailItem icon={<LocationPinIcon className="h-5 w-5" />} label="Pick-up" value={
                               <>
                                {booking.pickupLocation}
                                <span className="block text-[#f5f5f5] font-semibold mt-1">{new Date(booking.pickupDateTime).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}</span>
                                </>
                           }/>
                           <DetailItem icon={<LocationPinIcon className="h-5 w-5" />} label="Drop-off" value={
                               <>
                                {booking.dropoffLocation}
                                <span className="block text-[#f5f5f5] font-semibold mt-1">{new Date(booking.dropoffDateTime).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}</span>
                                </>
                           }/>
                        </div>
                        <DetailItem icon={<HashIcon className="h-5 w-5" />} label="Confirmation #" value={<span className="font-mono">{booking.confirmationNumber}</span>} />
                    </div>
                 );
            case 'Activity':
                return (
                    <div className="space-y-6">
                         <DetailItem icon={<CompassIcon className="h-5 w-5" />} label="Activity" value={<span className="text-lg">{booking.name}</span>} />
                         <DetailItem icon={<LocationPinIcon className="h-5 w-5" />} label="Location" value={booking.location} />
                         <div className="grid grid-cols-2 gap-4 pt-4 border-t border-[#444]">
                             <DetailItem icon={<CalendarIcon className="h-5 w-5" />} label="Date" value={<span className="font-semibold">{new Date(booking.date).toLocaleDateString(undefined, { dateStyle: 'full' })}</span>} />
                             <DetailItem icon={<ClockIcon className="h-5 w-5" />} label="Time" value={<span className="font-semibold">{booking.time}</span>} />
                         </div>
                         <DetailItem icon={<HashIcon className="h-5 w-5" />} label="Confirmation #" value={<span className="font-mono">{booking.confirmationNumber}</span>} />
                    </div>
                );
            case 'Cab':
                return (
                    <div className="space-y-6">
                         <DetailItem icon={<TaxiIcon className="h-5 w-5" />} label="Cab Company" value={<span className="text-lg">{booking.cabCompany}</span>} />
                         <div className="space-y-4 pt-4 border-t border-[#444]">
                             <DetailItem icon={<LocationPinIcon className="h-5 w-5" />} label="Pick-up" value={
                                 <>
                                  {booking.pickupLocation}
                                  <span className="block text-[#f5f5f5] font-semibold mt-1">{new Date(booking.pickupDateTime).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}</span>
                                 </>
                             }/>
                             {booking.dropoffLocation && <DetailItem icon={<LocationPinIcon className="h-5 w-5" />} label="Drop-off" value={booking.dropoffLocation}/>}
                         </div>
                         <div className="grid grid-cols-2 gap-4 pt-4 border-t border-[#444]">
                            {booking.driverName && <DetailItem icon={<UserIcon className="h-5 w-5" />} label="Driver" value={booking.driverName}/>}
                            {booking.driverContact && <DetailItem icon={<PhoneIcon className="h-5 w-5" />} label="Driver Contact" value={booking.driverContact}/>}
                            <DetailItem icon={<HashIcon className="h-5 w-5" />} label="Confirmation #" value={<span className="font-mono">{booking.confirmationNumber}</span>} />
                         </div>
                         {booking.bookingLink && (
                            <div className="pt-4 border-t border-[#444]">
                                <a href={booking.bookingLink} target="_blank" rel="noopener noreferrer" className="w-full flex items-center justify-center gap-2 py-2.5 bg-[#ff8c00] text-white rounded-md font-semibold hover:bg-[#e67e00] transition-colors">
                                    <LinkIcon className="h-4 w-4" />
                                    View on Website
                                </a>
                            </div>
                         )}
                    </div>
                );
        }
    };
    
    const renderFormFields = () => {
        const Input = (props: any) => <input {...props} value={(state as any)[props.name] || ''} onChange={handleFieldChange} className="mt-1 block w-full bg-[#333]/50 border border-[#444] rounded-md py-2 px-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00]" />;
        const NestedInput = ({name, ...props}: any) => <input name={name} {...props} value={name.split('.').reduce((o: any, i: string) => o?.[i], state) || ''} onChange={handleFieldChange} className="mt-1 block w-full bg-[#333]/50 border border-[#444] rounded-md py-2 px-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00]" />;
        const Label = (props: any) => <label {...props} className="block text-sm font-medium text-[#a3a3a3]" />
        
        switch (bookingType) {
            case 'Flight': return (<> <Label>Airline</Label> <Input name="airline" placeholder="VoyageAir"/> <Label>Flight Number</Label> <Input name="flightNumber" placeholder="VA 2042"/> <Label>Confirmation #</Label> <Input name="confirmationNumber"/> <div className="grid grid-cols-2 gap-4"> <div><Label>Departure Airport</Label><NestedInput name="departure.airport" placeholder="SFO"/></div> <div><Label>Departure Time</Label><NestedInput name="departure.dateTime" type="datetime-local"/></div> <div><Label>Arrival Airport</Label><NestedInput name="arrival.airport" placeholder="NRT"/></div> <div><Label>Arrival Time</Label><NestedInput name="arrival.dateTime" type="datetime-local"/></div> </div></>);
            case 'Hotel': return (<><Label>Hotel Name</Label><Input name="hotelName" placeholder="Shibuya Grand Hotel"/> <Label>Address</Label><Input name="address"/> <Label>Confirmation #</Label><Input name="confirmationNumber"/> <div className="grid grid-cols-2 gap-4"><div><Label>Check-in Date</Label><Input name="checkInDate" type="date"/></div> <div><Label>Check-out Date</Label><Input name="checkOutDate" type="date"/></div></div></>);
            case 'Car Rental': return (<><Label>Company</Label><Input name="company" placeholder="Nippon Rent-A-Car"/> <Label>Confirmation #</Label><Input name="confirmationNumber"/> <Label>Pick-up Location</Label><Input name="pickupLocation"/> <Label>Drop-off Location</Label><Input name="dropoffLocation"/> <div className="grid grid-cols-2 gap-4"><div><Label>Pick-up Time</Label><Input name="pickupDateTime" type="datetime-local"/></div> <div><Label>Drop-off Time</Label><Input name="dropoffDateTime" type="datetime-local"/></div></div></>);
            case 'Activity': return (<><Label>Activity Name</Label><Input name="name" placeholder="Ghibli Museum Tour"/> <Label>Location</Label><Input name="location"/> <Label>Confirmation #</Label><Input name="confirmationNumber"/> <div className="grid grid-cols-2 gap-4"><div><Label>Date</Label><Input name="date" type="date"/></div> <div><Label>Time</Label><Input name="time" type="time"/></div></div></>);
            case 'Cab': return (<><Label>Cab Company</Label><Input name="cabCompany" placeholder="GoRide Cabs"/> <Label>Pick-up Location</Label><Input name="pickupLocation"/><Label>Drop-off Location (optional)</Label><Input name="dropoffLocation"/><Label>Pick-up Time</Label><Input name="pickupDateTime" type="datetime-local"/> <div className="grid grid-cols-2 gap-4"><div><Label>Driver Name (optional)</Label><Input name="driverName"/></div> <div><Label>Driver Contact (optional)</Label><Input name="driverContact"/></div></div><Label>Booking Link (optional)</Label><Input name="bookingLink" placeholder="https://..."/><Label>Confirmation # (optional)</Label><Input name="confirmationNumber"/></>);
            default: return null;
        }
    };

    const renderExpenseFields = () => (
        <div className="mt-4 p-4 bg-[#1a1818]/50 rounded-lg space-y-4">
            <div className="flex gap-4">
                <div className="w-1/2"><label className="text-sm font-medium text-[#a3a3a3]">Amount</label><input type="number" name="expenseAmount" value={state.expenseAmount || ''} onChange={handleFieldChange} className="mt-1 w-full bg-[#333]/50 border-[#444] rounded-md py-2 px-3 text-[#f5f5f5]"/></div>
                <div className="w-1/2"><label className="text-sm font-medium text-[#a3a3a3]">Currency</label><input name="expenseCurrency" value={state.expenseCurrency || 'USD'} onChange={handleFieldChange} className="mt-1 w-full bg-[#333]/50 border-[#444] rounded-md py-2 px-3 text-[#f5f5f5]"/></div>
            </div>
            <div><label className="text-sm font-medium text-[#a3a3a3]">Paid By</label><select name="expensePaidBy" value={state.expensePaidBy} onChange={handleFieldChange} className="mt-1 w-full bg-[#333]/50 border-[#444] rounded-md py-2 px-3 text-[#f5f5f5]">{members.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}</select></div>
        </div>
    );

    return (
      <>
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 animate-fadeIn" onClick={onClose}>
            <div className="bg-[#2c2a2a] border border-[#444] rounded-xl p-8 w-full max-w-lg shadow-2xl m-4 max-h-[90vh] flex flex-col" onClick={e => e.stopPropagation()}>
                <div className="flex items-center gap-4 mb-4 flex-shrink-0">
                    <div className="flex-shrink-0 h-12 w-12 bg-[#333]/50 rounded-full flex items-center justify-center">{getBookingIcon(booking?.type || bookingType)}</div>
                    <div><h2 className="text-2xl font-bold text-[#f5f5f5]">{booking ? isEditing ? `Edit ${booking.type}` : `${booking.type} Details` : 'Add New Booking'}</h2></div>
                </div>
                {!booking && (<div className="flex items-center gap-2 p-1 bg-[#1a1818]/50 rounded-lg mb-4 flex-shrink-0"><button onClick={() => setTab('form')} className={`flex-1 text-center px-3 py-1.5 text-sm rounded-md transition-colors ${tab === 'form' ? 'bg-[#ff8c00] text-white' : 'text-[#f5f5f5] hover:bg-[#333]/70'}`}>Manual Entry</button><button onClick={() => setTab('import')} className={`flex-1 text-center px-3 py-1.5 text-sm rounded-md transition-colors flex items-center justify-center gap-2 ${tab === 'import' ? 'bg-[#ff8c00] text-white' : 'text-[#f5f5f5] hover:bg-[#333]/70'}`}><SparklesIcon className="h-4 w-4"/>Import with AI</button></div>)}
                
                <div className="overflow-y-auto pr-4 -mr-4 flex-grow">
                  {tab === 'import' && !booking ? (<div className="space-y-4"><p className="text-sm text-[#a3a3a3]/70">Paste your confirmation email text below or scan a document to let AI fill out the form for you.</p><textarea value={importText} onChange={e => setImportText(e.target.value)} rows={6} placeholder="Paste confirmation text here..." className="w-full bg-[#333]/50 border border-[#444] rounded-md py-2 px-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00]" /><button onClick={handleAnalyze} disabled={isAnalyzing || !importText} className="w-full flex justify-center items-center gap-2 py-2.5 bg-[#ff8c00] text-white rounded-md font-semibold hover:bg-[#e67e00] disabled:bg-[#ff8c00]/50 disabled:cursor-not-allowed">{isAnalyzing ? 'Analyzing Text...' : 'Analyze with AI'}</button><div className="flex items-center gap-4 my-2"><hr className="flex-grow border-[#444]" /><span className="text-[#a3a3a3]/70 text-xs">OR</span><hr className="flex-grow border-[#444]" /></div><button onClick={() => setIsOcrScannerOpen(true)} disabled={isAnalyzing} className="w-full flex justify-center items-center gap-2 py-2.5 bg-[#333]/60 text-white rounded-md font-semibold hover:bg-[#444]/60 disabled:opacity-50"><CameraIcon className="h-5 w-5"/>{isAnalyzing ? 'Analyzing...' : 'Scan Document with AI'}</button></div>) : (
                    <form id="booking-form" onSubmit={handleSubmit} className="space-y-4">
                    {isEditing ? (
                      <>
                        {!booking && (
                          <div>
                            <label className="block text-sm font-medium text-[#a3a3a3]">Booking Type</label>
                            <select value={bookingType} onChange={e => setBookingType(e.target.value as BookingType)} className="mt-1 block w-full bg-[#333]/50 border border-[#444] rounded-md py-2 px-3 text-[#f5f5f5]">
                                <option value="Flight">Flight</option>
                                <option value="Hotel">Hotel</option>
                                <option value="Car Rental">Car Rental</option>
                                <option value="Cab">Cab</option>
                                <option value="Activity">Activity</option>
                            </select>
                          </div>
                        )}
                        {renderFormFields()}

                        <label className="block text-sm font-medium text-[#a3a3a3]">Notes</label>
                        <textarea name="notes" value={state.notes || ''} onChange={handleFieldChange} rows={2} placeholder="Add any relevant notes..." className="mt-1 block w-full bg-[#333]/50 border border-[#444] rounded-md py-2 px-3 text-[#f5f5f5]"/>
                        
                        {!booking && (
                            <div>
                                <label className="flex items-center mt-4">
                                    <input type="checkbox" name="createExpense" checked={state.createExpense || false} onChange={handleFieldChange} className="h-4 w-4 bg-[#333]/50 border-[#444] rounded text-[#ff8c00]" />
                                    <span className="ml-2 text-[#f5f5f5]">Also add this booking cost as an expense</span>
                                </label>
                                {state.createExpense && renderExpenseFields()}
                            </div>
                        )}
                      </>
                    ) : (
                      renderDetails()
                    )}

                    <div className="space-y-2 pt-4">
                      <label className="block text-sm font-medium text-[#a3a3a3]">Attachments</label>
                      <div className="grid grid-cols-3 gap-2">
                        {(state.attachments || []).map((att, index) => (
                           <div key={index} className="relative group">
                             <a href={att.data} download={att.name} className="block w-full h-20 bg-[#333]/50 rounded-md flex items-center justify-center text-[#a3a3a3]/70 text-xs p-2 truncate">{att.name}</a>
                             {isEditing && <button type="button" onClick={() => removeAttachment(index)} className="absolute -top-1 -right-1 h-5 w-5 bg-red-500 text-white rounded-full text-xs hidden group-hover:block">&times;</button>}
                           </div>
                        ))}
                        {isEditing && (
                           <label className="w-full h-20 bg-[#333]/40 rounded-md flex items-center justify-center cursor-pointer hover:bg-[#444]/50">
                             <input type="file" className="hidden" onChange={handleFileChange} />
                             <span className="text-[#a3a3a3]/70 text-2xl">+</span>
                           </label>
                        )}
                         {isEditing && (
                           <button type="button" onClick={() => setIsAttachmentScannerOpen(true)} className="w-full h-20 bg-[#333]/40 rounded-md flex flex-col items-center justify-center cursor-pointer hover:bg-[#444]/50">
                             <CameraIcon className="h-6 w-6 text-[#a3a3a3]/70" />
                             <span className="text-[#a3a3a3]/70 text-xs mt-1">Scan</span>
                           </button>
                        )}
                      </div>
                    </div>
                  </form>
                  )}
                </div>
                
                <div className="flex justify-between items-center pt-6 flex-shrink-0">
                   <div>
                     {booking && !isEditing && (
                        <div className="flex items-center gap-2">
                          <button onClick={() => generateICS(booking)} className="flex items-center gap-2 px-3 py-2 bg-[#333]/60 text-white rounded-md font-semibold hover:bg-[#444]/60 text-sm"><CalendarPlusIcon className="h-4 w-4"/> Add to Calendar</button>
                          
                          <div className="relative">
                            <select value={booking.reminder || 'none'} onChange={handleReminderChange} className="bg-[#333]/60 text-white rounded-md font-semibold py-2 pl-3 pr-8 appearance-none text-sm">
                               <option value="none">No Reminder</option>
                               <option value="1h">1 Hour Before</option>
                               <option value="1d">1 Day Before</option>
                               <option value="2d">2 Days Before</option>
                            </select>
                             <BellIcon className="h-4 w-4 text-[#a3a3a3]/70 absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none" />
                          </div>
                        </div>
                     )}
                     {booking && isEditing && <button type="button" onClick={handleDelete} className="px-4 py-2 text-red-400 hover:bg-red-500/10 rounded-md">Delete</button>}
                   </div>
                   <div className="flex gap-4">
                     {isEditing ? (
                       <>
                         <button type="button" onClick={booking ? () => setIsEditing(false) : onClose} className="px-4 py-2 text-[#a3a3a3] hover:bg-[#333] rounded-md">Cancel</button>
                         <button type="submit" form="booking-form" className="px-6 py-2 bg-[#ff8c00] text-white rounded-md font-semibold hover:bg-[#e67e00]">Save</button>
                       </>
                     ) : (
                        <>
                           <button type="button" onClick={onClose} className="px-4 py-2 text-[#a3a3a3] hover:bg-[#333] rounded-md">Close</button>
                           <button type="button" onClick={() => setIsEditing(true)} className="px-6 py-2 bg-[#ff8c00] text-white rounded-md font-semibold hover:bg-[#e67e00]">Edit</button>
                        </>
                     )}
                   </div>
                </div>

            </div>
        </div>
        {isAttachmentScannerOpen && <DocumentScanner onCapture={handleAttachmentScanCapture} onClose={() => setIsAttachmentScannerOpen(false)} />}
        {isOcrScannerOpen && <DocumentScanner onCapture={handleOcrScan} onClose={() => setIsOcrScannerOpen(false)} />}
      </>
    );
};

export default BookingManager;