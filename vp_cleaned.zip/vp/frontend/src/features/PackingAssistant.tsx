

import React, { useState, useMemo } from 'react';
import { PackingItem } from '../types';
import { generatePackingList } from '../services/geminiService';
import { BriefcaseIcon } from '../components/icons/BriefcaseIcon';

// Client-side version of the types with a 'packed' state
interface ClientPackingItem extends PackingItem {
  packed: boolean;
}

interface ClientPackingCategory {
  category_name: string;
  items: ClientPackingItem[];
}

interface ClientPackingList {
  trip_title: string;
  packing_list: ClientPackingCategory[];
}

const PackingAssistant: React.FC = () => {
  const [destination, setDestination] = useState('');
  const [duration, setDuration] = useState('');
  const [activities, setActivities] = useState('');
  const [packingList, setPackingList] = useState<ClientPackingList | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!destination || !duration || !activities) {
      setError('Please fill out all fields to get your personalized list.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setPackingList(null);

    const result = await generatePackingList(destination, duration, activities);
    setIsLoading(false);

    if (result) {
      const clientSideList: ClientPackingList = {
        ...result,
        packing_list: result.packing_list.map(category => ({
          ...category,
          items: category.items.map(item => ({
            ...item,
            packed: false,
          })),
        })),
      };
      setPackingList(clientSideList);
    } else {
      setError('Failed to generate packing list. The AI might be busy, please try again.');
    }
  };

  const handleTogglePacked = (categoryIndex: number, itemIndex: number) => {
    setPackingList(currentList => {
      if (!currentList) return null;

      // Use a more robust immutable update pattern
      return {
        ...currentList,
        packing_list: currentList.packing_list.map((category, catIdx) => {
          if (catIdx !== categoryIndex) {
            return category;
          }
          return {
            ...category,
            items: category.items.map((item, itemIdx) => {
              if (itemIdx !== itemIndex) {
                return item;
              }
              return { ...item, packed: !item.packed };
            }),
          };
        }),
      };
    });
  };

  const { packedItems, totalItems, progress } = useMemo(() => {
    if (!packingList) return { packedItems: 0, totalItems: 0, progress: 0 };
    
    let packed = 0;
    let total = 0;
    packingList.packing_list.forEach(category => {
      total += category.items.length;
      packed += category.items.filter(item => item.packed).length;
    });

    return {
      packedItems: packed,
      totalItems: total,
      progress: total > 0 ? Math.round((packed / total) * 100) : 0,
    };
  }, [packingList]);

  const SkeletonLoader = () => (
    <div className="mt-8 animate-pulse">
      <div className="solaris-panel p-6">
        <div className="h-8 bg-[#333]/50 rounded-md w-3/4 mx-auto mb-6"></div>
        <div className="h-4 bg-[#333]/50 rounded-md w-1/2 mx-auto mb-4"></div>
        <div className="w-full bg-[#333]/50 rounded-full h-2.5 mb-8"></div>
        <div className="space-y-6">
          {[...Array(3)].map((_, i) => (
            <div key={i}>
              <div className="h-6 bg-[#333]/50 rounded-md w-1/3 mb-4"></div>
              <div className="space-y-3">
                <div className="h-5 bg-[#333]/50 rounded-md w-full"></div>
                <div className="h-5 bg-[#333]/50 rounded-md w-5/6"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <BriefcaseIcon className="h-12 w-12 mx-auto text-[#ff8c00] mb-2"/>
        <h1 className="text-4xl font-bold text-[#f5f5f5]">Smart Packing Assistant</h1>
        <p className="mt-2 text-lg text-[#a3a3a3]/70">Never forget an essential again. Get a packing list tailored to your trip.</p>
      </div>

      <form onSubmit={handleSubmit} className="solaris-panel p-6 space-y-4 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label htmlFor="destination-pack" className="block text-sm font-medium text-[#a3a3a3]">Destination</label>
            <input
              type="text"
              id="destination-pack"
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
              placeholder="e.g., Swiss Alps"
              className="mt-1 block w-full bg-[#333]/50 border border-[#444] rounded-md shadow-sm py-2 px-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00] focus:border-[#ff8c00]"
            />
          </div>
          <div>
            <label htmlFor="duration-pack" className="block text-sm font-medium text-[#a3a3a3]">Duration (days)</label>
            <input
              type="number"
              id="duration-pack"
              value={duration}
              onChange={(e) => setDuration(e.target.value)}
              placeholder="e.g., 10"
              className="mt-1 block w-full bg-[#333]/50 border border-[#444] rounded-md shadow-sm py-2 px-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00] focus:border-[#ff8c00]"
            />
          </div>
          <div>
            <label htmlFor="activities-pack" className="block text-sm font-medium text-[#a3a3a3]">Activities</label>
            <input
              type="text"
              id="activities-pack"
              value={activities}
              onChange={(e) => setActivities(e.target.value)}
              placeholder="e.g., Hiking, fine dining"
              className="mt-1 block w-full bg-[#333]/50 border border-[#444] rounded-md shadow-sm py-2 px-3 text-[#f5f5f5] focus:outline-none focus:ring-[#ff8c00] focus:border-[#ff8c00]"
            />
          </div>
        </div>
        <button
          type="submit"
          disabled={isLoading}
          className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-[#ff8c00] hover:bg-[#e67e00] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#ff8c00] disabled:bg-[#ff8c00]/50 disabled:cursor-not-allowed"
        >
          {isLoading ? 'Thinking...' : 'Generate My Packing List'}
        </button>
      </form>

      {isLoading && <SkeletonLoader />}
      {error && !isLoading && <p className="text-red-400 text-sm text-center mt-4">{error}</p>}

      {packingList && (
        <div className="mt-8 solaris-panel p-6 animate-fadeIn">
          <div className="max-w-2xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-4">{packingList.trip_title}</h2>
            <div className="mb-6">
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm font-medium text-[#a3a3a3]">Packing Progress</span>
                <span className="text-sm font-medium text-[#ff8c00]">{packedItems} / {totalItems} items</span>
              </div>
              <div className="w-full bg-[#333]/50 rounded-full h-2.5">
                <div className="bg-[#ff8c00] h-2.5 rounded-full transition-all duration-500 ease-out" style={{ width: `${progress}%` }}></div>
              </div>
            </div>

            <div className="space-y-6">
              {packingList.packing_list.map((category, catIndex) => (
                <div key={catIndex}>
                  <h3 className="text-lg font-semibold text-[#ff8c00] border-b border-[#444] pb-2 mb-3">{category.category_name}</h3>
                  <ul className="space-y-2">
                    {category.items.map((item, itemIndex) => (
                      <li key={itemIndex} className="flex items-center">
                        <label className="flex items-center cursor-pointer w-full group">
                          <input
                            type="checkbox"
                            checked={item.packed}
                            onChange={() => handleTogglePacked(catIndex, itemIndex)}
                            className="h-4 w-4 bg-[#333]/50 border-[#444] rounded text-[#ff8c00] focus:ring-[#ff8c00] cursor-pointer"
                          />
                          <span className={`ml-3 flex-grow text-[#f5f5f5] transition-colors ${item.packed ? 'line-through text-[#a3a3a3]/50' : 'group-hover:text-white'}`}>
                            {item.item_name}
                          </span>
                          <span className={`text-sm font-mono px-2 py-0.5 rounded ${item.packed ? 'text-[#1a1818]/50' : 'text-[#a3a3a3]/70 bg-[#333]/40'}`}>
                            {item.quantity}
                          </span>
                        </label>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PackingAssistant;