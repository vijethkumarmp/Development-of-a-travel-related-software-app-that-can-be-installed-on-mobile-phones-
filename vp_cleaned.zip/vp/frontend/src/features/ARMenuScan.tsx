import React, { useState, useRef, useEffect, useCallback } from 'react';
import { MenuAnalysisResponse } from '../types';
import { analyzeMenuImage } from '../services/geminiService';
import { ScanIcon } from '../components/icons/ScanIcon';
import { CameraIcon } from '../components/icons/CameraIcon';
import { SparklesIcon } from '../components/icons/SparklesIcon';
import { FireIcon } from '../components/icons/FireIcon';
import { LockClosedIcon } from '../components/icons/LockClosedIcon';

const ARMenuScan: React.FC = () => {
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [analysisResult, setAnalysisResult] = useState<MenuAnalysisResponse | null>(null);
    const [capturedImage, setCapturedImage] = useState<string | null>(null);
    const [isCameraOn, setIsCameraOn] = useState(false);
    const [permissionDenied, setPermissionDenied] = useState(false);
    
    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const streamRef = useRef<MediaStream | null>(null);

    const stopCamera = useCallback(() => {
        if (streamRef.current) {
            streamRef.current.getTracks().forEach(track => track.stop());
            streamRef.current = null;
        }
        setIsCameraOn(false);
    }, []);
    
    const startCamera = useCallback(async () => {
        setError(null);
        setPermissionDenied(false);
        setAnalysisResult(null);
        setCapturedImage(null);
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
                if (videoRef.current) {
                    videoRef.current.srcObject = stream;
                    streamRef.current = stream;
                    setIsCameraOn(true);
                }
            } catch (err: any) {
                console.error("Camera error:", err);
                if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
                    setError("Camera access was denied. Please enable it in your browser settings to use this feature.");
                    setPermissionDenied(true);
                } else {
                    setError("Could not access camera. Please check other browser permissions.");
                }
                setIsCameraOn(false);
            }
        } else {
            setError("Camera not supported on this device.");
        }
    }, []);

    const handleCaptureAndScan = async () => {
        if (videoRef.current && canvasRef.current) {
            const video = videoRef.current;
            const canvas = canvasRef.current;
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            const context = canvas.getContext('2d');
            if (context) {
                context.drawImage(video, 0, 0, canvas.width, canvas.height);
                const imageDataUrl = canvas.toDataURL('image/jpeg', 0.9);
                const base64Image = imageDataUrl.split(',')[1];
                
                setCapturedImage(imageDataUrl);
                stopCamera();
                setIsLoading(true);

                const result = await analyzeMenuImage(base64Image);
                if (result) {
                    setAnalysisResult(result);
                    if (result.menu_items.length === 0) {
                        setError("Could not detect any menu items. Please try again with a clearer picture.");
                    }
                } else {
                    setError("Failed to analyze the menu. The AI may be busy. Please try again.");
                }
                setIsLoading(false);
            }
        }
    };

    const reset = () => {
        stopCamera();
        setError(null);
        setAnalysisResult(null);
        setCapturedImage(null);
        setIsLoading(false);
    };

    // Cleanup camera on component unmount
    useEffect(() => {
        return () => {
            stopCamera();
        };
    }, [stopCamera]);

    return (
        <div className="max-w-7xl mx-auto animate-fadeIn">
            <div className="text-center mb-8">
                <ScanIcon className="h-12 w-12 mx-auto text-cyan-400 mb-2"/>
                <h1 className="text-4xl font-bold text-slate-100">AR Menu Scan</h1>
                <p className="mt-2 text-lg text-slate-300/70">Instantly translate and understand foreign menus.</p>
            </div>

            <div className="glass-panel p-6 rounded-xl">
                {!capturedImage && !isCameraOn && (
                    <div className="text-center py-16">
                        {permissionDenied ? (
                            <>
                                <LockClosedIcon className="h-16 w-16 mx-auto text-red-400 mb-4" />
                                <h2 className="text-2xl font-semibold text-slate-100">Camera Access Denied</h2>
                                {error && <p className="text-red-400 text-sm mt-2 mb-6 max-w-sm mx-auto">{error}</p>}
                                <button onClick={startCamera} className="px-6 py-3 bg-cyan-600 text-white rounded-lg font-semibold hover:bg-cyan-700 transition-colors shadow-lg">
                                    Retry Permission
                                </button>
                            </>
                        ) : (
                            <>
                                <CameraIcon className="h-16 w-16 mx-auto text-slate-400/70 mb-4" />
                                <h2 className="text-2xl font-semibold text-slate-100">Ready to Scan?</h2>
                                <p className="text-slate-300/70 mt-2 mb-6">Point your camera at a menu to begin.</p>
                                <button onClick={startCamera} className="px-6 py-3 bg-cyan-600 text-white rounded-lg font-semibold hover:bg-cyan-700 transition-colors shadow-lg">
                                    Start Camera
                                </button>
                                {error && <p className="text-red-400 text-sm mt-4">{error}</p>}
                            </>
                        )}
                    </div>
                )}


                {isCameraOn && (
                     <div className="relative">
                        <video ref={videoRef} className="w-full h-auto rounded-lg" autoPlay playsInline />
                        <div className="absolute inset-0 flex items-end justify-center p-6 bg-gradient-to-t from-black/50 to-transparent">
                             <button onClick={handleCaptureAndScan} className="h-16 w-16 rounded-full bg-white/20 backdrop-blur-md border-2 border-white/50 flex items-center justify-center text-white transition-all duration-300 hover:bg-white/30 hover:scale-105 active:scale-95" aria-label="Scan Menu">
                                <ScanIcon className="h-8 w-8" />
                            </button>
                        </div>
                    </div>
                )}
                
                {capturedImage && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="relative">
                           <img src={capturedImage} alt="Captured Menu" className="rounded-lg w-full" />
                           {isLoading && (
                             <div className="absolute inset-0 bg-slate-950/70 backdrop-blur-sm rounded-lg flex flex-col items-center justify-center text-center p-4">
                                <SparklesIcon className="h-10 w-10 text-cyan-300 animate-pulse mb-4" />
                                <p className="font-semibold text-lg text-slate-100">Analyzing Menu...</p>
                                <p className="text-sm text-slate-300/70">This might take a moment.</p>
                             </div>
                           )}
                        </div>

                        <div className="flex flex-col">
                            <div className="flex justify-between items-center mb-4">
                               <h2 className="text-2xl font-bold text-slate-100">Menu Analysis</h2>
                               <button onClick={reset} className="px-4 py-2 text-sm bg-slate-800/60 text-white rounded-md font-semibold hover:bg-slate-700/60">
                                Scan Again
                               </button>
                            </div>
                           
                            {analysisResult && analysisResult.menu_items.length > 0 ? (
                                <div className="space-y-3 overflow-y-auto max-h-[500px] pr-2">
                                    {analysisResult.menu_items.map((item, index) => (
                                        <div key={index} className="bg-slate-950/50 p-4 rounded-lg animate-fadeIn" style={{ animationDelay: `${index * 100}ms`}}>
                                            <p className="text-xs text-slate-400/60 uppercase">{item.item_name}</p>
                                            <h3 className="text-lg font-bold text-cyan-300 mt-1">{item.translation}</h3>
                                            <p className="text-sm text-slate-200/90 mt-2">{item.description}</p>
                                            <div className="flex items-center gap-2 mt-3 text-xs text-yellow-400 border-t border-violet-800/50 pt-2">
                                                <FireIcon className="h-4 w-4" />
                                                <span>~{item.calorie_estimate} kcal</span>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                !isLoading && (
                                     <div className="flex-1 flex items-center justify-center text-center bg-slate-950/50 rounded-lg p-4">
                                        <p className="text-slate-400/70">{error || "No results to show."}</p>
                                     </div>
                                )
                            )}
                        </div>
                    </div>
                )}

            </div>
        </div>
    );
};

export default ARMenuScan;