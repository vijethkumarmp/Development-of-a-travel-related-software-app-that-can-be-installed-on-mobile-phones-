import React from 'react';

export const CarIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="M14 16H9m10-2.1a2.4 2.4 0 0 0-1-4.4c-1.3-.2-2.8-.2-4.1 0a2.4 2.4 0 0 0-1 4.4" />
    <path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 8.6 16.3 6 12 6s-6.7 2.6-8.5 4.1C2.7 10.3 2 11.1 2 12v3c0 .6.4 1 1 1h2" />
    <circle cx="7" cy="17" r="2" />
    <circle cx="17" cy="17" r="2" />
  </svg>
);
