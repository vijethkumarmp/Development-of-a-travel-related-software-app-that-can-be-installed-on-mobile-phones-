import React from 'react';

export const LiveGuideIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="M20.2 7.8c.1-.4.2-.8.2-1.2a6 6 0 0 0-12 0c0 .4.1.8.2 1.2" />
    <path d="M14.5 15.5c.3-.1.5-.3.7-.5a3.5 3.5 0 0 0-6.4 0c.2.2.4.4.7.5" />
    <path d="M12 22s-8-4.5-8-11.5a8 8 0 0 1 16 0c0 7-8 11.5-8 11.5z" />
    <circle cx="12" cy="10.5" r="1.5" />
  </svg>
);
