import React from 'react';

export const MapPinIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" stroke="none" {...props}>
    <path d="M12 0C7.589 0 4 3.589 4 8c0 4.411 8 16 8 16s8-11.589 8-16c0-4.411-3.589-8-8-8zm0 12a4 4 0 110-8 4 4 0 010 8z"/>
    <circle cx="12" cy="8" r="2" fill="#2c2a2a" />
  </svg>
);
