import React from 'react';

export const MastercardIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="38px" height="24px" viewBox="0 0 38 24" {...props}>
    <g fill="none" fillRule="evenodd">
      <path fill="#fff" d="M0 4C0 1.79.766 0 2.28 0h33.44C37.234 0 38 1.79 38 4v16c0 2.21-.766 4-2.28 4H2.28C.766 24 0 22.21 0 20V4z" />
      <circle cx="15" cy="12" r="7" fill="#EB001B" />
      <circle cx="23" cy="12" r="7" fill="#F79E1B" />
      <path fill="#FF5F00" d="M23 12c0 3.866-3.134 7-7 7s-7-3.134-7-7 3.134-7 7-7 7 3.134 7 7z" />
    </g>
  </svg>
);
