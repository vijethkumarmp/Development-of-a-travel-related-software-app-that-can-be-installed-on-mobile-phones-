import React from 'react';

export const WifiIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
        <path d="M1 12.5C1 12.5 3.5 10 7 10C10.5 10 13.5 12.5 13.5 12.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
        <path d="M1 16.5C1 16.5 5.5 13 12 13C18.5 13 23 16.5 23 16.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
        <path d="M1 8.5C1 8.5 4.5 6 9.5 6C14.5 6 18 8.5 18 8.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
    </svg>
);
