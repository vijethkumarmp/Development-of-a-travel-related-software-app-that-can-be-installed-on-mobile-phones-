import React from 'react';

export const FireIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="M12 2c2.2 0 4 1.8 4 4 0 2.2-1.8 4-4 4s-4-1.8-4-4c0-2.2 1.8-4 4-4z" />
    <path d="M12.6 10.6c.2.2.4.5.5.8.2.3.3.6.3.9 0 .3-.1.6-.3.9-.1.3-.3.5-.5.8-.2.2-.4.4-.6.6-.2.2-.5.3-.8.4-.3.1-.6.1-.9.1s-.6-.1-.9-.1c-.3,0-.6-.2-.8-.4-.2-.2-.4-.4-.6-.6-.2-.2-.4-.5-.5-.8-.2-.3-.3-.6-.3-.9 0-.3.1-.6.3-.9.1-.3.3-.5.5-.8.2-.2.4-.4.6-.6.2-.2.5-.3.8-.4.3-.1.6-.1.9-.1s.6.1.9.1c.3.1.6.2.8.4z" transform="translate(0, 4)" />
    <path d="M12 10.5a5 5 0 01-5 5c0 2.8 2.2 5 5 5s5-2.2 5-5a5 5 0 01-5-5z" transform="translate(0, 4)"/>
    <path d="M8.5 22c-1.7-1.7-2.5-4-2.5-6.5 0-2.8 1.4-5.3 3.5-6.5" />
    <path d="M15.5 22c1.7-1.7 2.5-4 2.5-6.5 0-2.8-1.4-5.3-3.5-6.5" />
  </svg>
);