import React from 'react';

export const ChipIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg width="40" height="30" viewBox="0 0 40 30" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
        <rect x="0.5" y="0.5" width="39" height="29" rx="4.5" fill="#D9D9D9" stroke="#9E9E9E"/>
        <path d="M11 15H29" stroke="#757575" strokeWidth="2"/>
        <path d="M20 7V23" stroke="#757575" strokeWidth="2"/>
        <path d="M15 11L15 19" stroke="#757575" strokeWidth="1.5" strokeLinecap="round"/>
        <path d="M25 11L25 19" stroke="#757575" strokeWidth="1.5" strokeLinecap="round"/>
        <path d="M16 15H24" stroke="#757575" strokeWidth="1.5" strokeLinecap="round"/>
        <path d="M16 15H24" stroke="#757575" strokeWidth="1.5" strokeLinecap="round"/>
    </svg>
);
