import React, { useRef, useEffect, useState, useCallback } from 'react';
import { ScanIcon } from './icons/ScanIcon';
import { LockClosedIcon } from './icons/LockClosedIcon';

interface DocumentScannerProps {
  onCapture: (base64Data: string) => void;
  onClose: () => void;
}

const DocumentScanner: React.FC<DocumentScannerProps> = ({ onCapture, onClose }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [error, setError] = useState<string | null>(null);
  const [permissionDenied, setPermissionDenied] = useState(false);

  const startCamera = useCallback(async () => {
    setError(null);
    setPermissionDenied(false);
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' }
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      } catch (err: any) {
        console.error("Error accessing camera:", err);
        if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
          setError("Camera permission denied. Please go to your browser settings to allow camera access for this site. You may need to reload the page afterwards.");
          setPermissionDenied(true);
        } else {
          setError("Could not access the camera. Please check permissions.");
        }
      }
    } else {
      setError("Camera not supported on this device.");
    }
  }, []);

  useEffect(() => {
    startCamera();

    return () => {
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [startCamera]);

  const handleCapture = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const context = canvas.getContext('2d');
      if (context) {
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        const base64Image = canvas.toDataURL('image/jpeg', 0.9).split(',')[1];
        onCapture(base64Image);
      }
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex flex-col items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="relative w-full max-w-2xl bg-[#1a1818] border border-[#444] rounded-xl overflow-hidden shadow-2xl" onClick={e => e.stopPropagation()}>
        {error ? (
          <div className="p-8 text-center flex flex-col items-center justify-center min-h-[300px]">
            {permissionDenied ? (
                <>
                    <LockClosedIcon className="h-12 w-12 text-red-400 mb-4" />
                    <h2 className="text-xl font-bold text-[#f5f5f5] mb-2">Camera Access Denied</h2>
                    <p className="text-[#a3a3a3]/70 max-w-sm mb-6 text-red-400">{error}</p>
                    <button 
                        onClick={startCamera}
                        className="px-5 py-2.5 bg-[#ff8c00] text-white rounded-lg font-semibold hover:bg-[#e67e00] transition-colors"
                    >
                        Retry Permission
                    </button>
                </>
            ) : (
                <p className="text-red-400">{error}</p>
            )}
          </div>
        ) : (
          <video ref={videoRef} className="w-full h-auto" autoPlay playsInline />
        )}
        <canvas ref={canvasRef} className="hidden" />
      </div>
      <div className="mt-6 flex gap-6 items-center">
        <button
          onClick={onClose}
          className="px-6 py-3 bg-gray-700/50 text-white rounded-lg font-semibold hover:bg-gray-600/50"
        >
          Cancel
        </button>
        <button
          onClick={handleCapture}
          disabled={!!error}
          className="h-16 w-16 rounded-full bg-white/20 backdrop-blur-md border-2 border-white/50 flex items-center justify-center text-white transition-all duration-300 hover:bg-white/30 hover:scale-105 active:scale-95 disabled:opacity-50"
          aria-label="Capture Scan"
        >
         <ScanIcon className="h-8 w-8" />
        </button>
      </div>
    </div>
  );
};

export default DocumentScanner;