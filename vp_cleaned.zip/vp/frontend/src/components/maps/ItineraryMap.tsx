import React, { useMemo } from 'react';
import { ItineraryDay } from '../../types';
import { MapPinIcon } from '../icons/MapPinIcon';

interface ItineraryMapProps {
  days: ItineraryDay[];
  selectedActivityId: string | null;
  onMarkerClick: (activityId: string) => void;
  getActivityId: (dayIndex: number, activityIndex: number) => string;
}

const ItineraryMap: React.FC<ItineraryMapProps> = ({ days, selectedActivityId, onMarkerClick, getActivityId }) => {
  const { points, bounds, projection } = useMemo(() => {
    const allPoints = days.flatMap((day, dayIndex) =>
      day.activities.map((activity, activityIndex) => ({
        ...activity,
        id: getActivityId(dayIndex, activityIndex),
        dayIndex,
      }))
    ).filter(a => a.latitude != null && a.longitude != null);

    if (allPoints.length === 0) {
      return { points: [], bounds: null, projection: () => [0, 0] };
    }

    const minLon = Math.min(...allPoints.map(p => p.longitude!));
    const maxLon = Math.max(...allPoints.map(p => p.longitude!));
    const minLat = Math.min(...allPoints.map(p => p.latitude!));
    const maxLat = Math.max(...allPoints.map(p => p.latitude!));
    
    const bounds = { minLon, maxLon, minLat, maxLat };

    const width = 800;
    const height = 400;
    const padding = 50;

    const lonRange = bounds.maxLon - bounds.minLon;
    const latRange = bounds.maxLat - bounds.minLat;

    const projection = (lat: number, lon: number): [number, number] => {
      // Simple linear projection
      const x = (((lon - bounds.minLon) / (lonRange || 1)) * (width - padding * 2)) + padding;
      const y = (((bounds.maxLat - lat) / (latRange || 1)) * (height - padding * 2)) + padding;
      return [x, y];
    };

    return { points: allPoints, bounds, projection };
  }, [days, getActivityId]);

  if (!bounds) {
    return (
      <div className="h-64 flex items-center justify-center bg-[#1a1818]/50 rounded-lg text-[#a3a3a3]/70">
        No locations with coordinates to display on the map.
      </div>
    );
  }

  return (
    <div className="bg-[#1a1818]/50 rounded-lg p-2 mb-8">
      <svg viewBox="0 0 800 400" className="w-full h-auto">
        <rect width="800" height="400" fill="#2c2a2a" rx="8" />

        {/* Render paths for each day */}
        {days.map((day, dayIndex) => {
          const dayPoints = day.activities
            .map(a => (a.latitude != null && a.longitude != null ? projection(a.latitude, a.longitude) : null))
            .filter((p): p is [number, number] => p !== null);
          
          if (dayPoints.length < 2) return null;

          const pathData = "M" + dayPoints.map(p => p.join(',')).join(' L');
          
          return (
            <path
              key={`path-${dayIndex}`}
              d={pathData}
              fill="none"
              stroke="#444"
              strokeWidth="2"
              strokeDasharray="4 4"
            />
          );
        })}


        {/* Render markers */}
        {points.map((point) => {
          const [x, y] = projection(point.latitude!, point.longitude!);
          const isSelected = point.id === selectedActivityId;
          
          return (
            <g key={point.id} transform={`translate(${x}, ${y})`} onClick={() => onMarkerClick(point.id)} className="cursor-pointer group">
              <MapPinIcon 
                className={`w-8 h-8 transform -translate-x-4 -translate-y-8 transition-all duration-300 ${isSelected ? 'text-[#ff8c00]' : 'text-[#a3a3a3]/70 group-hover:text-[#f5f5f5]'}`} 
                style={{ filter: isSelected ? 'drop-shadow(0 0 8px #ff8c00)' : 'none' }}
              />
               {isSelected && <circle cx="0" cy="0" r="8" fill="rgba(255,140,0,0.3)" ><animate attributeName="r" from="4" to="12" dur="1s" repeatCount="indefinite" /><animate attributeName="opacity" from="1" to="0" dur="1s" repeatCount="indefinite" /></circle>}
               <title>{point.description}</title>
            </g>
          );
        })}
      </svg>
    </div>
  );
};

export default ItineraryMap;
