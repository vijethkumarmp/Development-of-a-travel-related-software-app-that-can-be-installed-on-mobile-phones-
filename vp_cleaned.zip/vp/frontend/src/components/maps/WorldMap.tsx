
import React, { useState } from 'react';
import { VisitedPlace } from '../../types';

interface WorldMapProps {
  visitedPlaces: VisitedPlace[];
  onMarkerClick: (bookingId: number) => void;
}

// Basic Mercator projection functions
const project = (lat: number, lon: number): [number, number] => {
  const width = 960;
  const height = 500;
  const latRad = (lat * Math.PI) / 180;
  const x = (width * (lon + 180)) / 360;
  const mercN = Math.log(Math.tan(Math.PI / 4 + latRad / 2));
  const y = height / 2 - (width * mercN) / (2 * Math.PI);
  return [x, y];
};

const WorldMap: React.FC<WorldMapProps> = ({ visitedPlaces, onMarkerClick }) => {
  const [activePlace, setActivePlace] = useState<VisitedPlace | null>(null);

  const handleMarkerClick = (place: VisitedPlace) => {
    // Only allow selecting pop-ups for past trips
    if (place.status === 'past') {
      setActivePlace(place === activePlace ? null : place);
    }
    // Always notify parent to handle journal display logic
    onMarkerClick(place.bookingId);
  };

  const activePlaceCoords = activePlace ? project(activePlace.latitude, activePlace.longitude) : null;
  
  return (
    <div className="relative">
      <svg viewBox="0 0 960 500" className="w-full h-auto bg-[#1a1818]/50 rounded-md">
        {/* Simplified World Map SVG Path */}
        <path 
          d="M480 0L473.4 3.7c-21.4 12-45.9 22.8-72.3 29.1L384 37.1l-10.8 1.4c-22.1 2.9-44.3 6.9-66.2 12.3L296.2 53l-10.7-1.1c-22.1-2.3-44.5-3.3-66.9-2.9l-11 .2-10.2 2.1c-21.2 4.4-41.9 10-61.7 17.2l-10.3 3.7-10.1-1.2c-20.9-2.5-42-2.9-63-1.4l-10.7.8-10.5 2.1c-21.6 4.3-42.7 10-62.8 17.2l-10.2 3.7-10.4-.2c-21.6-.4-43.2 1.2-64.4 4.9l-10.9 1.9L0 120.2l.2 10.9c.4 21.6 2.8 43 7.1 63.8l2.1 10.2 1.2 10.1c2.5 20.9 7.1 41.5 13.6 61.2l3.7 10.3 2.1 10.2c4.3 20.2 10 39.9 17.2 58.6l3.7 10.1.8 10.7c1.6 21.4 5.3 42.6 10.8 63.1l1.4 10.8-4.2 9.5c-8.4 18.9-15.8 38.3-21.8 58.2l-2.1 10.2-1.2 10.1c-2.5 20.9-3.9 42-4.1 63.2l-.1 10.9 9.5 4.2c18.9 8.4 38.3 15.8 58.2 21.8l10.2 2.1 10.1 1.2c20.9 2.5 42 3.9 63.2 4.1l10.9.1 10.7-1.6c21.8-3.2 43.1-8.1 63.8-14.7l10.2-2.1 10.2-1.2c21.2-2.5 42.3-5.3 63.1-10.8l10.8-1.4 9.5-4.2c18.9-8.4 37.4-17.8 55.1-28.7l10.1-3.7 10.7.8c21.8 1.7 43.6 1.7 65.3 0l10.9-.1 10.5-2.1c21.6-4.3 42.7-10 62.8-17.2l10.2-3.7 10.4.2c21.6.4 43.2-1.2 64.4-4.9l-10.9-1.9 10.7-3.2c21.8-6.5 42.9-14.7 62.8-24.6l10.2-3.7 10.1 1.2c20.9 2.5 42 2.9 63 1.4l10.7-.8 10.5-2.1c21.6-4.3 42.7-10 62.8-17.2l10.2-3.7 10.4.2c-21.6-.4-43.2 1.2-64.4 4.9l-10.9-1.9z"
          fill="#2c2a2a"
          stroke="#b8860b"
          strokeWidth="0.5"
        />

        <g>
          {visitedPlaces.map((place, index) => {
            const [x, y] = project(place.latitude, place.longitude);
            const isSelected = activePlace?.bookingId === place.bookingId;
            const isPast = place.status === 'past';

            if (isPast) {
              return (
                <circle
                  key={index}
                  cx={x}
                  cy={y}
                  r={isSelected ? "8" : "4"}
                  fill={isSelected ? "rgb(255 200 0)" : "rgb(255 140 0)"}
                  stroke="rgb(255 220 100)"
                  strokeWidth="1.5"
                  className="cursor-pointer transition-all duration-300 hover:r-6"
                  onClick={() => handleMarkerClick(place)}
                >
                  <animate
                    attributeName="r"
                    from="4"
                    to="8"
                    dur="1.5s"
                    begin={`${index * 0.1}s`}
                    repeatCount="indefinite"
                    values="4; 8; 4"
                  />
                </circle>
              );
            } else { // Upcoming
              return (
                  <circle
                    key={index}
                    cx={x}
                    cy={y}
                    r="5"
                    fill="transparent"
                    stroke="rgb(184 134 11)"
                    strokeWidth="2"
                    className="cursor-not-allowed"
                  >
                     <animate
                        attributeName="stroke-opacity"
                        dur="2s"
                        values="0;1;0"
                        repeatCount="indefinite"
                        begin={`${index * 0.2}s`}
                      />
                  </circle>
              );
            }
          })}
        </g>
        
        {activePlace && activePlace.status === 'past' && activePlaceCoords && (
          <g transform={`translate(${activePlaceCoords[0]}, ${activePlaceCoords[1]})`} className="transition-opacity duration-300 animate-fadeIn">
            <g transform="translate(15, -15)">
              <rect x="0" y="-30" width="160" height="55" rx="5" fill="rgba(26, 24, 24, 0.9)" stroke="rgba(184, 134, 11, 0.7)" />
              <text x="10" y="-13" fill="white" fontSize="12" fontWeight="bold">{activePlace.name}</text>
              <text x="10" y="4" fill="#a3a3a3" fontSize="10">{activePlace.country}</text>
              <text
                x="10" y="19"
                fill="#ff8c00"
                fontSize="10"
                className="cursor-pointer"
                onClick={() => onMarkerClick(activePlace.bookingId)}
                style={{ textDecoration: 'underline' }}
              >
                View/Edit Journal Entry
              </text>
            </g>
          </g>
        )}
      </svg>
    </div>
  );
};

export default WorldMap;