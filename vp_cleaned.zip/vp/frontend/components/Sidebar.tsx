
import React from 'react';
import { FEATURES } from '../constants';
import { Feature } from '../types';

interface SidebarProps {
  activeFeature: Feature;
  setActiveFeature: (feature: Feature) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeFeature, setActiveFeature }) => {
  return (
    <aside className="w-64 bg-[#1a1818]/80 backdrop-blur-lg border-r border-[#b8860b]/30 flex flex-col">
      <div className="p-6 flex items-center space-x-3">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-[#ff8c00]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M21.5 12c0-5.25-4.25-9.5-9.5-9.5S2.5 6.75 2.5 12s4.25 9.5 9.5 9.5"/>
          <path d="M12 2.5v19"/>
          <path d="M2.5 12h19"/>
          <path d="M4.1 19.9a9.5 9.5 0 0 0 15.8 0"/>
          <path d="M4.1 4.1a9.5 9.5 0 0 1 15.8 0"/>
        </svg>
        <h1 className="text-2xl font-bold text-[#f5f5f5]">TripBro</h1>
      </div>
      <nav className="flex-1 px-4 py-2 space-y-1">
        {FEATURES.map((feature) => (
          <button
            key={feature.id}
            onClick={() => setActiveFeature(feature)}
            className={`w-full flex items-center px-4 py-2.5 text-sm font-medium rounded-md transition-all duration-200 ease-in-out ${
              activeFeature.id === feature.id
                ? 'bg-[#ff8c00]/20 text-[#ff8c00]'
                : 'text-[#a3a3a3]/70 hover:bg-[#2c2a2a] hover:text-[#f5f5f5]'
            }`}
          >
            <feature.Icon className="h-5 w-5 mr-3" />
            <span>{feature.name}</span>
          </button>
        ))}
      </nav>
      <div className="p-4 border-t border-[#b8860b]/30">
        <div className="flex items-center">
            <img className="h-10 w-10 rounded-full" src="https://picsum.photos/seed/traveler/100" alt="User Avatar"/>
            <div className="ml-3">
                <p className="text-sm font-medium text-[#f5f5f5]">Vijeth Kumar</p>
                <p className="text-xs text-[#a3a3a3]/60">Pro Traveler</p>
            </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;