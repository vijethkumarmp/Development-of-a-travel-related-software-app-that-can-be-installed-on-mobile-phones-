# 🚀 QUICK START GUIDE

## One-Command Setup

### Start Backend
```bash
cd c:\Users\91797\Downloads\grpproject\backend
python manage.py runserver 0.0.0.0:8000
```
✅ Backend running at: **http://localhost:8000**

### Start Frontend  
```bash
cd c:\Users\91797\Downloads\grpproject\frontend
npm run dev
```
✅ Frontend running at: **http://localhost:5173**

---

## Test the Connection

### 1. Create a Test User
**POST** `http://localhost:8000/api/register/`
```json
{
  "username": "testuser",
  "email": "test@example.com",
  "password": "TestPass123!"
}
```

### 2. Login
**POST** `http://localhost:8000/api/token/`
```json
{
  "username": "testuser",
  "password": "TestPass123!"
}
```
Returns: `{ "access": "eyJ...", "refresh": "eyJ..." }`

### 3. Use the Token
**GET** `http://localhost:8000/api/userprofiles/`
Header: `Authorization: Bearer eyJ...`

---

## 📊 All Fixed Models & Fields

| Model | Key Fields |
|-------|-----------|
| **Translation** | source_language ✅, target_language, translated_text |
| **PackingList** | destination ✅, trip_details ✅, packing_list_items ✅ |
| **SouvenirSuggestion** | location ✅, suggestion ✅ |
| **JetLagPlan** | departure_location ✅, arrival_location ✅, flight_details ✅ |
| **Booking** | booking_type ✅, booking_date ✅, confirmation_number ✅ |
| **ExpenseEntry** | amount, currency, category, note |
| **MoodEntry** | mood, note |
| **OfflineMapDownload** | area, file_ref |
| **ScrapbookEntry** | title, content |
| **SOSContact** | name, phone, notes |

---

## 📝 Frontend API Usage Examples

### Get All Itineraries
```typescript
import { getItineraries } from '@/services/apiService';
const itineraries = await getItineraries();
```

### Create New Expense
```typescript
import { createExpense } from '@/services/apiService';
const expense = await createExpense({
  amount: 50,
  currency: 'USD',
  category: 'Food',
  note: 'Lunch'
});
```

### Translate Text
```typescript
import { translateText } from '@/services/apiService';
const result = await translateText('Hello', 'Spanish');
// Returns: { translated_text: 'Hola', source_language: 'English', ... }
```

### Generate Itinerary Suggestion
```typescript
import { generateItinerarySuggestion } from '@/services/apiService';
const suggestion = await generateItinerarySuggestion('Tokyo, Japan');
```

---

## 🐛 Common Issues & Solutions

| Issue | Solution |
|-------|----------|
| Backend won't start | Check Python version (3.9+), run migrations |
| Frontend won't start | Clear node_modules, run `npm install` |
| API calls failing | Verify `.env.local` has `VITE_API_URL` |
| Authentication fails | User must exist, password correct |
| CORS errors | Backend CORS is enabled in settings.py |
| Database locked | Restart backend server |

---

## 📂 Important Files Modified

```
✅ backend/backendapp/models.py        - Added all missing fields
✅ backend/backendapp/serializers.py   - Fixed field mappings
✅ backend/backendapp/views.py         - Added RegisterView, fixed field names
✅ backend/backendapp/urls.py          - Added register endpoint
✅ frontend/src/services/apiService.ts - NEW: Complete API integration
✅ frontend/.env.local                 - Added VITE_API_URL
✅ frontend/postcss.config.js          - Updated for Tailwind v4
✅ frontend/src/features/LoginPage.tsx - Updated for backend auth
```

---

## 🎯 Project Status

| Component | Status |
|-----------|--------|
| Backend Server | ✅ Running |
| Frontend Server | ✅ Running |
| Database | ✅ SQLite configured |
| API Integration | ✅ Connected |
| Authentication | ✅ JWT implemented |
| CORS | ✅ Enabled |
| All Models | ✅ Fixed |
| All Serializers | ✅ Fixed |
| All ViewSets | ✅ Working |

---

## 💡 Next Steps

1. **Test in Browser**: http://localhost:5173
2. **Login with test user** (or register new one)
3. **Create sample data** (expenses, itineraries, etc.)
4. **Check backend**: http://localhost:8000/admin (admin panel)
5. **View API docs**: http://localhost:8000/api (DRF browsable API)

---

## 🔐 Security Notes

- Tokens stored in localStorage
- JWT authentication on all endpoints
- CORS enabled for localhost
- All API calls require authentication (except register/token)
- Passwords hashed using Django security

**You're all set! Happy traveling! 🌍✈️**
