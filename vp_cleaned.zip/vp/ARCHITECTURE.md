# 🏗️ TripBro Architecture & Data Flow

## System Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│                          USER'S BROWSER                                 │
│                                                                         │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │                    React Frontend (Port 5173)                   │  │
│  │  ┌────────────────┐ ┌───────────────┐ ┌──────────────────┐    │  │
│  │  │   LoginPage    │ │   Dashboard   │ │  ExpenseManager  │    │  │
│  │  └────────────────┘ └───────────────┘ └──────────────────┘    │  │
│  │  ┌────────────────┐ ┌───────────────┐ ┌──────────────────┐    │  │
│  │  │ItineraryBuild │ │   Bookings    │ │   Scrapbook      │    │  │
│  │  └────────────────┘ └───────────────┘ └──────────────────┘    │  │
│  │                                                                 │  │
│  │  ┌──────────────────────────────────────────────────────────┐ │  │
│  │  │            API Service (apiService.ts)                  │ │  │
│  │  │  • getToken()   • createExpense()  • translateText()   │ │  │
│  │  │  • getItineraries() • getBookings() • askLocalGuide() │ │  │
│  │  │  ... 60+ endpoints total                              │ │  │
│  │  └──────────────────────────────────────────────────────────┘ │  │
│  │                                                                 │  │
│  │  ┌──────────────────────────────────────────────────────────┐ │  │
│  │  │           Local Storage (IndexedDB)                      │ │  │
│  │  │  • Bookings  • Expenses  • MoodEntries  • Scrapbook     │ │  │
│  │  └──────────────────────────────────────────────────────────┘ │  │
│  └──────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────┘
                                 ↑ ↓
                         (HTTP Requests/Responses)
                    (JWT Bearer Tokens in Headers)
                                 ↑ ↓
┌─────────────────────────────────────────────────────────────────────────┐
│                    Django Backend (Port 8000)                           │
│                                                                         │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │              REST API Endpoints (/api/)                         │  │
│  │  ┌──────────────┐ ┌──────────────┐ ┌──────────────────────┐   │  │
│  │  │  /register/  │ │   /token/    │ │ /token/refresh/    │   │  │
│  │  └──────────────┘ └──────────────┘ └──────────────────────┘   │  │
│  │                                                                 │  │
│  │  ┌──────────────────────────────────────────────────────────┐ │  │
│  │  │           Resource Endpoints                            │ │  │
│  │  │  /userprofiles/    /itineraries/    /translations/     │ │  │
│  │  │  /live-guides/     /packing-lists/  /souvenirs/        │ │  │
│  │  │  /jetlag-plans/    /bookings/       /expenses/         │ │  │
│  │  │  /moods/           /offline-maps/   /scrapbook-entries/ │ │  │
│  │  │  /sos-contacts/                                         │ │  │
│  │  └──────────────────────────────────────────────────────────┘ │  │
│  │                                                                 │  │
│  │  ┌──────────────────────────────────────────────────────────┐ │  │
│  │  │            ViewSets (Business Logic)                     │ │  │
│  │  │  • UserProfileViewSet          • BookingViewSet         │ │  │
│  │  │  • ItinerarySuggestionViewSet  • ExpenseEntryViewSet    │ │  │
│  │  │  • TranslationViewSet          • MoodEntryViewSet       │ │  │
│  │  │  • LiveGuideQueryViewSet       • ... 8 more             │ │  │
│  │  └──────────────────────────────────────────────────────────┘ │  │
│  │                                                                 │  │
│  │  ┌──────────────────────────────────────────────────────────┐ │  │
│  │  │           Serializers (Data Validation)                  │ │  │
│  │  │  Converts between JSON and Django Models                │ │  │
│  │  └──────────────────────────────────────────────────────────┘ │  │
│  │                                                                 │  │
│  │  ┌──────────────────────────────────────────────────────────┐ │  │
│  │  │          Django Models (ORM)                             │ │  │
│  │  │  ✅ User, UserProfile, ItinerarySuggestion              │ │  │
│  │  │  ✅ Translation, LiveGuideQuery, PackingList            │ │  │
│  │  │  ✅ SouvenirSuggestion, JetLagPlan, Booking            │ │  │
│  │  │  ✅ ExpenseEntry, MoodEntry, OfflineMapDownload       │ │  │
│  │  │  ✅ ScrapbookEntry, SOSContact                          │ │  │
│  │  └──────────────────────────────────────────────────────────┘ │  │
│  └──────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────┘
                                 ↑ ↓
                       (SQL Queries)
                                 ↑ ↓
┌─────────────────────────────────────────────────────────────────────────┐
│                      SQLite Database                                    │
│                                                                         │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │ Tables:                                                          │  │
│  │ • auth_user (Django built-in)                                  │  │
│  │ • backendapp_userprofile (1:1 with auth_user)                │  │
│  │ • backendapp_itinerarysuggestion (user foreign key)          │  │
│  │ • backendapp_translation (user foreign key)                  │  │
│  │ • backendapp_liveguidequery (user foreign key)               │  │
│  │ • backendapp_packinglist (user foreign key)                  │  │
│  │ • backendapp_souvenirsuggestion (user foreign key)           │  │
│  │ • backendapp_jetlagplan (user foreign key)                   │  │
│  │ • backendapp_booking (user foreign key)                      │  │
│  │ • backendapp_expenseentry (user foreign key)                 │  │
│  │ • backendapp_moodentry (user foreign key)                    │  │
│  │ • backendapp_offlinemapdownload (user foreign key)           │  │
│  │ • backendapp_scrapbookentry (user foreign key)               │  │
│  │ • backendapp_soscontact (user foreign key)                   │  │
│  └──────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Data Flow Diagram

```
╔════════════════════════════════════════════════════════════════════╗
║                    USER REGISTRATION FLOW                         ║
╚════════════════════════════════════════════════════════════════════╝

  User fills form              Frontend API Call          Backend Processing
  ─────────────────           ──────────────────          ──────────────────
  
  username: john      ──→   POST /api/register/    ──→   Create User
  email: john@ex      │                               │   Create UserProfile
  password: pass      │      {                         │   Hash password
                      │        username: john,        │   Validate uniqueness
                      │        email: john@ex,        │   
                      │        password: pass         │
                      │      }                        │
                      └──────────────────────────────→ │
                                                       └──→ Database Write
                                                           ↓
                                                   Response: {
                                                     id: 1,
                                                     username: john,
                                                     email: john@ex,
                                                     message: User created
                                                   }
                                                       ↓
                      ←──────────────────────────────────
  
  Success message             Frontend Storage        User Logged In
  ────────────────           ────────────────        ───────────────
  "User created!"                  │
                              Set in localStorage


╔════════════════════════════════════════════════════════════════════╗
║                     USER LOGIN FLOW                               ║
╚════════════════════════════════════════════════════════════════════╝

  User fills form             Frontend API Call       Backend Verification
  ─────────────────          ──────────────────       ────────────────────
  
  username: john      ──→   POST /api/token/    ──→  Query User
  password: pass      │                            │  Verify Password Hash
                      │      {                      │  If valid:
                      │        username: john,      │    Generate JWT token
                      │        password: pass       │
                      │      }                      │
                      └─────────────────────────→  │
                                                    └──→ Return JWT
                                                       {
                                                         access: "eyJ...",
                                                         refresh: "eyJ..."
                                                       }
                                                       ↓
                      ←──────────────────────────────
  
  Token Storage            Authenticated State        API Authorization Ready
  ─────────────────        ──────────────────         ────────────────────────
  Store in localStorage    User is logged in          All future requests:
  token = eyJ...           Redirect to dashboard      Header: 
                                                      Authorization: Bearer eyJ...


╔════════════════════════════════════════════════════════════════════╗
║               CREATE EXPENSE FLOW (WITH AUTH)                      ║
╚════════════════════════════════════════════════════════════════════╝

  User fills form          Frontend API Call        Backend Processing
  ──────────────          ──────────────────       ──────────────────
  
  amount: 50      ──→   POST /api/expenses/   ──→  Get Current User
  currency: USD   │                              │  from JWT token
  category: Food  │      {                       │  
  note: Lunch     │        amount: 50,           │  Validate Data
                  │        currency: USD,        │
                  │        category: Food,       │  Set user_id =
                  │        note: Lunch           │  current_user.id
                  │      }                       │
                  │                              │  Create Expense Record
                  │      Header:                 │
                  │      Authorization:         │  
                  │      Bearer eyJ...          │
                  └──────────────────────────→ │
                                                └──→ Database Write
                                                   expense_record = {
                                                     id: 1,
                                                     user_id: 1,
                                                     amount: 50,
                                                     currency: USD,
                                                     category: Food,
                                                     note: Lunch,
                                                     created_at: 2025-11-15
                                                   }
                                                   ↓
                      ←─────────────────────────────────
  
  Display Result         Frontend Processes       User Sees Expense
  ──────────────        ───────────────────      ───────────────────
  Expense added         Response from API        Listed in expenses
  Success message       Update local state       "Food: $50 USD"


╔════════════════════════════════════════════════════════════════════╗
║                   GET ALL EXPENSES FLOW                            ║
╚════════════════════════════════════════════════════════════════════╝

  User clicks         Frontend API Call          Backend Processing
  "View Expenses"     ──────────────────        ──────────────────
  
                ──→   GET /api/expenses/   ──→  Get Current User
                │                            │  from JWT token
                │     Header:                │
                │     Authorization:        │  Query Database:
                │     Bearer eyJ...         │  SELECT * FROM expenses
                └──────────────────────────→  WHERE user_id = 1
                                               ↓
                                        Returns: [
                                          {id: 1, amount: 50, ...},
                                          {id: 2, amount: 30, ...},
                                          {id: 3, amount: 20, ...}
                                        ]
                                               ↓
                      ←──────────────────────────────
  
  Display List        Frontend Processes       User Sees Data
  ────────────        ──────────────────       ──────────────
  Show all expenses   Filter by current user   Expense List:
                     (already done by API)    1. $50 USD Food
                     Display in table          2. $30 USD Transport
                     Calculate totals         3. $20 USD Hotel
                                              Total: $100 USD
```

---

## Component Interaction Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                    Frontend Components                         │
└─────────────────────────────────────────────────────────────────┘

                    ┌─────────────────┐
                    │  LoginPage.tsx  │
                    └────────┬────────┘
                             │
                    Uses apiService.ts
                             │
                    ┌────────▼────────────┐
                    │  After Login:       │
                    │  - Dashboard.tsx    │
                    │  - ExpenseManager   │
                    │  - BookingManager   │
                    │  - ItineraryBuilder │
                    └────────┬────────────┘
                             │
              All components share:
              - JWT token from localStorage
              - apiService for backend calls
              - TripContext for state
              - dbService for local storage

┌─────────────────────────────────────────────────────────────────┐
│              apiService.ts (API Gateway)                        │
│                                                                 │
│  • Handles all HTTP requests                                  │
│  • Adds JWT tokens to headers                                 │
│  • Handles errors and responses                               │
│  • Provides 60+ methods for all endpoints                     │
└──────────────────────────┬──────────────────────────────────────┘
                           │
                (Makes HTTP requests to)
                           │
┌──────────────────────────▼──────────────────────────────────────┐
│              Django Backend API                                │
│                                                                 │
│  • Receives HTTP requests                                      │
│  • Validates JWT tokens                                        │
│  • Processes business logic                                    │
│  • Returns JSON responses                                      │
└──────────────────────────┬──────────────────────────────────────┘
                           │
                (Queries/Updates)
                           │
┌──────────────────────────▼──────────────────────────────────────┐
│              SQLite Database                                    │
│                                                                 │
│  • Stores all user data                                         │
│  • Maintains data integrity                                     │
│  • Supports relationships                                       │
│  • Isolated per user                                            │
└────────────────────────────────────────────────────────────────┘
```

---

## Authentication Flow (JWT)

```
┌─────────────────────────────────────────────────────────────────┐
│                    JWT Authentication Flow                      │
└─────────────────────────────────────────────────────────────────┘

STEP 1: LOGIN
────────────
User submits credentials
         ↓
POST /api/token/
  { username, password }
         ↓
Backend validates credentials
         ↓
Returns JWT tokens:
  { access: "eyJ...", refresh: "eyJ..." }
         ↓
Frontend stores in localStorage:
  token = "eyJ..."


STEP 2: AUTHENTICATED REQUEST
──────────────────────────────
Frontend makes API call:
  GET /api/expenses/
  
With header:
  Authorization: Bearer eyJ...
         ↓
Backend middleware checks token
         ↓
Token valid?
  ✓ YES  → Extract user_id from token
  ✗ NO   → Return 401 Unauthorized
         ↓
If valid: Query database with user_id
         ↓
Return filtered data (user's data only)


STEP 3: TOKEN REFRESH
─────────────────────
When token expires (30+ min):
         ↓
Frontend uses refresh token:
  POST /api/token/refresh/
  { refresh: "eyJ..." }
         ↓
Backend validates refresh token
         ↓
Issues new access token
         ↓
Frontend updates localStorage
         ↓
Continue making requests


STEP 4: SECURITY CHECKS
───────────────────────
✓ Token signature verified
✓ Token not expired
✓ User exists in database
✓ User has permission for resource
✓ No unauthorized access possible
```

---

## Database Schema Relationships

```
┌──────────────────┐
│  auth_user       │ (Django built-in)
│ ─────────────────│
│  id (PK)         │
│  username        │
│  email           │
│  password_hash   │
└────────┬─────────┘
         │ 1:1
         │
         ├─────────────────┬──────────────┬───────────────────┬──────────────┐
         │                 │              │                   │              │
         │ 1:N             │ 1:N          │ 1:N               │ 1:N          │
         ▼                 ▼              ▼                   ▼              ▼
    ┌─────────────┐  ┌──────────────┐  ┌──────────────┐  ┌─────────┐  ┌──────────┐
    │UserProfile  │  │ItinerarySugg │  │ Translation  │  │Booking  │  │Expense   │
    └─────────────┘  └──────────────┘  └──────────────┘  └─────────┘  └──────────┘
    ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐
    │LiveGuideQuer │  │PackingList   │  │SouvenirSugg  │  │JetLagPlan   MoodEntry │
    └──────────────┘  └──────────────┘  └──────────────┘  └──────────────────────┘
    ┌──────────────┐  ┌──────────────┐  ┌──────────────┐
    │OfflineMap    │  │ScrapbookEntry│  │SOSContact    │
    └──────────────┘  └──────────────┘  └──────────────┘

All have: user (ForeignKey to auth_user)
All have: created_at (timestamps)
All return only user's own data via API
```

---

## Request/Response Cycle

```
FRONTEND                     NETWORK                    BACKEND
────────                     ───────                    ───────

User Action
    ↓
Call apiService method
    ↓
Build HTTP request         ──HTTP Request──→         Receive request
Add JWT token                                         ↓
    ↓                                            Verify JWT token
Fetch from API                                       ↓
    ↓                       ←──Response JSON──      Validate request
Wait for response                                    ↓
    ↓                                            Query ORM/Database
Parse JSON                                          ↓
    ↓                                            Serialize to JSON
Store in state             ──Response──→           ↓
    ↓                                            Send response
Update UI
    ↓
User sees data
```

---

**Architecture Summary:**
- ✅ Clean separation of concerns
- ✅ Secure authentication layer
- ✅ User data isolation
- ✅ Scalable design
- ✅ RESTful API structure
