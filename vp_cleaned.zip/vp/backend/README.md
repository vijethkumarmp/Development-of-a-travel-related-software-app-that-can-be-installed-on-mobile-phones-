# TripBro Backend (Django)

This is a Django REST Framework backend skeleton for the TripBro frontend.

Features implemented as models and REST endpoints:
- Itinerary suggestions
- Translations
- Live guide queries
- Packing lists
- Souvenir suggestions
- Jet-lag plans
- Bookings
- Expense entries
- Mood tracker
- Offline map downloads
- Scrapbook entries
- SOS contacts

Quickstart:
1. Create a virtualenv and install requirements.txt
2. python manage.py migrate
3. python manage.py createsuperuser
4. python manage.py runserver

API base: /api/
Auth: JWT (obtain token at /api/token/)

Notes:
- This is a starter backend. You'll likely want to connect external translation APIs, mapping services, and live location services as needed.
