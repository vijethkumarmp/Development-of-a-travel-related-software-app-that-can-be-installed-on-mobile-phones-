from rest_framework import viewsets, permissions, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.views import APIView
from django.contrib.auth.models import User
from .models import *
from .serializers import *

class IsOwner(permissions.BasePermission):
    """
    Custom permission to only allow owners of an object to edit or view it.
    """
    def has_object_permission(self, request, view, obj):
        # Instance must have an attribute named `user`.
        return obj.user == request.user

class BaseViewSet(viewsets.ModelViewSet):
    """
    A base viewset that automatically filters querysets by the current user
    and sets the user on creation.
    """
    permission_classes = [permissions.IsAuthenticated, IsOwner]

    def get_queryset(self):
        """
        This view should return a list of all the items
        for the currently authenticated user.
        """
        return self.queryset.filter(user=self.request.user)

    def perform_create(self, serializer):
        """
        Associate the user with the new object upon creation.
        """
        serializer.save(user=self.request.user)


class UserProfileViewSet(BaseViewSet):
    """
    API endpoint that allows user profiles to be viewed or edited.
    """
    queryset = UserProfile.objects.all()
    serializer_class = UserProfileSerializer

class ItinerarySuggestionViewSet(BaseViewSet):
    """
    API endpoint for itinerary suggestions.
    """
    queryset = ItinerarySuggestion.objects.all()
    serializer_class = ItinerarySuggestionSerializer

    @action(detail=False, methods=['post'])
    def generate_suggestion(self, request):
        """
        Frontend sends a location, backend generates a suggestion and saves it.
        POST /api/itineraries/generate_suggestion/
        Body: {"location_query": "Paris, France"}
        """
        location_query = request.data.get('location_query')
        if not location_query:
            return Response({'location_query': 'This field is required.'}, status=status.HTTP_400_BAD_REQUEST)

        # [External API Call] Here you would call a service like Google Places API or an LLM.
        # For now, we'll create a mock suggestion.
        suggestion_text = f"Based on your interest in {location_query}, you should visit the Eiffel Tower and the Louvre Museum."

        # Create and save the new ItinerarySuggestion object
        serializer = self.get_serializer(data={'location_query': location_query, 'suggested_place': suggestion_text})
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

class TranslationViewSet(BaseViewSet):
    """
    API endpoint for translations.
    """
    queryset = Translation.objects.all()
    serializer_class = TranslationSerializer

    @action(detail=False, methods=['post'])
    def translate_text(self, request):
        """
        Frontend sends text and target language, backend translates and saves.
        POST /api/translations/translate_text/
        Body: {"source_text": "Hello", "target_language": "Spanish"}
        """
        source_text = request.data.get('source_text')
        target_language = request.data.get('target_language')

        if not source_text or not target_language:
            return Response({'error': 'Fields "source_text" and "target_language" are required.'}, status=status.HTTP_400_BAD_REQUEST)

        # [External API Call] Here you would use a translation service (e.g., Google Translate API).
        translated_text = f"'{source_text}' translated to {target_language} is 'Hola'." # Mock translation

        data = {
            'source_text': source_text,
            'target_language': target_language,
            'translated_text': translated_text,
            'source_language': 'English' # Or detect automatically
        }
        serializer = self.get_serializer(data=data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

class LiveGuideQueryViewSet(BaseViewSet):
    """
    API endpoint for live guide queries.
    """
    queryset = LiveGuideQuery.objects.all()
    serializer_class = LiveGuideQuerySerializer

    @action(detail=False, methods=['post'])
    def ask_question(self, request):
        """
        Frontend sends a location and a query, backend generates an answer and saves.
        POST /api/live-guides/ask_question/
        Body: {"location": "Current Location", "query": "Where is the nearest cafe?"}
        """
        location = request.data.get('location')
        query_text = request.data.get('query')

        if not location or not query_text:
            return Response({'error': 'Fields "location" and "query" are required.'}, status=status.HTTP_400_BAD_REQUEST)

        # [External API Call] Here you would use a service like Google Maps/Places or an LLM.
        # Mock response
        response_text = f"The nearest cafe to {location} is 'The Code Bean'."
        
        data = {
            'location': location,
            'query': query_text,
            'reply': response_text
        }
        serializer = self.get_serializer(data=data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

class PackingListViewSet(BaseViewSet):
    """
    API endpoint for packing lists.
    """
    queryset = PackingList.objects.all()
    serializer_class = PackingListSerializer

class SouvenirSuggestionViewSet(BaseViewSet):
    """
    API endpoint for souvenir suggestions.
    """
    queryset = SouvenirSuggestion.objects.all()
    serializer_class = SouvenirSuggestionSerializer

    @action(detail=False, methods=['post'])
    def generate_suggestion(self, request):
        """
        Frontend sends a location, backend generates a souvenir suggestion and saves it.
        POST /api/souvenirs/generate_suggestion/
        Body: {"location": "Tokyo, Japan"}
        """
        location = request.data.get('location')
        if not location:
            return Response({'location': 'This field is required.'}, status=status.HTTP_400_BAD_REQUEST)

        # [External API Call] Here you would call an LLM or a travel API.
        suggestion_text = f"For {location}, a great souvenir is a traditional 'Maneki-neko' cat." # Mock suggestion

        serializer = self.get_serializer(data={'location': location, 'suggestion': suggestion_text})
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

class JetLagPlanViewSet(BaseViewSet):
    """
    API endpoint for jet lag plans.
    """
    queryset = JetLagPlan.objects.all()
    serializer_class = JetLagPlanSerializer

    @action(detail=False, methods=['post'])
    def generate_plan(self, request):
        """
        Frontend sends flight details, backend generates a jet lag plan and saves it.
        POST /api/jetlag-plans/generate_plan/
        """
        if not request.data:
            return Response({'error': 'Flight details are required in the request body.'}, status=status.HTTP_400_BAD_REQUEST)

        # [External API Call] Here you would use an LLM or a specialized health API.
        plan_text = "Adjust your sleep schedule 3 days before departure. Stay hydrated during the flight." # Mock plan
        
        serializer = self.get_serializer(data={**request.data, 'plan': plan_text})
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

class BookingViewSet(BaseViewSet):
    queryset = Booking.objects.all()
    serializer_class = BookingSerializer

class ExpenseEntryViewSet(BaseViewSet):
    queryset = ExpenseEntry.objects.all()
    serializer_class = ExpenseEntrySerializer

class MoodEntryViewSet(BaseViewSet):
    queryset = MoodEntry.objects.all()
    serializer_class = MoodEntrySerializer

class OfflineMapDownloadViewSet(BaseViewSet):
    queryset = OfflineMapDownload.objects.all()
    serializer_class = OfflineMapDownloadSerializer

class ScrapbookEntryViewSet(BaseViewSet):
    queryset = ScrapbookEntry.objects.all()
    serializer_class = ScrapbookEntrySerializer

class SOSContactViewSet(BaseViewSet):
    queryset = SOSContact.objects.all()
    serializer_class = SOSContactSerializer


# Registration Endpoint
class RegisterView(APIView):
    """
    API endpoint for user registration.
    POST /api/register/
    Body: {"username": "john", "email": "john@example.com", "password": "securepassword"}
    """
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        username = request.data.get('username')
        email = request.data.get('email')
        password = request.data.get('password')

        if not all([username, email, password]):
            return Response(
                {'error': 'username, email, and password are required.'},
                status=status.HTTP_400_BAD_REQUEST
            )

        if User.objects.filter(username=username).exists():
            return Response(
                {'error': 'Username already exists.'},
                status=status.HTTP_400_BAD_REQUEST
            )

        if User.objects.filter(email=email).exists():
            return Response(
                {'error': 'Email already exists.'},
                status=status.HTTP_400_BAD_REQUEST
            )

        try:
            user = User.objects.create_user(
                username=username,
                email=email,
                password=password
            )
            # Create a UserProfile for this user
            UserProfile.objects.create(user=user)
            return Response(
                {
                    'id': user.id,
                    'username': user.username,
                    'email': user.email,
                    'message': 'User created successfully. Please login.'
                },
                status=status.HTTP_201_CREATED
            )
        except Exception as e:
            return Response(
                {'error': str(e)},
                status=status.HTTP_400_BAD_REQUEST
            )