from django.contrib import admin
from .models import *
admin.site.register([UserProfile, ItinerarySuggestion, Translation, LiveGuideQuery, PackingList, SouvenirSuggestion, JetLagPlan, Booking, ExpenseEntry, MoodEntry, OfflineMapDownload, ScrapbookEntry, SOSContact])
