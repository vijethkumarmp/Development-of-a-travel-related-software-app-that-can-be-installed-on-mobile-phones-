from django.apps import AppConfig
class BackendappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'backendapp'
    def ready(self):
        # Import signal handlers to enable replication to MongoDB
        try:
            from . import signals  # noqa: F401
        except Exception:
            pass
