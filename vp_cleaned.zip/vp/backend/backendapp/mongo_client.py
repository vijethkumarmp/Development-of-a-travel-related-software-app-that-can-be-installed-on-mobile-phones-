import logging
from django.conf import settings

try:
    from pymongo import MongoClient
except Exception:
    MongoClient = None

logger = logging.getLogger(__name__)

_client = None

def get_mongo_client():
    global _client
    if _client is not None:
        return _client
    if MongoClient is None:
        logger.warning('pymongo not installed; MongoDB integration disabled')
        return None
    try:
        uri = getattr(settings, 'MONGO_URI', 'mongodb://localhost:27017')
        _client = MongoClient(uri, serverSelectionTimeoutMS=2000)
        # quick ping
        _client.admin.command('ping')
        logger.info('Connected to MongoDB at %s', uri)
        return _client
    except Exception as e:
        logger.warning('Could not connect to MongoDB: %s', e)
        _client = None
        return None

def get_db():
    client = get_mongo_client()
    if client is None:
        return None
    db_name = getattr(settings, 'MONGO_DB_NAME', 'tripbro_mongo')
    return client[db_name]
