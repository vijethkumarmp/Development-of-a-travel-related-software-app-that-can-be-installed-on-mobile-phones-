from django.db.models.signals import post_save
from django.dispatch import receiver
from django.apps import apps
from django.conf import settings
import logging

from .mongo_client import get_db

logger = logging.getLogger(__name__)


def model_to_dict(instance):
    """Lightweight serializer for model instance to dict."""
    data = {}
    for field in instance._meta.get_fields():
        # Skip many-to-many and related fields
        if field.many_to_many or field.one_to_many:
            continue
        name = getattr(field, 'name', None)
        if not name:
            continue
        try:
            value = getattr(instance, name)
            # If value is a related object, store its pk
            if hasattr(value, 'pk'):
                data[name] = getattr(value, 'pk')
            else:
                data[name] = value
        except Exception:
            data[name] = None
    return data


@receiver(post_save)
def replicate_to_mongo(sender, instance, created, **kwargs):
    # Only replicate app models (skip Django builtins)
    app_label = getattr(sender._meta, 'app_label', '')
    if app_label == 'auth' or app_label == 'admin' or app_label == 'contenttypes' or app_label == 'sessions':
        return

    db = get_db()
    if db is None:
        # Mongo not available or not configured
        return

    try:
        collection_name = f"{app_label}_{sender.__name__}"
        doc = model_to_dict(instance)
        # Use Django PK as source id
        doc['_django_pk'] = getattr(instance, 'pk', None)
        # Upsert by django pk
        db[collection_name].replace_one({'_django_pk': doc['_django_pk']}, doc, upsert=True)
        logger.debug('Replicated %s to MongoDB collection %s', sender.__name__, collection_name)
    except Exception as e:
        logger.warning('Failed to replicate %s to MongoDB: %s', sender.__name__, e)
