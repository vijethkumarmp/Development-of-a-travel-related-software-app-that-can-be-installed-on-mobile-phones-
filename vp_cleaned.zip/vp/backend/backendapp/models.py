from django.db import models
from django.contrib.auth.models import User

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    home_location = models.CharField(max_length=255, blank=True)

    def __str__(self):
        return self.user.username

class ItinerarySuggestion(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    location_query = models.CharField(max_length=255, blank=True)
    suggested_place = models.CharField(max_length=255, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

class Translation(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    source_text = models.TextField()
    source_language = models.CharField(max_length=50, default='English')
    target_language = models.CharField(max_length=50)
    translated_text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

class LiveGuideQuery(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    query = models.TextField()
    reply = models.TextField(blank=True)
    location = models.CharField(max_length=255, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

class PackingList(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    destination = models.CharField(max_length=255, blank=True)
    trip_details = models.TextField(blank=True)
    packing_list_items = models.JSONField(default=list)
    created_at = models.DateTimeField(auto_now_add=True)

class SouvenirSuggestion(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    location = models.CharField(max_length=255, blank=True)
    suggestion = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

class JetLagPlan(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    departure_location = models.CharField(max_length=255, blank=True)
    arrival_location = models.CharField(max_length=255, blank=True)
    flight_details = models.JSONField(default=dict)
    plan = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

class Booking(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    booking_type = models.CharField(max_length=100, blank=True)
    details = models.JSONField(default=dict)
    booking_date = models.DateTimeField(blank=True, null=True)
    confirmation_number = models.CharField(max_length=255, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

class ExpenseEntry(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    currency = models.CharField(max_length=10, default='USD')
    category = models.CharField(max_length=100, blank=True)
    note = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

class MoodEntry(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    mood = models.CharField(max_length=100)
    note = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

class OfflineMapDownload(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    area = models.CharField(max_length=255)
    file_ref = models.CharField(max_length=255, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

class ScrapbookEntry(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField(max_length=255, blank=True)
    content = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

class SOSContact(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    phone = models.CharField(max_length=50)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
