from django.conf import settings

# This file can contain app-specific settings if needed
# Most settings should be in the main tripbro/settings.py file

# For example, you might want to add app-specific configurations here
# like API endpoints, external service configurations, etc.