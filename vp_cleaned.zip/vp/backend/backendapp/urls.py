from django.urls import path, include
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from . import views

router = DefaultRouter()
router.register(r'userprofiles', views.UserProfileViewSet, basename='userprofile')
router.register(r'itineraries', views.ItinerarySuggestionViewSet, basename='itinerary')
router.register(r'translations', views.TranslationViewSet, basename='translation')
router.register(r'live-guides', views.LiveGuideQueryViewSet, basename='liveguide')
router.register(r'packing-lists', views.PackingListViewSet, basename='packing-list')
router.register(r'souvenirs', views.SouvenirSuggestionViewSet, basename='souvenir')
router.register(r'jetlag-plans', views.JetLagPlanViewSet, basename='jetlag-plan')
router.register(r'bookings', views.BookingViewSet, basename='booking')
router.register(r'expenses', views.ExpenseEntryViewSet, basename='expense')
router.register(r'moods', views.MoodEntryViewSet, basename='mood')
router.register(r'offline-maps', views.OfflineMapDownloadViewSet, basename='offline-map')
router.register(r'scrapbook-entries', views.ScrapbookEntryViewSet, basename='scrapbook-entry')
router.register(r'sos-contacts', views.SOSContactViewSet, basename='sos-contact')

urlpatterns = [
    path('', include(router.urls)), # The router handles the root and all registered endpoints
    path('register/', views.RegisterView.as_view(), name='register'),
    path('token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
]