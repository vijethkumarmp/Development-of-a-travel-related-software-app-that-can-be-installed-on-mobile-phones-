import requests

API_BASE = 'http://localhost:8000/api'

# Login
resp = requests.post(f'{API_BASE}/token/', json={'username':'vijethkumar955@gmail.com','password':'password123'})
print('Token status', resp.status_code)
print(resp.json())

access = resp.json().get('access')
if not access:
    raise SystemExit('No access token')

headers = {'Authorization': 'Bearer ' + access}
# create itinerary suggestion
payload = {'location_query':'Test City'}
r = requests.post(f'{API_BASE}/itineraries/generate_suggestion/', json=payload, headers=headers)
print('Itinerary status', r.status_code)
print(r.json())
