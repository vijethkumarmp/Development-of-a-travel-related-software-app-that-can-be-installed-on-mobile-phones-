import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'tripbro.settings')
django.setup()

from django.contrib.auth.models import User
from backendapp.models import UserProfile

# Create test user
try:
    if not User.objects.filter(email='vijethkumar955@gmail.com').exists():
        user = User.objects.create_user(
            username='vijethkumar955',
            email='vijethkumar955@gmail.com',
            password='password123'
        )
        UserProfile.objects.get_or_create(user=user)
        print('✅ User created successfully!')
        print('Email: vijethkumar955@gmail.com')
        print('Password: password123')
    else:
        print('✅ User already exists')
except Exception as e:
    print(f'❌ Error: {e}')
